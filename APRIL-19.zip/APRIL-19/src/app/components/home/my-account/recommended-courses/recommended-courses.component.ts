import { Component, OnInit, OnDestroy } from '@angular/core';
import { CoursesService } from '../../../../services/courses.service';

@Component({
  selector: 'app-recommended-courses',
  templateUrl: './recommended-courses.component.html',
  styleUrls: ['./recommended-courses.component.css']
})
export class RecommendedCoursesComponent implements OnInit, OnDestroy {
  private subscription: any;
  public recommendedCourses: any;
  public loading: boolean;
  BaseUrl: string;
  deafultCourseImgUrl: string;
  public noData: any;
  public noDomainId: boolean;
  public error_message: string;
  public no_duration: string = '--:--';
  public isCourseAccepted: boolean;

  constructor(private courses_service: CoursesService) { }

  ngOnInit() {
    // this.BaseUrl = window['appConfig'].apiBaseUrl;
    // this.deafultCourseImgUrl = window['appConfig'].deafultCourseImgUrl;
    this.loading = true;
    this.subscription = this.courses_service.GetRecommendedCourses()
      .subscribe( resp => {
          this.recommendedCourses = resp['data'];
        },
        error => {
            setTimeout(() => {
              if (error.error['success'] === false && error.error.errors[0]['code'] === 401) {
                this.error_message = 'No courses assigned';
                this.noData = true;
                this.loading = false;
              } else if (error.error['success'] === false && error.error.errors[0]['code'] === 404) {
                // this.error_message = 'domain id is required';
                this.error_message = 'No Records Found';
                this.noDomainId = true;
                this.loading = false;
              }
            }, 2000);
        }
      );
  }

  accept_suggested_course(flagId: number, courseId: number) {
    console.log('Course accepted :' + flagId + 'and' +  courseId);
    // this.subscription = this.courses_service.suggestedCoursesDeny(flagId, courseId)
    //   .subscribe( resp => {
    //       console.log(resp);
    //     },
    //     error => {
    //         console.log(error);
    //     }
    // );
    // this.isCourseAccepted = true;
  }
  deny_suggested_course(flagId: number, courseId: number) {
    console.log('Course denied : ' + flagId + 'and' + courseId );
    // this.subscription = this.courses_service.suggestedCoursesDeny(flagId, courseId)
    //   .subscribe( resp => {
    //       console.log(resp);
    //     },
    //     error => {
    //         console.log(error);
    //     }
    // );
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

}
