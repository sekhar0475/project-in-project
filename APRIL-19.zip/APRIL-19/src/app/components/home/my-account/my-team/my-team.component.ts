import { Component, OnInit, OnDestroy } from '@angular/core';
import SimpleBar from 'simplebar';
import { CoursesService } from '../../../../services/courses.service';
import { PerfectScrollbarConfigInterface,
  PerfectScrollbarComponent, PerfectScrollbarDirective } from 'ngx-perfect-scrollbar';

@Component({
  selector: 'app-my-team',
  templateUrl: './my-team.component.html',
  styleUrls: ['./my-team.component.css']
})
export class MyTeamComponent implements OnInit, OnDestroy {
  private subscription: any;
  public BaseUrl: string;
  deafultCourseImgUrl: string;
  public myTeam: any;
  public loading: boolean;
  public config: PerfectScrollbarConfigInterface;
  public noDomainId: boolean;
  public apiBaseUrl: string;
  public noData: any;
  public error_message: string;

  constructor(private courses_service: CoursesService) { }
  ngOnInit() {
    // this.BaseUrl = window['appConfig'].apiBaseUrl;
    // this.deafultCourseImgUrl = window['appConfig'].deafultCourseImgUrl;
    this.loading = true;
    this.noData = false;
    this.subscription = this.courses_service.getMyTeam()
      .subscribe( resp => {
          this.myTeam = resp['data']['teammembers'];
        },
        error => {
            setTimeout(() => {
              if (error.error['success'] === false && error.error.errors[0]['code'] === 401) {
                this.error_message = 'No team members';
                this.noData = true;
                this.loading = false;
              } else if (error.error['success'] === false && error.error.errors[0]['code'] === 404) {
                // this.error_message = 'domain id is required';
                this.error_message = 'No Records Found';
                this.noDomainId = true;
                this.loading = false;
              }
            }, 2000);
        }
      );
  }
  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

}
