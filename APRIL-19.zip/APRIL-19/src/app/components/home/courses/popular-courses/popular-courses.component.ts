import { Component, OnInit, OnDestroy } from '@angular/core';
import { CoursesService } from '../../../../services/courses.service';

@Component({
  selector: 'app-popular-courses',
  templateUrl: './popular-courses.component.html',
  styleUrls: ['./popular-courses.component.css']
})
export class PopularCoursesComponent implements OnInit, OnDestroy {

  private subscription: any;
  public popularCourses: any;
  public loading: boolean;
  BaseUrl: string;
  deafultCourseImgUrl: string;
  isAccepted: boolean;
  isDenaied: boolean;
  selectedIndex: number;

  constructor(private courses_service: CoursesService) { }

  ngOnInit() {
    // this.BaseUrl = window['appConfig'].apiBaseUrl;
    // this.deafultCourseImgUrl = window['appConfig'].deafultCourseImgUrl;
    this.loading = true;
    this.subscription = this.courses_service.getPopularCourses()
      .subscribe( resp => {
        this.popularCourses = resp['data'];
        this.loading = false;
      }
    );
  }

  accepted(i) {
      console.log(i);
      this.selectedIndex = i;
      this.isAccepted = true;
  }
  denied(i) {
    console.log(i);
    this.selectedIndex = i;
    this.popularCourses.splice(i, 1);
    this.isDenaied = true;
}
  ngOnDestroy(): void { this.subscription.unsubscribe(); }
}
