import { Injectable } from '@angular/core';
import {Observable, throwError, EMPTY} from 'rxjs';
import { map, filter, concatMap, catchError} from 'rxjs/operators';
import {HttpClient, HttpHeaders, HttpErrorResponse, HttpResponse } from '@angular/common/http';

// const headerDict = {
//   'Content-Type': 'application/json',
//   'Accept': 'application/json',
//   'domainID': window['appConfig'].domainId
// };
// const requestOptions = {headers: new HttpHeaders(headerDict)};

@Injectable({
  providedIn: 'root'
})
export class CoursesService {

  apiBaseUrl: string;
  getPopularCourseUrl: string;
  getNewCoursesUrl: string;
  getMyTeamsUrl: string;
  getLearningTypeCoursesUrl: string;
  getLearningTabsUrl: string;
  getMyCareerPathUrl: string;
  getAcademicCoursesUrl: string;
  GetAcademyListUrl: string;
  getSubAcademyUrl: string;
  myRecommendationUrl: string;
  getAllCoursesUrl: string;
  getLearningPlanStatus: string;
  icertifyUrl: string;
  suggestedCourseDenyUrl: string;

  doaminID: string;
  deafultCourseImgUrl: string;

  readyforroleTabId: number;
  mandatoryTabId: number;
  recommendedTabId: number;
  leadershipTabId: number;
  specialTabId: number;
  othersTabId: number;

  constructor(private http: HttpClient) {
    // this.apiBaseUrl = window['appConfig'].apiBaseUrl;
    // this.getPopularCourseUrl = window['appConfig'].getPopularCourse;
    // this.getNewCoursesUrl = window['appConfig'].getNewCourse;
    // this.getMyTeamsUrl = window['appConfig'].getMyTeam;
    // this.getLearningTypeCoursesUrl =  window['appConfig'].getLearningTypeCourses;
    // this.getLearningTabsUrl =  window['appConfig'].getLearningTabs;
    // this.getMyCareerPathUrl =  window['appConfig'].MyCareerPath;
    // this.getAcademicCoursesUrl = window['appConfig'].getAcademicCourses;
    // this.GetAcademyListUrl = window['appConfig'].GetAcademyList;
    // this.getSubAcademyUrl = window['appConfig'].getSubAcademy;
    // this.myRecommendationUrl = window['appConfig'].myRecommendation;
    // // this.getLearningPlanStatus =  window['appConfig'].getLearningTabs;
    // this.icertifyUrl = window['appConfig'].icertify;

    // this.doaminID = window['appConfig'].domainId;
    // this.deafultCourseImgUrl = window['appConfig'].deafultCourseImgUrl;
    // this.readyforroleTabId = window['appConfig'].readyFor;
    // this.mandatoryTabId = window['appConfig'].mandatory;
    // this.recommendedTabId = window['appConfig'].recommended;
    // this.leadershipTabId = window['appConfig'].leadership;
    // this.specialTabId = window['appConfig'].special;
    // this.othersTabId = window['appConfig'].others;

    // this.getAllCoursesUrl = window['appConfig'].EmployeeCourseUrl;
    // this.suggestedCourseDenyUrl = this.apiBaseUrl + '/course_recommendation/course_recommendation_resources/recommendation_deny.json';
  }

  navigateToUrl(searchBy: number) {
    window.location.href = this.getAllCoursesUrl + `?type=${searchBy}`;
  }
  suggestedCoursesDeny(flagId: number, courseId: number) {
    console.log(this.apiBaseUrl);
    // return this.http.post(this.suggestedCourseDenyUrl, {'flag_id': flagId, 'course_id': courseId }, requestOptions);
  }

  getPopularCourses(): Observable<any> {
    // return this.http.post(this.getPopularCourseUrl, null, requestOptions);
    return this.http.get('../../assets/GetPopularCourses.json');
  }

  getNewCourses(): Observable<any> {
    // return this.http.post(this.getNewCoursesUrl, null, requestOptions);
    return this.http.get('../../assets/GetNewCourses.json');
  }

  getMyTeam(): Observable<any> {
    // return this.http.post(this.getMyTeamsUrl, null, requestOptions);
    return this.http.get('../../assets/MyTeam.json');
  }
  getReadyForRoleCourses() {
    // return this.http.post(this.getLearningTypeCoursesUrl, {'class_id': this.readyforroleTabId}, requestOptions);
    return this.http.get('../../assets/GetLearningTypeCourses.json');
  }
  getMandatoryCourses() {
    // return this.http.post(this.getLearningTypeCoursesUrl, {'class_id': this.mandatoryTabId}, requestOptions);
    return this.http.get('../../assets/GetLearningTypeCourses.json');
  }
  getRecommendedCourses() {
    // return this.http.post(this.getLearningTypeCoursesUrl, {'class_id': this.recommendedTabId}, requestOptions);
    return this.http.get('../../assets/GetLearningTypeCourses.json');
  }

  getSpecialCourses() {
    // return this.http.post(this.getLearningTypeCoursesUrl, {'class_id': this.specialTabId}, requestOptions);
    return this.http.get('../../assets/GetLearningTypeCourses.json');
  }
  getLeadershipCourses() {
    // return this.http.post(this.getLearningTypeCoursesUrl, {'class_id': this.leadershipTabId}, requestOptions);
    return this.http.get('../../assets/GetLearningTypeCourses.json');
  }

  getOthersCourses() {
    // return this.http.post(this.getLearningTypeCoursesUrl, {'class_id': this.othersTabId}, requestOptions);
    return this.http.get('../../assets/GetLearningTypeCourses.json');
  }
  GetLearningPlanStatus() {
    // return this.http.post(this.getLearningTabsUrl, null , requestOptions);
    return this.http.get('../../assets/GetLearningPlanStatus.json');
 }

 getMyCareerPath() {
    // return this.http.post(this.getMyCareerPathUrl, null , requestOptions);
    return this.http.get('../../assets/GetMyCareerPath.json');
 }

 getAcademicCourses() {
    // return this.http.post(this.getAcademicCoursesUrl, null , requestOptions);
    return this.http.get('../../assets/GetAcadenicCourses.json');
 }
 getChanelList() {
   // return this.http.post(this.GetAcademyListUrl, null, requestOptions);
   return this.http.get('../../assets/LocalGetChannelList.json');
 }
 getSubAcademy(subAcademyID: number) {
  // return this.http.post(this.getSubAcademyUrl, {'academy_name': subAcademyID}, requestOptions);
  return this.http.get('../../assets/GetSubAcademy.json');
 }
 GetRecommendedCourses() {
  // return this.http.post(this.myRecommendationUrl, null, requestOptions);
  return this.http.get('../../assets/GetRecommendedCourses.json');
 }
 iCertify() {
  // return this.http.post(this.icertifyUrl, null, requestOptions);
 }

}

