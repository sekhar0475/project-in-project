import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { APP_BASE_HREF } from '@angular/common';
import { AppRoutingModule } from './app-routing.module';

// COMPONENTS
import { AppComponent } from './app.component';
import { HomeComponent } from './components/home/home.component';
import { MyAccountComponent } from './components/home/my-account/my-account.component';
import { MyTrainingComponent } from './components/home/my-account/my-training/my-training.component';
import { ReadyForRoleComponent } from './components/home/my-account/my-training/ready-for-role/ready-for-role.component';
import { MandatoryComponent } from './components/home/my-account/my-training/mandatory/mandatory.component';
import { RecommendedComponent } from './components/home/my-account/my-training/recommended/recommended.component';
import { LeadershipComponent } from './components/home/my-account/my-training/leadership/leadership.component';
import { SpecialComponent } from './components/home/my-account/my-training/special/special.component';
import { OthersComponent } from './components/home/my-account/my-training/others/others.component';
import { IcertificationComponent } from './components/home/my-account/icertification/icertification.component';
import { RecommendedCoursesComponent } from './components/home/my-account/recommended-courses/recommended-courses.component';
import { MyCareerPathComponent } from './components/home/my-account/my-career-path/my-career-path.component';
import { MyTeamComponent } from './components/home/my-account/my-team/my-team.component';
import { EngagementsComponent } from './components/home/engagements/engagements.component';
import { CoursesComponent } from './components/home/courses/courses.component';
import { NewCoursesComponent } from './components/home/courses/new-courses/new-courses.component';
import { PopularCoursesComponent } from './components/home/courses/popular-courses/popular-courses.component';
import { JioCertificationComponent } from './components/home/courses/jio-certification/jio-certification.component';
import { CourseViewComponent } from './components/common/course-view/course-view.component';

// PIPES
import { CustomDatePipe } from './pipes/custom-date.pipe';

import { NgxLoadingModule, ngxLoadingAnimationTypes } from 'ngx-loading';
import { PerfectScrollbarModule, PERFECT_SCROLLBAR_CONFIG, PerfectScrollbarConfigInterface } from 'ngx-perfect-scrollbar';

// INTERCEPTOR
import { HttpErrorInterceptor } from './interceptor/httpconfig.interceptor';

import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ConfirmationDialogComponent } from './components/confirmation-dialog/confirmation-dialog.component';
import { ConfirmationDialogService } from './components/confirmation-dialog/confirmation-dialog.service';

const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
  suppressScrollX: true
};

@NgModule({
  declarations: [
    AppComponent,
    NewCoursesComponent,
    PopularCoursesComponent,
    HomeComponent,
    EngagementsComponent,
    MyAccountComponent,
    CoursesComponent,
    MyTrainingComponent,
    MyCareerPathComponent,
    MyTeamComponent,
    ReadyForRoleComponent,
    MandatoryComponent,
    RecommendedComponent,
    JioCertificationComponent,
    RecommendedCoursesComponent,
    IcertificationComponent,
    LeadershipComponent,
    SpecialComponent,
    OthersComponent,
    CustomDatePipe,
    ConfirmationDialogComponent,
    CourseViewComponent
  ],
  imports: [
    BrowserModule, HttpClientModule, FormsModule, BrowserAnimationsModule, PerfectScrollbarModule, NgbModule,
    NgxLoadingModule.forRoot({
      animationType: ngxLoadingAnimationTypes.cubeGrid,
      backdropBackgroundColour: 'rgba(255,255,255,0.8)',
      backdropBorderRadius: '4px',
      primaryColour: '#9966ff',
      secondaryColour: '#66ccff',
      tertiaryColour: '#ffffff'
    }),
    AppRoutingModule
  ],
  providers: [
    ConfirmationDialogService,
    {provide: APP_BASE_HREF, useValue : '/' },
    {
      provide: PERFECT_SCROLLBAR_CONFIG,
      useValue: DEFAULT_PERFECT_SCROLLBAR_CONFIG
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: HttpErrorInterceptor,
      multi: true,
    },
  ],
  bootstrap: [AppComponent],
  entryComponents: [ ConfirmationDialogComponent ]
})
export class AppModule { }
