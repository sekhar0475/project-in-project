import { Component, OnInit, Input, OnDestroy } from '@angular/core';
import { CoursesService } from '../../../../services/courses.service';
import {
  PerfectScrollbarConfigInterface,
  PerfectScrollbarComponent,
  PerfectScrollbarDirective
} from 'ngx-perfect-scrollbar';

@Component({
  selector: 'app-my-team',
  templateUrl: './my-team.component.html',
  styleUrls: ['./my-team.component.css']
})
export class MyTeamComponent implements OnInit {
  public BaseUrl: string;
  deafultCourseImgUrl: string;

  public config: PerfectScrollbarConfigInterface;
  public apiBaseUrl: string;
  teamMemberImg: string;

  @Input() myTeam: any;
  @Input() loading: boolean ;
  @Input() errorPresent: boolean;
  @Input() error_message: string;
  @Input() noData: boolean = true;
  @Input() myTeamStatus: boolean;

  constructor(private courses_service: CoursesService) {}
  ngOnInit() {
    this.BaseUrl = window['appConfig'].apiBaseUrl;
    this.deafultCourseImgUrl = window['appConfig'].deafultCourseImgUrl;
    this.teamMemberImg = window['appConfig'].teamMemberImgUrl;
  }

  all_team_members() {
    window.location.href = this.BaseUrl + '/my/training/status';
  }
}
