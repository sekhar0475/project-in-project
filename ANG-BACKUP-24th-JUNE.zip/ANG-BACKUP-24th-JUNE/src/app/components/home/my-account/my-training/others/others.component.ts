import { Component, OnInit, OnDestroy } from '@angular/core';
import {Input} from '@angular/core';

import { CoursesService } from '../../../../../services/courses.service';

@Component({
  selector: 'app-others',
  templateUrl: './others.component.html',
  styleUrls: ['./others.component.css']
})
export class OthersComponent implements OnInit, OnDestroy {
  private subscription: any;
  public othersCourses:  any;
  public loading: boolean = false;
  deafultCourseImgUrl: string;
  public error_message: string;
  errorPresent: boolean;

  constructor(private courses_service: CoursesService) {}
  ngOnInit() {
    this.deafultCourseImgUrl = window['appConfig'].deafultCourseImgUrl;
    this.subscription = this.courses_service.getOthersCourses()
      .subscribe( resp => {
          this.loading = true;
          if (resp['data'].length) {
            setTimeout(() => {
              this.othersCourses = resp['data'];
              this.loading = false;
            }, 1000);
          } else {
            this.loading = false;
            this.errorPresent = true;
            this.error_message = 'No records found';
          }
        },
        error => {
            this.errorPresent = true;
            this.error_message = error;
        }
      );
  }
  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

}
