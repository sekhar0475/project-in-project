import { Component, OnInit, OnDestroy } from '@angular/core';
import { CoursesService } from '../../../../services/courses.service';

import { ConfirmationDialogService } from '../../../confirmation-dialog/confirmation-dialog.service';
@Component({
  selector: 'app-recommended-courses',
  templateUrl: './recommended-courses.component.html',
  styleUrls: ['./recommended-courses.component.css']
})
export class RecommendedCoursesComponent implements OnInit, OnDestroy {
  private subscription: any;
  public recommendedCourses: any;
  public loading: boolean = false;
  BaseUrl: string;
  deafultCourseImgUrl: string;
  public error_message: string;
  public no_duration: string = '--:--';
  public isCourseAccepted: boolean;
  public isCourseDenied: boolean;
  selectedIndex: number;
  errorPresent: boolean;
  noData: boolean = true;

  constructor(private courses_service: CoursesService, private confirmationDialogService: ConfirmationDialogService) { }

  ngOnInit() {
    this.BaseUrl = window['appConfig'].apiBaseUrl;
    this.deafultCourseImgUrl = window['appConfig'].deafultCourseImgUrl;
    this.isCourseAccepted = false;
    this.GetRecommendedCourses();
  }

  GetRecommendedCourses() {
    this.subscription = this.courses_service.GetRecommendedCourses().subscribe( resp => {
        this.noData = false;
        this.loading = true;
        if (resp['data'].length) {
          setTimeout(() => {
            this.recommendedCourses = resp['data'];
            this.loading = false;
          }, 1000);
        } else {
          this.loading = false;
          this.errorPresent = true;
          this.error_message = 'No records found';
        }
      },
      error => {
        this.errorPresent = true;
        this.error_message = error;
      }
    );
  }

  accept_suggested_course(flagId: number, courseId: number, courseTitle: string, index: number) {
    this.confirmationDialogService.confirm('Please confirm..', `accept : ${courseTitle}`)
     .then((confirmed) => {
        if (confirmed) {
          this.selectedIndex = index;
          this.isCourseAccepted = true;
          this.subscription = this.courses_service.suggestedCoursesDeny(flagId, courseId)
            .subscribe( resp => {},
              error => { console.log(error); }
          );
        }
      }
    )
    .catch(() => {
    console.log('User dismissed the dialog (e.g., by using ESC, clicking the cross icon, or clicking outside the dialog)');
    });
  }

  deny_suggested_course(flagId: number, courseId: number, courseTitle: string, index: number) {
    this.confirmationDialogService.confirm('Please confirm..', `deny : ${courseTitle}`)
     .then((confirmed) => {
          if (confirmed) {
            this.selectedIndex = index;
            this.recommendedCourses.splice(index, 1);
            this.isCourseDenied = true;
            this.subscription = this.courses_service.suggestedCoursesDeny(flagId, courseId)
              .subscribe(
                resp => { console.log(resp); },
                error => { console.log(error); }
              );
          }
       }
      )
     .catch(() => {
      console.log('User dismissed the dialog (e.g., by using ESC, clicking the cross icon, or clicking outside the dialog)');
      });
  }

  all_suggested_courses() {
    window.location.href = this.BaseUrl + '/recommendation/suggested-courses';
  }
  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

}
