import { Component, OnInit, OnDestroy } from '@angular/core';

import { CoursesService } from '../../../../services/courses.service';

@Component({
  selector: 'app-my-team',
  templateUrl: './my-team.component.html',
  styleUrls: ['./my-team.component.css']
})
export class MyTeamComponent implements OnInit, OnDestroy {
  private subscription: any;
  public myTeam: any;
  public loading: boolean;
  constructor(private courses_service: CoursesService) { }

  ngOnInit() {
    this.loading = true;
    this.subscription = this.courses_service.getMyTeam()
      .subscribe( resp => {
        this.myTeam = resp['data']['TeamMembers'];
        this.loading = false;
      });
  }
  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

}
