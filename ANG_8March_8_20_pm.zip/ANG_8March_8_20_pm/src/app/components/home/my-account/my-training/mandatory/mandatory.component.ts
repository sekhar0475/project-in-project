import { Component, OnInit, OnDestroy } from '@angular/core';
import { CoursesService } from '../../../../../services/courses.service';

@Component({
  selector: 'app-mandatory',
  templateUrl: './mandatory.component.html',
  styleUrls: ['./mandatory.component.css']
})
export class MandatoryComponent implements OnInit, OnDestroy {
  private subscription: any;
  public mandatoryCourses: any;
  public percent: number;
  public loader: boolean;

  constructor(private courses_service: CoursesService) { }

  ngOnInit() {
    this.loader = true;
    this.subscription = this.courses_service.getMandatoryCourses()
      .subscribe( resp => { this.mandatoryCourses = resp['data'];
      this.loader = false;
    });
    this.percent = 40;
  }
  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

}
