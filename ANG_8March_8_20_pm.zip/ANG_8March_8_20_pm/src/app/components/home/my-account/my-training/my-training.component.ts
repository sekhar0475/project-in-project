import { Component, OnInit, OnDestroy } from '@angular/core';
import { CoursesService } from '../../../../services/courses.service';

@Component({
  selector: 'app-my-training',
  templateUrl: './my-training.component.html',
  styleUrls: ['./my-training.component.css']
})
export class MyTrainingComponent implements OnInit, OnDestroy {
  private subscription: any;
  public displayMyTrainingRoutes: string = 'Ready for role';
  public learningLearningPlanStatus:  any;

  readyforroleTabId: number;
  mandatoryTabId: number;
  recommendedTabId: number;
  selectedTabId: number;

  constructor(private courses_service: CoursesService) {

    // this.readyforroleTabId = window['appConfig'].readyFor;
    // this.mandatoryTabId = window['appConfig'].mandatory;
    // this.recommendedTabId = window['appConfig'].recommended;

    this.selectedTabId = this.readyforroleTabId;
   }

  ngOnInit() {
    this.subscription = this.courses_service.GetLearningPlanStatus()
      .subscribe( resp => (this.learningLearningPlanStatus = resp['data'])
    );
  }
  goToAllCourses(paramValue: number): void {
    this.courses_service.navigateToUrl(paramValue);
  }

  ngOnDestroy(): void { this.subscription.unsubscribe(); }
}

