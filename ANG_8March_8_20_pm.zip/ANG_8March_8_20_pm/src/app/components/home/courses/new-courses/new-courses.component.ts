import { Component, OnInit, OnDestroy } from '@angular/core';

import { CoursesService } from '../../../../services/courses.service';
@Component({
  selector: 'app-new-courses',
  templateUrl: './new-courses.component.html',
  styleUrls: ['./new-courses.component.css']
})
export class NewCoursesComponent implements OnInit, OnDestroy {
  private subscription: any;
  public newCourses:  any;
  public loading: boolean;
  BaseUrl: string;

  constructor(private courses_service: CoursesService) { }

  ngOnInit() {
    // this.BaseUrl = window['appConfig'].apiBaseUrl;
    this.loading = true;
    this.subscription = this.courses_service.getNewCourses()
      .subscribe( resp => {
        this.newCourses = resp['data'];
        this.loading = false;
    });
  }
  ngOnDestroy(): void { this.subscription.unsubscribe(); }
}
