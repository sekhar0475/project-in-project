import { Component, OnInit, OnDestroy } from '@angular/core';
import { CoursesService } from '../../../../services/courses.service';

@Component({
  selector: 'app-jio-certification',
  templateUrl: './jio-certification.component.html',
  styleUrls: ['./jio-certification.component.css']
})
export class JioCertificationComponent implements OnInit, OnDestroy {
  private subscription: any;
  public popularCourses: any;
  public loading: boolean;

  constructor(private courses_service: CoursesService) { }

  ngOnInit() {
    this.loading = true;
    this.subscription = this.courses_service.getAcademicCourses()
      .subscribe( resp => {
        this.popularCourses = resp;
        this.loading = false;
      }
    );
  }
  ngOnDestroy(): void { this.subscription.unsubscribe(); }

}
