import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IcertificationComponent } from './icertification.component';

describe('IcertificationComponent', () => {
  let component: IcertificationComponent;
  let fixture: ComponentFixture<IcertificationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IcertificationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IcertificationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
