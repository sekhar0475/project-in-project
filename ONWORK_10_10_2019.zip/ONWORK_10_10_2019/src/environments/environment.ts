// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  doaminID : 'Sumit.Rusia',
  csrfToken : 'axxx-bxxx-cxxx-dxxx',
  apiBaseUrl : '../assets/',
  deafultCourseImgUrl : 'images/default_course_image.jpg',
  teamMemberImg : 'images/team_member.jpg',
  getPopularCourseUrl : '../assets/popularCourses.json',
  getNewCoursesUrl : '../assets/newCourses.json',
  getMyTeamsUrl : '../assets/myTeam.json',
  getLearningTypeCoursesUrl :  '../assets/learningTypeCourses.json',
  getLearningTabsUrl :  '../assets/popularCourses.json',
  getMyCareerPathUrl :  '../assets/myCareerPath.json',
  getAcademicCoursesUrl : '../assets/academicCourses.json',
  GetAcademyListUrl : '../assets/academyList.json',
  getSubAcademyUrl : '../assets/subAcademy.json',
  myRecommendationUrl : '../assets/myRecommendedTeam.json',
  icertifyUrl : '../assets/selfCertifyByUser.json',
  getAllCoursesUrl : '../assets/popularCourses.json',
  getClassTypeListUrl : '../assets/classTypeList.json',
  myAnnouncementsData : '../assets/announcements.json',
  readyforroleTabId : 136246
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
