(function ($) {
	
	"use strict";
	
	///////////////////////////////////////////////////////////
	// wow js active
	///////////////////////////////////////////////////////////
	new WOW().init();
	 
	///////////////////////////////////////////////////////////
	// preloader
	///////////////////////////////////////////////////////////
	$(window).on('load',function() { // makes sure the whole site is loaded
		$('.preloder-wrap').fadeOut(); // will first fade out the loading animation
		$('.loader').delay(150).fadeOut('slow'); // will fade out the white DIV that covers the website.
		$('body').delay(150).css({'overflow':'visible'})
	});
	
	
	
	///////////////////////////////////////////////////////////
	// scroll tabs
	///////////////////////////////////////////////////////////
	var scrollEnabled = true;
	var $tabs;
	var scrollEnabled;
	$(function () {
		// To get the random tabs label with variable length for testing the calculations
		var keywords = ['Just a tab label', 'Long string', 'Short',
			'Very very long string', 'tab', 'New tab', 'This is a new tab'];
		$('#scroll-tabs-1, #scroll-tabs-2, #scroll-tabs-3, #scroll-tabs-4').scrollTabs({
			scrollOptions: {
                easing: 'swing',
                enableDebug: false,
                closable: false,
                showFirstLastArrows: false,
                selectTabAfterScroll: true
            }
		});
	});
	
	///////////////////////////////////////////////////////////
	// slimScroll
	///////////////////////////////////////////////////////////
	$(function() {
		$('.tab-fix-ceontent').slimScroll({
			height: '358px',
			size: '3px',
			color: '#92bae5',
			opacity: 0.9,
			alwaysVisible: true,
			distance: '9px',
			railVisible: true,
			railColor: '#ddd',
			railOpacity: 0.9,
			wheelStep: 10,
			allowPageScroll: false,
			disableFadeOut: false
		});
	});
	
	///////////////////////////////////////////////////////////
	// social share
	///////////////////////////////////////////////////////////
	$(document).ready(function(){	
	
			var btn = $('#bttbtn');

			$(window).scroll(function() {
			  if ($(window).scrollTop() > 50) {
				btn.addClass('show');
			  } else {
				btn.removeClass('show');
			  }
			});

			btn.on('click', function(e) {
			  e.preventDefault();
			  $('html, body').animate({scrollTop:0}, '300');
			});
	
		
		$('.social').click(function() {
			$(this).siblings('.social-list').toggle(function(){
				if ($(this).hasClass("active")){
					$(this).removeClass('active');   
				}else{
					$(this).addClass('active');   
				}
			});
			$(this).find('i').toggleClass("fa-share-alt fa-times");
		});
	});

	$(".shareRoundIcons").jsSocials({
		shareIn: "popup",
		text: "Ladies Gold Polki Ring",
		showLabel: false,
		showCount: true,
		//shares: ["twitter", "facebook", "googleplus", "linkedin", "pinterest", "stumbleupon", "whatsapp"]
		shares: ["facebook", "twitter"]
	});
	
	$('.search-icon').on('click', function() {
		$('.navbar-form').fadeIn(300);
		$('.navbar-form input').focus();
	});
	$('.navbar-form input').blur(function() {
		$('.navbar-form').fadeOut(300);
	});
	
})(jQuery);