export const environment = {
  production: true,
  apiBaseUrl : window['appConfig'].apiBaseUrl
};

