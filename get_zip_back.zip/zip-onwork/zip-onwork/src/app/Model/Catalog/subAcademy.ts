export interface SubAcademyData {
    ChannelID: string;
    ChannelName: string;
    academylink: string;
    courses: string;
}

export interface SubAcademy {
    status: number;
    message: string;
    data: SubAcademyData[];
}
