// export const apis = {
//   static doaminID : window['appConfig'].domainId,
//   static csrfToken : window['appConfig'].csrfToken,
//   static deafultCourseImgUrl : window['appConfig'].deafultCourseImgUrl,
//   static teamMemberImg : window['appConfig'].teamMemberImgUrl,
//   static getPopularCourseUrl : window['appConfig'].getPopularCourse,
//   static getNewCoursesUrl : window['appConfig'].getNewCourse,
//   static getMyTeamsUrl : window['appConfig'].getMyTeam,
//   static getLearningTypeCoursesUrl :  window['appConfig'].getLearningTypeCourses,
//   static getLearningTabsUrl :  window['appConfig'].getLearningTabs,
//   static getMyCareerPathUrl :  window['appConfig'].MyCareerPath,
//   static getAcademicCoursesUrl : window['appConfig'].getAcademicCourses,
//   static GetAcademyListUrl : window['appConfig'].GetAcademyList,
//   static getSubAcademyUrl : window['appConfig'].getSubAcademy,
//   static myRecommendationUrl : window['appConfig'].myRecommendation,
//   static icertifyUrl : window['appConfig'].icertify,
//   static getAllCoursesUrl : window['appConfig'].EmployeeCourseUrl,
//   static getClassTypeListUrl : window['appConfig'].getClassTypeList,
//   static myAnnouncementsData : window['appConfig'].myAnnouncements,
//   static readyforroleTabId : window['appConfig'].readyFor
// };

export class AppConstants {
    public static DOMAIN_ID = window['appConfig'].domainId;
}
