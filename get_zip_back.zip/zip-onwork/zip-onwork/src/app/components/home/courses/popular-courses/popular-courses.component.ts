import { Component, OnInit, OnDestroy } from '@angular/core';
import { CoursesService } from '../../../../services/courses.service';
// import { custom-date.pipe.ts} from '../../../../pipes/custom-date.pipe';
import { environment } from '../../../../../environments/environment';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-popular-courses',
  templateUrl: './popular-courses.component.html',
  styleUrls: ['./popular-courses.component.css']
})
export class PopularCoursesComponent implements OnInit, OnDestroy {

  private subscription: any;
  public popularCourses: any;
  loading: boolean = true;
  BaseUrl: string;
  deafultCourseImgUrl: string;
  errorPresent: boolean;
  public error_message: string;

  constructor(private courses_service: CoursesService) { }

  ngOnInit() {
    this.BaseUrl = environment.apiBaseUrl;
    this.deafultCourseImgUrl = environment.deafultCourseImgUrl;
    this.subscription = this.courses_service.getPopularCourses()
    .subscribe( resp => {
        this.popularCourses = resp['data'];
        this.loading = false;
      }, error => {
        this.loading = false;
        this.errorPresent = true;
        this.error_message = error;
      }
    );
  }
  ngOnDestroy(): void {
    if (this.subscription) {
      this.subscription.unsubscribe();
    }
  }
}
