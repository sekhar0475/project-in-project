import { Component, OnInit, OnDestroy } from '@angular/core';
import { CoursesService } from '../../../../services/courses.service';
import { environment } from '../../../../../environments/environment';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-new-courses',
  templateUrl: './new-courses.component.html',
  styleUrls: ['./new-courses.component.css']
})
export class NewCoursesComponent implements OnInit, OnDestroy {
  newCourses:  any;
  loading: boolean = true;
  BaseUrl: string;
  deafultCourseImgUrl: string;
  errorPresent: boolean;
  error_message: string;
  private subscription: any;

  constructor(private courses_service: CoursesService) { }
   ngOnInit() {
    this.BaseUrl = environment.apiBaseUrl;
    this.deafultCourseImgUrl = environment.deafultCourseImgUrl;

    this.courses_service.getNewCourses()
    .subscribe( resp => {
        this.newCourses = resp['data'];
        this.loading = false;
      }, error => {
        this.loading = false;
        this.errorPresent = true;
        this.error_message = error;
      });

  }
  ngOnDestroy(): void {
    if (this.subscription) {
      this.subscription.unsubscribe();
    }
  }
}
