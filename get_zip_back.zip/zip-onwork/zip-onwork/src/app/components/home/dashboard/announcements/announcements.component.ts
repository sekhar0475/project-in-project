import { Component, OnInit, OnDestroy } from '@angular/core';
import { environment } from '../../../../../environments/environment';
import { CoursesService } from '../../../../services/courses.service';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-announcements',
  templateUrl: './announcements.component.html',
  styleUrls: ['./announcements.component.css']
})
export class AnnouncementsComponent implements OnInit, OnDestroy {
  private subscription: any;
  myAnnouncementsData: any;
  errorPresent: boolean;
  constructor(private courses_service: CoursesService) { }

  ngOnInit() {
    this.errorPresent = false;
    this.subscription = this.courses_service.GetmyAnnouncementsData()
      .subscribe(
        resp => {
          this.myAnnouncementsData = resp;
        },
        err => { this.errorPresent = true; }
    );
  }

  ngOnDestroy(): void {
    if (this.subscription) {
      this.subscription.unsubscribe();
    }
  }
}
