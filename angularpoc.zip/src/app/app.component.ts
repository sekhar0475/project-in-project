import { Component } from '@angular/core';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'angularpoc';
  public isbtnFirst:boolean;
  public firstTabFlags:object = {isbtnFirst:false,isbtnSecond:false,isbtnThird:false,isbtnFour:false};
  public thirdTabFlags:object = {isbtnFirst:false,isbtnSecond:false,isbtnThird:false,isbtnFour:false};
}
