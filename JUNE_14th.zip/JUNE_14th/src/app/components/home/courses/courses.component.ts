import { Component, OnInit } from '@angular/core';
import { PerfectScrollbarConfigInterface,
  PerfectScrollbarComponent, PerfectScrollbarDirective } from 'ngx-perfect-scrollbar';

@Component({
  selector: 'app-courses',
  templateUrl: './courses.component.html',
  styleUrls: ['./courses.component.css']
})
export class CoursesComponent implements OnInit {

  public displayCourseChildRoutes: string = 'popularCourses';
  public config: PerfectScrollbarConfigInterface;

  constructor() { }

  ngOnInit() {
  }
}
