import { Component, OnInit, OnDestroy } from '@angular/core';
import { CoursesService } from '../../../../services/courses.service';
import {
  PerfectScrollbarConfigInterface,
  PerfectScrollbarComponent,
  PerfectScrollbarDirective
} from 'ngx-perfect-scrollbar';

@Component({
  selector: 'app-my-team',
  templateUrl: './my-team.component.html',
  styleUrls: ['./my-team.component.css']
})
export class MyTeamComponent implements OnInit, OnDestroy {
  private subscription: any;
  public BaseUrl: string;
  deafultCourseImgUrl: string;
  public myTeam: any;
  public loading: boolean = false;
  public config: PerfectScrollbarConfigInterface;
  public apiBaseUrl: string;
  public error_message: string;
  errorPresent: boolean;
  noData: boolean = true;
  teamMemberImg: string;
  // my_team_image = '../../../../../assets/img/my_team_member.jpg';

  constructor(private courses_service: CoursesService) {}
  ngOnInit() {
    this.BaseUrl = window['appConfig'].apiBaseUrl;
    this.deafultCourseImgUrl = window['appConfig'].deafultCourseImgUrl;
    this.teamMemberImg = window['appConfig'].teamMemberImgUrl;
    this.subscription = this.courses_service.getMyTeam().subscribe(
      resp => {
        if (resp['data']['teamcount'] > 0) {
          this.noData = false;
          this.loading = true;
          setTimeout(() => {
            this.myTeam = resp['data']['teammembers'];
            this.loading = false;
          }, 1000);
        } else {
          this.loading = false;
          this.errorPresent = true;
          this.error_message = 'No records found';
        }
      },
      error => {
        this.errorPresent = true;
        this.error_message = error;
      }
    );
  }

  all_team_members() {
    window.location.href = this.BaseUrl + '/my/training/status';
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
}
