import { Component, OnInit, OnDestroy } from '@angular/core';
import { CoursesService } from '../../../../services/courses.service';

@Component({
  selector: 'app-my-career-path',
  templateUrl: './my-career-path.component.html',
  styleUrls: ['./my-career-path.component.css']
})
export class MyCareerPathComponent implements OnInit, OnDestroy {
  private subscription: any;
  public myCareerPath: any;
  public loading: boolean;
  BaseUrl: string;
  deafultCourseImgUrl: string;
  public apiBaseUrl: string;
  public error_message: string;
  errorPresent: boolean;
  noData: boolean = true;

  constructor(private courses_service: CoursesService) { }

  ngOnInit() {
    this.BaseUrl = window['appConfig'].apiBaseUrl;
    this.deafultCourseImgUrl = window['appConfig'].deafultCourseImgUrl;
    this.subscription = this.courses_service.getMyCareerPath().subscribe( resp => {
          this.noData = false;
          this.loading = true;
          if (resp['data'].length) {
            setTimeout(() => {
              this.myCareerPath = resp['data'];
              this.loading = false;
            }, 1000);
          } else {
            this.loading = false;
            this.errorPresent = true;
            this.error_message = 'No records found';
          }
        },
        error => {
          this.errorPresent = true;
          this.error_message = error;
        }
      );
  }

  all_my_career_path() {
    window.location.href = this.BaseUrl + '/employee/career_path?title=&type=Learning Path';
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

}
