import { Component, OnInit, OnDestroy } from '@angular/core';
import { CoursesService } from './../../../services/courses.service';

@Component({
  selector: 'app-my-account',
  templateUrl: './my-account.component.html',
  styleUrls: ['./my-account.component.css']
})
export class MyAccountComponent implements OnInit, OnDestroy {
  subscription: any;
  hideMyTeam: boolean = false;
  hideCareerPath: boolean = false;

  constructor(private courses_service: CoursesService) {}
  ngOnInit() {

    this.subscription = this.courses_service.getMyTeam().subscribe(resp => {
      if (resp['data']['teamcount'] > 0) {
        this.hideMyTeam = false;
      } else { this.hideMyTeam = true; }
    }, error => { this.hideMyTeam = true; });

    this.subscription = this.courses_service.getMyCareerPath().subscribe(resp => {
      if (!resp['data'].length) {
        this.hideCareerPath = true;
      }
    }, error => { this.hideCareerPath = true; });
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
}
