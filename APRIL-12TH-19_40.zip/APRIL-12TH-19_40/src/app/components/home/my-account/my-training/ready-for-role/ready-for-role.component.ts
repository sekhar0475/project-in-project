import { Component, OnInit, OnDestroy } from '@angular/core';
import {Input} from '@angular/core';

import { CoursesService } from '../../../../../services/courses.service';

@Component({
  selector: 'app-ready-for-role',
  templateUrl: './ready-for-role.component.html',
  styleUrls: ['./ready-for-role.component.css']
})
export class ReadyForRoleComponent implements OnInit, OnDestroy {
  private subscription: any;
  public learningTypeCourses:  any;
  public loading: boolean;
  public noData: boolean;
  public noDomainId: boolean;
  deafultCourseImgUrl: string;

  constructor(private courses_service: CoursesService) {}
  ngOnInit() {
    this.deafultCourseImgUrl = window['appConfig'].deafultCourseImgUrl;
    this.loading = true;
    this.noData = false;
    this.subscription = this.courses_service.getReadyForRoleCourses()
      .subscribe( resp => {
        this.noDomainId = false;
        this.learningTypeCourses = resp['data'];
        if (this.learningTypeCourses.length === 0) {
          setTimeout(() => {
              this.noData = true;
              this.loading = false;
          }, 2000);
        }
      },
      error => {
          setTimeout(() => {
            this.loading = false;
            this.noDomainId = true;
          }, 2000);
        }
      );
  }
  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

}
