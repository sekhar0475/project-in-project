import { Component, OnInit, OnDestroy } from '@angular/core';
import { CoursesService } from '../../../../services/courses.service';

@Component({
  selector: 'app-my-career-path',
  templateUrl: './my-career-path.component.html',
  styleUrls: ['./my-career-path.component.css']
})
export class MyCareerPathComponent implements OnInit, OnDestroy {
  private subscription: any;
  public myCareerPath: any;
  public loading: boolean;
  BaseUrl: string;
  deafultCourseImgUrl: string;
  public noDomainId: boolean;
  public apiBaseUrl: string;
  public noData: any;

  constructor(private courses_service: CoursesService) { }

  ngOnInit() {
    this.BaseUrl = window['appConfig'].apiBaseUrl;
    this.deafultCourseImgUrl = window['appConfig'].deafultCourseImgUrl;
    this.loading = true;
    this.noData = false;
    this.subscription = this.courses_service.getMyCareerPath()
      .subscribe( resp => {
        this.noDomainId = false;
        this.myCareerPath = resp['data'];
        if (this.myCareerPath.length === 0) {
          setTimeout(() => {
            this.noData = true;
            this.loading = false;
          }, 2000);
        }
      },
      error => {
        setTimeout(() => {
          this.loading = false;
          this.noDomainId = true;
        }, 2000);
      }
    );
  }
  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

}
