import { Component, OnInit, OnDestroy } from '@angular/core';
import { CoursesService } from '../../../../services/courses.service';
import { PerfectScrollbarConfigInterface,
  PerfectScrollbarComponent, PerfectScrollbarDirective } from 'ngx-perfect-scrollbar';
import { Response } from 'selenium-webdriver/http';

@Component({
  selector: 'app-icertification',
  templateUrl: './icertification.component.html',
  styleUrls: ['./icertification.component.css']
})
export class IcertificationComponent implements OnInit, OnDestroy {
  private subscription: any;
  public BaseUrl: string;
  deafultCourseImgUrl: string;
  public learning_plan_status: any;
  public learning_plan_status_value: any;
  public i_certify_button: boolean;
  public icertify_text: string = 'I have completed Ready for Role Program and I know how to do my job';
  public loading: boolean;
  public config: PerfectScrollbarConfigInterface;
  public noDomainId: boolean;
  public apiBaseUrl: string;
  public noData: any;

  public iCertifyStatus: boolean;
  constructor(private courses_service: CoursesService) { }
  ngOnInit() {
    this.BaseUrl = window['appConfig'].apiBaseUrl;
    this.deafultCourseImgUrl = window['appConfig'].deafultCourseImgUrl;
    this.loading = true;
    this.noData = false;
    this.iCertifyStatus = false;
    this.i_certify_button = true;
    this.subscription = this.courses_service.GetLearningPlanStatus()
      .subscribe( resp => {
        this.noDomainId = false;
        this.learning_plan_status = resp.filter(item => item.class_type === 'Ready for Role');
        this.learning_plan_status_value = this.learning_plan_status[0].status;
        if (this.learning_plan_status_value === 100) {
            this.iCertifyStatus = true;
        }
      },
      error => {
        setTimeout(() => {
          this.loading = false;
          this.noDomainId = true;
        }, 2000);
      });
  }
  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  icertify() {
      if (this.iCertifyStatus) {
        this.i_certify_button = false;
        this.icertify_text = 'Congratulations you have already certified yourself as Ready for Role';
      } else {
         console.log(this.learning_plan_status_value);
      }
  }

}
