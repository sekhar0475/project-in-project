import { Component, OnInit, OnDestroy } from '@angular/core';
import SimpleBar from 'simplebar';
import { CoursesService } from '../../../../services/courses.service';
import { PerfectScrollbarConfigInterface,
  PerfectScrollbarComponent, PerfectScrollbarDirective } from 'ngx-perfect-scrollbar';

@Component({
  selector: 'app-my-team',
  templateUrl: './my-team.component.html',
  styleUrls: ['./my-team.component.css']
})
export class MyTeamComponent implements OnInit, OnDestroy {
  private subscription: any;
  public BaseUrl: string;
  deafultCourseImgUrl: string;
  public myTeam: any;
  public loading: boolean;
  public config: PerfectScrollbarConfigInterface;
  public noDomainId: boolean;
  public apiBaseUrl: string;
  public noData: any;

  constructor(private courses_service: CoursesService) { }
  ngOnInit() {
    this.BaseUrl = window['appConfig'].apiBaseUrl;
    this.deafultCourseImgUrl = window['appConfig'].deafultCourseImgUrl;
    this.loading = true;
    this.noData = false;
    this.subscription = this.courses_service.getMyTeam()
      .subscribe( resp => {
        this.noDomainId = false;
        this.myTeam = resp['data']['TeamMembers'];
        if (this.myTeam.length === 0) {
          setTimeout(() => {
            this.noData = true;
            this.loading = false;
          }, 2000);
        }
      },
      error => {
        setTimeout(() => {
          this.loading = false;
          this.noDomainId = true;
        }, 2000);
      });
  }
  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

}
