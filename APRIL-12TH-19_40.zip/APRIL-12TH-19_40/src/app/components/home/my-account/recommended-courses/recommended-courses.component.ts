import { Component, OnInit, OnDestroy } from '@angular/core';
import { CoursesService } from '../../../../services/courses.service';

@Component({
  selector: 'app-recommended-courses',
  templateUrl: './recommended-courses.component.html',
  styleUrls: ['./recommended-courses.component.css']
})
export class RecommendedCoursesComponent implements OnInit, OnDestroy {
  private subscription: any;
  public recommendedCourses: any;
  public loading: boolean;
  BaseUrl: string;
  deafultCourseImgUrl: string;
  public noData: any;

  constructor(private courses_service: CoursesService) { }

  ngOnInit() {
    // this.BaseUrl = window['appConfig'].apiBaseUrl;
    // this.deafultCourseImgUrl = window['appConfig'].deafultCourseImgUrl;
    this.loading = true;
    this.subscription = this.courses_service.GetRecommendedCourses()
      .subscribe( resp => {
          this.recommendedCourses = resp['data'];
          console.log(this.recommendedCourses);

          this.noData = false;
          if (this.recommendedCourses.length === 0) {
            setTimeout(() => {
              this.noData = true;
              this.loading = false;
            }, 2000);
          }
        },
        error => {
          console.log('oops', error);
          console.log('message', error.message);
        }
      );
  }
  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

}
