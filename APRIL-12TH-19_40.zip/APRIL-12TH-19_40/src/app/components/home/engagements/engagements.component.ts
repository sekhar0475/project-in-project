import { Component, OnInit, OnDestroy } from '@angular/core';
import { CoursesService } from '../../../services/courses.service';

@Component({
  selector: 'app-engagements',
  templateUrl: './engagements.component.html',
  styleUrls: ['./engagements.component.css']
})
export class EngagementsComponent implements OnInit, OnDestroy {
  private subscription: any;
  public chanelList: any;
  public subAcademies: any;
  public subAcademy_id: number;
  public loading: boolean;
  BaseUrl: string;
  deafultCourseImgUrl: string;

  constructor(private courses_service: CoursesService) { }

  ngOnInit() {
    this.BaseUrl = window['appConfig'].apiBaseUrl;
    this.deafultCourseImgUrl = window['appConfig'].deafultCourseImgUrl;
    this.loading = true;
    this.subscription = this.courses_service.getChanelList()
      .subscribe( resp => {
        this.chanelList = resp['data'];
        this.loading = false;
      });

      // this.getSubacademyDeatils(this.subAcademy_id);
  }

  getSubacademyDeatils(subAcademyId: number) {
    this.subAcademy_id = subAcademyId;
    this.courses_service.getSubAcademy(this.subAcademy_id)
      .subscribe(
        resp => {
            this.subAcademies = resp['data'];
            this.loading = false;
        }
    );
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

}
