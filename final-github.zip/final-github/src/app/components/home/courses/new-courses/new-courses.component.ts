import { Component, OnInit, OnDestroy } from '@angular/core';
import { CoursesService } from '../../../../services/courses.service';
import { environment } from '../../../../../environments/environment';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-new-courses',
  templateUrl: './new-courses.component.html',
  styleUrls: ['./new-courses.component.css']
})
export class NewCoursesComponent implements OnInit, OnDestroy {
  public newCourses:  any;
  public loading: boolean = false;
  BaseUrl: string;
  deafultCourseImgUrl: string;
  errorPresent: boolean;
  public error_message: string;
  private unsubscribe: Subject<void> = new Subject();

  constructor(private courses_service: CoursesService) { }
   ngOnInit() {
    this.BaseUrl = environment.apiBaseUrl;
    this.deafultCourseImgUrl = environment.deafultCourseImgUrl;
    this.courses_service.getNewCourses()
    .pipe(takeUntil(this.unsubscribe))
    .subscribe( resp => {
        this.loading = true;
        setTimeout(() => {
          this.newCourses = resp['data'];
          this.loading = false;
        }, 1000);
      }, error => {
        this.errorPresent = true;
        this.error_message = error;
      });
  }
  ngOnDestroy(): void {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }
}
