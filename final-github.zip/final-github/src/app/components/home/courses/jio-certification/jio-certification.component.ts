import { Component, OnInit, OnDestroy } from '@angular/core';
import { CoursesService } from '../../../../services/courses.service';
import { environment } from '../../../../../environments/environment';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-jio-certification',
  templateUrl: './jio-certification.component.html',
  styleUrls: ['./jio-certification.component.css']
})
export class JioCertificationComponent implements OnInit, OnDestroy {
  public academicCourses: any;
  public loading: boolean = false;
  BaseUrl: string;
  deafultCourseImgUrl: string;
  public noData: any = true;
  public error_message: string;
  ceritication_title: string;
  errorPresent: boolean = false;
  private unsubscribe: Subject<void> = new Subject();

  constructor(private courses_service: CoursesService) {}
  ngOnInit() {
    this.deafultCourseImgUrl = environment.deafultCourseImgUrl;
    this.BaseUrl = environment.apiBaseUrl;
    this.courses_service.getAcademicCourses()
    .pipe(takeUntil(this.unsubscribe))
    .subscribe(
      resp => {
        this.loading = true;
        setTimeout(() => {
          this.ceritication_title = resp['heading'][0];
          this.academicCourses = resp['data'];
          this.loading = false;
        }, 200);
      },
      error => {
        this.errorPresent = true;
        this.error_message = error;
      }
    );
  }

  all_certification_courses() {
    if (this.ceritication_title) {
      window.location.href = this.BaseUrl + '/employee/academies/courses?type=' + this.ceritication_title;
    } else {
      window.location.href = this.BaseUrl;
    }
  }

  ngOnDestroy(): void {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }
}
