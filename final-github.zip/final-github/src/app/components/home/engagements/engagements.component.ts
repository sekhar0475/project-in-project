import { Component, OnInit, OnDestroy } from '@angular/core';
// import { CoursesService } from '../../../services/courses.service';
// import { environment } from '../../../../environments/environment';
// import { Subject } from 'rxjs';
// import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-engagements',
  templateUrl: './engagements.component.html',
  styleUrls: ['./engagements.component.css']
})
export class EngagementsComponent implements OnInit, OnDestroy {
  // private subscription: any;
  // public loading: boolean = false;
  // BaseUrl: string;
  // deafultCourseImgUrl: string;
  // public error_message: string;
  // errorPresent: boolean = false;
  // private unsubscribe: Subject<void> = new Subject();

  // constructor(private courses_service: CoursesService) { }
  constructor() { }
  ngOnInit() {
    // this.BaseUrl = environment.apiBaseUrl;
    // this.deafultCourseImgUrl = environment.deafultCourseImgUrl;
    // this.academy_selected = false;
    // this.subscription = this.courses_service.GetAcademyList()
    //   .pipe(takeUntil(this.unsubscribe))
    //   .subscribe( resp => {
    //     this.loading = true;
    //       setTimeout(() => {
    //         this.chanelList = resp['data'];
    //         this.loading = false;
    //       }, 1000);
    //   }, error => {
    //     this.errorPresent = true;
    //     this.error_message = error;
    //   });
  }

  ngOnDestroy(): void {
    // this.unsubscribe.next();
    // this.unsubscribe.complete();
  }

}
