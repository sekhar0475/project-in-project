import { Component, OnInit, OnDestroy } from '@angular/core';
import { CoursesService } from '../../../services/courses.service';
import { environment } from '../../../../environments/environment';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-catalog',
  templateUrl: './catalog.component.html',
  styleUrls: ['./catalog.component.css']
})
export class CatalogComponent implements OnInit, OnDestroy {
  private subscription: any;
  public chanelList: any;
  public subAcademies: any;
  public subAcademy_id: number;
  public loading: boolean = false;
  BaseUrl: string;
  deafultCourseImgUrl: string;
  public academy_selected: boolean;
  changeDirection: boolean;
  currentIndex: number;
  public error_message: string;
  errorPresent: boolean = false;
  public subcategory_error_message: string;
  subcategory_errorPresent: boolean;
  private unsubscribe: Subject<void> = new Subject();

  constructor(private courses_service: CoursesService) { }

  ngOnInit() {
    this.BaseUrl = environment.apiBaseUrl;
    this.deafultCourseImgUrl = environment.deafultCourseImgUrl;
    this.academy_selected = false;
    this.subscription = this.courses_service.GetAcademyList()
      .pipe(takeUntil(this.unsubscribe))
      .subscribe( resp => {
        this.loading = true;
          setTimeout(() => {
            this.chanelList = resp['data'];
            this.loading = false;
          }, 1000);
      }, error => {
        this.errorPresent = true;
        this.error_message = error;
      });
  }
  getSubacademyDeatils(subAcademyId: number, index: number) {
    this.subAcademies = [];
    this.currentIndex = index;
    this.changeDirection = !this.changeDirection;
    this.subAcademy_id = subAcademyId;
    this.subcategory_errorPresent = false;
    this.subscription = this.courses_service.getSubAcademy(this.subAcademy_id)
            .pipe(takeUntil(this.unsubscribe))
            .subscribe(
              resp => {
                this.subAcademies = resp['data'];
                if (!this.subAcademies.length) {
                  this.subcategory_errorPresent = true;
                  this.subcategory_error_message = 'No sub catageroies...!';
                }
              }, error => {
                this.subcategory_errorPresent = true;
                this.subcategory_error_message = error;
              }
          );
  }

  ngOnDestroy(): void {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }

}
