import { Component, OnInit, OnDestroy } from '@angular/core';
import {Input} from '@angular/core';

import { CoursesService } from '../../../../../services/courses.service';

@Component({
  selector: 'app-leadership',
  templateUrl: './leadership.component.html',
  styleUrls: ['./leadership.component.css']
})
export class LeadershipComponent implements OnInit, OnDestroy {
  private subscription: any;
  public leadershipCourses:  any;
  public loading: boolean;
  public noData: boolean;
  public noDomainId: boolean;
  deafultCourseImgUrl: string;
  public error_message: string;

  constructor(private courses_service: CoursesService) {}
  ngOnInit() {
    this.deafultCourseImgUrl = window['appConfig'].deafultCourseImgUrl;
    this.loading = true;
    this.noData = false;
    this.subscription = this.courses_service.getLeadershipCourses()
      .subscribe( resp => {
            this.leadershipCourses = resp['data'];
            console.log(this.leadershipCourses);
          },
          error => {
              console.log(error);
              setTimeout(() => {
                if (error.error['success'] === false && error.error.errors[0]['code'] === 401) {
                  this.error_message = 'No courses assigned';
                  this.noData = true;
                  this.loading = false;
                } else if (error.error['success'] === false && error.error.errors[0]['code'] === 404) {
                  // this.error_message = 'domain id is required';
                  this.error_message = 'No Records Found';
                  this.noDomainId = true;
                  this.loading = false;
                } else {
                  this.error_message = 'Server side problem';
                }
              }, 2000);
          }
      );
  }
  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

}

