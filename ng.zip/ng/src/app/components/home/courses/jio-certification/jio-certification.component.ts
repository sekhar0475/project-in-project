import { Component, OnInit, OnDestroy } from '@angular/core';
import { CoursesService } from '../../../../services/courses.service';

@Component({
  selector: 'app-jio-certification',
  templateUrl: './jio-certification.component.html',
  styleUrls: ['./jio-certification.component.css']
})
export class JioCertificationComponent implements OnInit, OnDestroy {
  private subscription: any;
  public academicCourses: any;
  public loading: boolean;
  deafultCourseImgUrl: string;
  public noData: any;
  public noDomainId: boolean;
  public error_message: string;

  constructor(private courses_service: CoursesService) { }
    ngOnInit() {
    this.deafultCourseImgUrl = window['appConfig'].deafultCourseImgUrl;
    this.loading = true;
    this.subscription = this.courses_service.getAcademicCourses()
      .subscribe( resp => {
        this.academicCourses = resp['data'];
        console.log(this.academicCourses);
        this.loading = false;
      },
      error => {
        setTimeout(() => {
          if (error.error['success'] === false && error.error.errors[0]['code'] === 401) {
            this.error_message = 'There are no Recommended Courses assigned to you. Thankyou !';
            this.noData = true;
            this.loading = false;
          } else if (error.error['success'] === false && error.error.errors[0]['code'] === 404) {
            // this.error_message = 'domain id is required';
            this.error_message = 'No Records Found';
            this.noDomainId = true;
            this.loading = false;
          }
        }, 2000);
      }
    );
  }

  ngOnDestroy(): void { this.subscription.unsubscribe(); }

}
