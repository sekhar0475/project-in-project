import { Component, OnInit, OnDestroy } from '@angular/core';
import { CoursesService } from '../../../services/courses.service';

@Component({
  selector: 'app-engagements',
  templateUrl: './engagements.component.html',
  styleUrls: ['./engagements.component.css']
})
export class EngagementsComponent implements OnInit, OnDestroy {
  private subscription: any;
  public chanelList: any;
  public subAcademies: any;
  public subAcademy_id: number;
  public loading: boolean;
  BaseUrl: string;
  deafultCourseImgUrl: string;
  public academy_selected: boolean;
  changeDirection: number;

  constructor(private courses_service: CoursesService) { }

  ngOnInit() {
    this.BaseUrl = window['appConfig'].apiBaseUrl;
    this.deafultCourseImgUrl = window['appConfig'].deafultCourseImgUrl;
    this.loading = true;
    this.academy_selected = false;
    this.subscription = this.courses_service.getChanelList()
      .subscribe( resp => {
        this.chanelList = resp['data'];
        this.loading = false;
      });
  }

  getSubacademyDeatils(subAcademyId: number, index: number) {
    this.subAcademies = [];
    this.changeDirection = index;
    this.loading = true;
    this.subAcademy_id = subAcademyId;
    this.subscription = this.courses_service.getSubAcademy(this.subAcademy_id)
                          .subscribe(
                            resp => {
                                this.subAcademies = resp['data'];
                                console.log(this.subAcademies);
                                this.loading = false;
                            }
                        );
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

}
