import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  styleUrls: ['app.component.scss'],
  template: `
    <div class="app">
      <pizza-app></pizza-app>
    </div>
  `
})
export class AppComponent {}
