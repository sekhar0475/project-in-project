import { Component, OnInit, Input } from '@angular/core';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'course-view',
  templateUrl: './course-view.component.html',
  styleUrls: ['./course-view.component.css']
})
export class CourseViewComponent implements OnInit {
  deafultCourseImgUrl: string;
  @Input() public courses: any;

  constructor() { }

  ngOnInit() {
    this.deafultCourseImgUrl = window['appConfig'].deafultCourseImgUrl;
  }

}
