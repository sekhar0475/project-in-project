import { Component, OnInit, OnDestroy } from '@angular/core';
import { CoursesService } from '../../../../services/courses.service';
import { PerfectScrollbarConfigInterface,
  PerfectScrollbarComponent, PerfectScrollbarDirective } from 'ngx-perfect-scrollbar';
import { trigger, transition, useAnimation } from '@angular/animations';

@Component({
  selector: 'app-icertification',
  templateUrl: './icertification.component.html',
  styleUrls: ['./icertification.component.css']
})
export class IcertificationComponent implements OnInit, OnDestroy {
  private subscription: any;
  public BaseUrl: string;
  deafultCourseImgUrl: string;
  public learning_plan_status: any;
  public learning_plan_status_value: any;
  public i_certify_button: boolean;
  public is_certified: boolean;
  public loading: boolean;
  public config: PerfectScrollbarConfigInterface;
  public noDomainId: boolean;
  public apiBaseUrl: string;
  public noData: any;
  public iCertifyStatus: string;
  btn_active: boolean = false;

  constructor(private courses_service: CoursesService) { }
  ngOnInit() {
    this.BaseUrl = window['appConfig'].apiBaseUrl;
    this.deafultCourseImgUrl = window['appConfig'].deafultCourseImgUrl;
    this.loading = true;
    this.noData = false;
    this.iCertifyStatus = 'false';
    this.is_certified = false;
    this.subscription = this.courses_service.GetLearningPlanStatus()
      .subscribe( resp => {
          this.noDomainId = false;
          this.learning_plan_status = resp['data'].filter(item => item.class_type === 'Ready for Role');
          this.learning_plan_status_value = this.learning_plan_status[0].status;
          this.iCertifyStatus = resp['iCertifyFlag'];
          if (this.learning_plan_status_value === 100  && (this.iCertifyStatus === 'false')) {
            this.btn_active = true;
            this.is_certified = false;
          } else if (this.learning_plan_status_value === 100  && (this.iCertifyStatus === 'true')) {
            this.is_certified = true;
          } else if (this.iCertifyStatus === 'true') {
            this.is_certified = true;
          } else {
            console.log('Courses are in progress, need to complete all');
          }
        },
        error => {
          setTimeout(() => {
            this.loading = false;
            this.noDomainId = true;
          }, 1000);
        });
  }

  icertify() {
    if (this.iCertifyStatus === 'false' && this.btn_active === true) {
        this.subscription = this.courses_service.iCertify()
        .subscribe( resp => { this.is_certified = true; }, error => {console.log('Problem with cerification'); });
    } else { console.log('Already successfully certified'); }
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
}
