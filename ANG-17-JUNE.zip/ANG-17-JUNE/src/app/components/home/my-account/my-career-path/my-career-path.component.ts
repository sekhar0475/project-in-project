import { Component, OnInit, Input, OnDestroy } from '@angular/core';
import { CoursesService } from '../../../../services/courses.service';

@Component({
  selector: 'app-my-career-path',
  templateUrl: './my-career-path.component.html',
  styleUrls: ['./my-career-path.component.css']
})
export class MyCareerPathComponent implements OnInit {
  BaseUrl: string;
  deafultCourseImgUrl: string;
  public apiBaseUrl: string;

  @Input() myCareerPath: any;
  @Input() loading: boolean ;
  @Input() errorPresent: boolean;
  @Input() error_message: string;
  @Input() noData: boolean = true;

  constructor(private courses_service: CoursesService) { }

  ngOnInit() {
    this.BaseUrl = window['appConfig'].apiBaseUrl;
    this.deafultCourseImgUrl = window['appConfig'].deafultCourseImgUrl;
  }

  all_my_career_path() {
    window.location.href = this.BaseUrl + '/employee/career_path?title=&type=Learning Path';
  }

}
