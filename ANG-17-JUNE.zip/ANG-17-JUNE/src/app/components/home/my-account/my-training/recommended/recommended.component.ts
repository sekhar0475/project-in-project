import { Component, OnInit, OnDestroy } from '@angular/core';
import { CoursesService } from '../../../../../services/courses.service';

@Component({
  selector: 'app-recommended',
  templateUrl: './recommended.component.html',
  styleUrls: ['./recommended.component.css']
})
export class RecommendedComponent implements OnInit, OnDestroy {
  private subscription: any;
  public recommendedCourses: any;
  public loading: boolean = false;
  public apiBaseUrl: string;
  deafultCourseImgUrl: string;
  public error_message: string;
  errorPresent: boolean;

  constructor(private courses_service: CoursesService) { }

  ngOnInit() {
    this.apiBaseUrl = window['appConfig'].apiBaseUrl;
    this.deafultCourseImgUrl = window['appConfig'].deafultCourseImgUrl;
    this.subscription = this.courses_service.getRecommendedCourses()
      .subscribe( resp => {
            this.loading = true;
            setTimeout(() => {
              this.recommendedCourses = resp['data'];
              this.loading = false;
            }, 1000);
          },
          error => {
            this.errorPresent = true;
            this.error_message = error;
          }
      );

  }
  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

}
