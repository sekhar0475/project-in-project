import { Component, OnInit, OnDestroy } from '@angular/core';
import { CoursesService } from '../../../../services/courses.service';
// import { custom-date.pipe.ts} from '../../../../pipes/custom-date.pipe';

@Component({
  selector: 'app-popular-courses',
  templateUrl: './popular-courses.component.html',
  styleUrls: ['./popular-courses.component.css']
})
export class PopularCoursesComponent implements OnInit, OnDestroy {

  private subscription: any;
  public popularCourses: any;
  public loading: boolean = false;
  BaseUrl: string;
  deafultCourseImgUrl: string;
  errorPresent: boolean;
  public error_message: string;

  constructor(private courses_service: CoursesService) { }

  ngOnInit() {
    this.BaseUrl = window['appConfig'].apiBaseUrl;
    this.deafultCourseImgUrl = window['appConfig'].deafultCourseImgUrl;
    this.subscription = this.courses_service.getPopularCourses().subscribe( resp => {
        this.loading = true;
        setTimeout(() => {
          this.popularCourses = resp['data'];
          this.loading = false;
        }, 1500);
      }, error => {
        this.errorPresent = true;
        this.error_message = error;
      }
    );
  }
  ngOnDestroy(): void { this.subscription.unsubscribe(); }
}
