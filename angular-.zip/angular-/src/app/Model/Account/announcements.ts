export interface Announcements {
    nid: string;
    title: string;
    body: string;
    post_date: string;
    link: string;
}
