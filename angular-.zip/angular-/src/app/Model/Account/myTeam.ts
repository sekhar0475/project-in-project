export interface Teammember {
    SlNo: number;
    user_id: string;
    emp_name: string;
    course_count: number;
    completed_course: number;
    percentage: number;
    myteam_url: string;
}

export interface MyTeamData {
    teamcount: number;
    teammembers: Teammember[];
}

export interface MyTeam {
    status: number;
    message: string;
    data: MyTeamData;
}
