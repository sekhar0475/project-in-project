export interface Safe {
    title: string;
    given: string;
    family: string;
}

export interface Sender {
    title: string;
    given: string;
    family: string;
    safe: Safe;
}

export interface MyRecommendedData {
    cid: string;
    reco_to_uid: string;
    reco_by_uid: string;
    sender: Sender;
    type: string;
    accept_status: string;
    title: string;
    published_date: string;
    image_path: string;
    titlelink: string;
    duration: string;
    description: string;
}

export interface MyRecommended {
    status: number;
    message: string;
    data: MyRecommendedData[];
}


