export interface ClassTypeData {
    ClasstypeID: string;
    ClasstypeName: string;
    ClasstypeDescription?: any;
    ClasstypelLink: string;
}

export interface ClassTypeList {
    status: number;
    message: string;
    data: ClassTypeData[];
}
