export interface AcademyListData {
    ChannelID: string;
    ChannelName: string;
}

export interface AcademyList {
    status: number;
    message: string;
    data: AcademyListData[];
}

