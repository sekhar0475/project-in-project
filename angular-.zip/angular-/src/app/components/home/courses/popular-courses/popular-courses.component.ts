import { Component, OnInit, OnDestroy } from '@angular/core';
import { CoursesService } from '../../../../services/courses.service';
// import { custom-date.pipe.ts} from '../../../../pipes/custom-date.pipe';
import { environment } from '../../../../../environments/environment';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-popular-courses',
  templateUrl: './popular-courses.component.html',
  styleUrls: ['./popular-courses.component.css']
})
export class PopularCoursesComponent implements OnInit, OnDestroy {

  private subscription: any;
  public popularCourses: any;
  public loading: boolean = false;
  BaseUrl: string;
  deafultCourseImgUrl: string;
  errorPresent: boolean;
  public error_message: string;
  private unsubscribe: Subject<void> = new Subject();

  constructor(private courses_service: CoursesService) { }

  ngOnInit() {
    this.BaseUrl = environment.apiBaseUrl;
    this.deafultCourseImgUrl = environment.deafultCourseImgUrl;
    this.subscription = this.courses_service.getPopularCourses()
    .pipe(takeUntil(this.unsubscribe))
    .subscribe( resp => {
        this.loading = true;
        setTimeout(() => {
          this.popularCourses = resp['data'];
          this.loading = false;
        }, 1500);
      }, error => {
        this.errorPresent = true;
        this.error_message = error;
      }
    );
  }
  ngOnDestroy(): void {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }
}
