import { Component, OnInit } from '@angular/core';
import { environment } from '../../../../../environments/environment';
import { CoursesService } from '../../../../services/courses.service';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-announcements',
  templateUrl: './announcements.component.html',
  styleUrls: ['./announcements.component.css']
})
export class AnnouncementsComponent implements OnInit {
  private subscription: any;
  private unsubscribe: Subject<void> = new Subject();
  myAnnouncementsData: any;
  errorPresent: boolean;
  constructor(private courses_service: CoursesService) { }

  ngOnInit() {
    this.errorPresent = false;
    this.subscription = this.courses_service.GetmyAnnouncementsData()
      .pipe(takeUntil(this.unsubscribe))
      .subscribe(
        resp => {
          this.myAnnouncementsData = resp;
        },
        err => { this.errorPresent = true; }
    );
  }

}
