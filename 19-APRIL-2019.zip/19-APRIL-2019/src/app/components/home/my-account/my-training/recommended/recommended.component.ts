import { Component, OnInit, OnDestroy } from '@angular/core';
import { CoursesService } from '../../../../../services/courses.service';

@Component({
  selector: 'app-recommended',
  templateUrl: './recommended.component.html',
  styleUrls: ['./recommended.component.css']
})
export class RecommendedComponent implements OnInit, OnDestroy {
  private subscription: any;
  public recommendedCourses: any;
  public percent: number;
  public loading: boolean;
  public noDomainId: boolean;
  public apiBaseUrl: string;
  deafultCourseImgUrl: string;
  public noData: any;
  public error_message: string;

  constructor(private courses_service: CoursesService) { }

  ngOnInit() {
    this.apiBaseUrl = window['appConfig'].apiBaseUrl;
    this.deafultCourseImgUrl = window['appConfig'].deafultCourseImgUrl;
    this.loading = true;
    this.noDomainId = false;
    this.noData = false;
    this.subscription = this.courses_service.getRecommendedCourses()
      .subscribe( resp => {
            this.recommendedCourses = resp['data'];
          },
          error => {
              setTimeout(() => {
                if (error.error['success'] === false && error.error.errors[0]['code'] === 401) {
                  this.error_message = 'No courses assigned';
                  this.noData = true;
                  this.loading = false;
                } else if (error.error['success'] === false && error.error.errors[0]['code'] === 404) {
                  // this.error_message = 'domain id is required';
                  this.error_message = 'No Records Found';
                  this.noDomainId = true;
                  this.loading = false;
                }
              }, 2000);
          }
      );

  }
  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

}
