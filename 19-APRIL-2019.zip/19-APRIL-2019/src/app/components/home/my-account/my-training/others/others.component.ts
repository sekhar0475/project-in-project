import { Component, OnInit, OnDestroy } from '@angular/core';
import {Input} from '@angular/core';

import { CoursesService } from '../../../../../services/courses.service';

@Component({
  selector: 'app-others',
  templateUrl: './others.component.html',
  styleUrls: ['./others.component.css']
})
export class OthersComponent implements OnInit, OnDestroy {
  private subscription: any;
  public othersCourses:  any;
  public loading: boolean;
  public noData: boolean;
  public noDomainId: boolean;
  deafultCourseImgUrl: string;
  public error_message: string;

  constructor(private courses_service: CoursesService) {}
  ngOnInit() {
    this.deafultCourseImgUrl = window['appConfig'].deafultCourseImgUrl;
    this.loading = true;
    this.noData = false;
    this.subscription = this.courses_service.getOthersCourses()
      .subscribe( resp => {
          this.othersCourses = resp['data'];
        },
        error => {
            setTimeout(() => {
              if (error.error['success'] === false && error.error.errors[0]['code'] === 401) {
                this.error_message = 'No courses assigned';
                this.noData = true;
                this.loading = false;
              } else if (error.error['success'] === false && error.error.errors[0]['code'] === 404) {
                // this.error_message = 'domain id is required';
                this.error_message = 'No Records Found';
                this.noDomainId = true;
                this.loading = false;
              }
            }, 2000);
        }
      );
  }
  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

}
