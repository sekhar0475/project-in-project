import { Component, OnInit, OnDestroy } from '@angular/core';
import { CoursesService } from '../../../../services/courses.service';
import { PerfectScrollbarConfigInterface,
  PerfectScrollbarComponent, PerfectScrollbarDirective } from 'ngx-perfect-scrollbar';
import { Response } from 'selenium-webdriver/http';

@Component({
  selector: 'app-icertification',
  templateUrl: './icertification.component.html',
  styleUrls: ['./icertification.component.css']
})
export class IcertificationComponent implements OnInit, OnDestroy {
  private subscription: any;
  public BaseUrl: string;
  deafultCourseImgUrl: string;
  public learning_plan_status: any;
  public learning_plan_status_value: any;
  public i_certify_button: boolean;
  public is_certified: boolean;
  public loading: boolean;
  public config: PerfectScrollbarConfigInterface;
  public noDomainId: boolean;
  public apiBaseUrl: string;
  public noData: any;
  public iCertifyStatus: boolean;

  constructor(private courses_service: CoursesService) { }
  ngOnInit() {
    this.BaseUrl = window['appConfig'].apiBaseUrl;
    this.deafultCourseImgUrl = window['appConfig'].deafultCourseImgUrl;
    this.loading = true;
    this.noData = false;
    this.iCertifyStatus = false;
    this.is_certified = false;
    this.subscription = this.courses_service.GetLearningPlanStatus()
      .subscribe( resp => {
          this.noDomainId = false;
          this.learning_plan_status = resp['data'].filter(item => item.class_type === 'Ready for Role');
          this.learning_plan_status_value = this.learning_plan_status[0].status;
          if (this.learning_plan_status_value === 100) {
            this.iCertifyStatus = true;
          }
          this.is_certified = resp['iCertifyFlag'];
        },
        error => {
          setTimeout(() => {
            this.loading = false;
            this.noDomainId = true;
          }, 2000);
        });
  }

  icertify() {
    if (this.iCertifyStatus) {
      this.subscription = this.courses_service.iCertify()
        .subscribe( resp => {
          },
          error => {
          });
      } else {
      }
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
}
