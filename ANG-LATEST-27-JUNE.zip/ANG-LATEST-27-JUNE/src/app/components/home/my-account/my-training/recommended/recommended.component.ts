import { Component, OnInit, OnDestroy } from '@angular/core';
import { CoursesService } from '../../../../../services/courses.service';
import { environment } from '../../../../../../environments/environment';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-recommended',
  templateUrl: './recommended.component.html',
  styleUrls: ['./recommended.component.css']
})
export class RecommendedComponent implements OnInit, OnDestroy {
  private subscription: any;
  public recommendedCourses: any;
  public loading: boolean = false;
  public apiBaseUrl: string;
  deafultCourseImgUrl: string;
  public error_message: string;
  errorPresent: boolean;
  private unsubscribe: Subject<void> = new Subject();

  constructor(private courses_service: CoursesService) { }
  ngOnInit() {
    this.apiBaseUrl = environment.apiBaseUrl;
    this.deafultCourseImgUrl = environment.deafultCourseImgUrl;
    this.subscription = this.courses_service.getRecommendedCourses()
      .pipe(takeUntil(this.unsubscribe))
      .subscribe( resp => {
            this.loading = true;
            if (resp['data'].length) {
              setTimeout(() => {
                this.recommendedCourses = resp['data'];
                this.loading = false;
              }, 1000);
            } else {
              this.loading = false;
              this.errorPresent = true;
              this.error_message = 'No records found';
            }
          },
          error => {
            this.errorPresent = true;
            this.error_message = error;
          }
      );

  }
  ngOnDestroy(): void {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }

}
