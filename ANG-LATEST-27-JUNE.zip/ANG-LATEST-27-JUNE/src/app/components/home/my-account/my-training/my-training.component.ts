import { Component, OnInit, OnDestroy } from '@angular/core';
import { CoursesService } from '../../../../services/courses.service';
import { PerfectScrollbarConfigInterface,
  PerfectScrollbarComponent, PerfectScrollbarDirective } from 'ngx-perfect-scrollbar';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-my-training',
  templateUrl: './my-training.component.html',
  styleUrls: ['./my-training.component.css']
})
export class MyTrainingComponent implements OnInit, OnDestroy {
  private subscription: any;
  public displayMyTrainingRoutes: string = 'Ready for role';
  public learningLearningPlanStatus:  any;
  public config: PerfectScrollbarConfigInterface;

  readyforroleTabId: number;
  mandatoryTabId: number;
  recommendedTabId: number;
  selectedTabId: number;
  private unsubscribe: Subject<void> = new Subject();

  constructor(private courses_service: CoursesService) {

    this.readyforroleTabId = window['appConfig'].readyFor;
    this.mandatoryTabId = window['appConfig'].mandatory;
    this.recommendedTabId = window['appConfig'].recommended;

    this.selectedTabId = this.readyforroleTabId;
   }

  ngOnInit() {
    this.subscription = this.courses_service.GetLearningPlanStatus()
      .pipe(takeUntil(this.unsubscribe))
      .subscribe( resp => (this.learningLearningPlanStatus = resp['data'])
    );
  }
  goToAllCourses(paramValue: number): void {
    this.courses_service.navigateToUrl(paramValue);
  }

  ngOnDestroy(): void {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }
}

