import { Component, OnInit, OnDestroy } from '@angular/core';
import { CoursesService } from '../../../../../services/courses.service';
import { environment } from '../../../../../../environments/environment';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-leadership',
  templateUrl: './leadership.component.html',
  styleUrls: ['./leadership.component.css']
})
export class LeadershipComponent implements OnInit, OnDestroy {
  private subscription: any;
  public leadershipCourses:  any;
  public loading: boolean = false;
  deafultCourseImgUrl: string;
  public error_message: string;
  errorPresent: boolean;
  private unsubscribe: Subject<void> = new Subject();

  constructor(private courses_service: CoursesService) {}
  ngOnInit() {
    this.deafultCourseImgUrl = environment.deafultCourseImgUrl;
    this.subscription = this.courses_service.getLeadershipCourses()
      .pipe(takeUntil(this.unsubscribe))
      .subscribe( resp => {
            this.loading = true;
            if (resp['data'].length) {
              setTimeout(() => {
                this.leadershipCourses = resp['data'];
                this.loading = false;
              }, 1000);
            } else {
              this.loading = false;
              this.errorPresent = true;
              this.error_message = 'No records found';
            }
          },
          error => {
              this.errorPresent = true;
              this.error_message = error;
          }
      );
  }
  ngOnDestroy(): void {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }

}

