// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  apiBaseUrl : window['appConfig'].apiBaseUrl,
  getPopularCourseUrl : window['appConfig'].getPopularCourse,
  getNewCoursesUrl : window['appConfig'].getNewCourse,
  getMyTeamsUrl : window['appConfig'].getMyTeam,
  getLearningTypeCoursesUrl :  window['appConfig'].getLearningTypeCourses,
  getLearningTabsUrl :  window['appConfig'].getLearningTabs,
  getMyCareerPathUrl :  window['appConfig'].MyCareerPath,
  getAcademicCoursesUrl : window['appConfig'].getAcademicCourses,
  GetAcademyListUrl : window['appConfig'].GetAcademyList,
  getSubAcademyUrl : window['appConfig'].getSubAcademy,
  myRecommendationUrl : window['appConfig'].myRecommendation,
  icertifyUrl : window['appConfig'].icertify,
  doaminID : window['appConfig'].domainId,
  deafultCourseImgUrl : window['appConfig'].deafultCourseImgUrl,
  readyforroleTabId : window['appConfig'].readyFor,
  mandatoryTabId : window['appConfig'].mandatory,
  recommendedTabId : window['appConfig'].recommended,
  leadershipTabId : window['appConfig'].leadership,
  specialTabId : window['appConfig'].special,
  othersTabId : window['appConfig'].others,
  getAllCoursesUrl : window['appConfig'].EmployeeCourseUrl,
  teamMemberImg : window['appConfig'].teamMemberImgUrl
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
