export interface MyCareerPathData {
imgname: string;
class_nid: string;
Title: string;
TitleLink: string;
}

export interface MyCareerPath {
status: number;
message: string;
data: MyCareerPathData[];
}
