export interface LearningTypeCourseData {
    class_nid: string;
    class_type: string;
    class_title: string;
    course_nid: string;
    course_img?: any;
    course_title: string;
    course_description: string;
    course_link: string;
    course_level: string;
    course_duration: string;
    publish_date: string;
    course_validity: string;
    lesson_count: number;
    course_completion_status: number;
}

export interface LearningTypeCourses {
    status: number;
    message: string;
    course_count: number;
    data: LearningTypeCourseData[];
}



