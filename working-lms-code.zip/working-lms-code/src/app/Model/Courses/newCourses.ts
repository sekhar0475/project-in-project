export interface NewCourseData {
    imgname?: any;
    Title: string;
    TitleLink: string;
    Description: string;
    CourseLevel: string;
    CourseDuration: string;
    PublishDate: string;
}

export interface NewCourses {
    status: number;
    message: string;
    data: NewCourseData[];
}
