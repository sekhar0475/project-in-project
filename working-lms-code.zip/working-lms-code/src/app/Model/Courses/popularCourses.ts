export interface PopularCourseData {
    imgname?: any;
    Title: string;
    TitleLink: string;
    Description: string;
    CourseLevel?: any;
    CourseDuration: string;
    PublishDate: string;
}

export interface PopularCourses {
    status: number;
    message: string;
    data: PopularCourseData[];
}
