export interface AcademicCoursesData {
    tid: string;
    name: string;
    title: string;
    nid: string;
    created: string;
    vid: string;
    changed: string;
    body_value: string;
    uri: string;
    field_course_duration_value: string;
    opigno_course_categories_tid: string;
    course_link: string;
}

export interface AcademicCourses {
    status: number;
    message: string;
    heading: string[];
    data: AcademicCoursesData[];
}

