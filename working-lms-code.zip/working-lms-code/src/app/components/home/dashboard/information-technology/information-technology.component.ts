import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-information-technology',
  templateUrl: './information-technology.component.html',
  styleUrls: ['./information-technology.component.css']
})
export class InformationTechnologyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
