import { Component, OnInit, OnDestroy } from '@angular/core';
import { CoursesService } from './../../../services/courses.service';

@Component({
  selector: 'app-my-account',
  templateUrl: './my-account.component.html',
  styleUrls: ['./my-account.component.css']
})
export class MyAccountComponent implements OnInit, OnDestroy {
  subscription: any;

  my_team: boolean = false;
  my_career: boolean = false;

  public myTeamData: any;
  public mt_loading: boolean = false;
  public mt_error_message: string;
  mt_errorPresent: boolean;
  mt_noData: boolean = true;


  public mc_error_message: string;
  mc_errorPresent: boolean;
  mc_noData: boolean = true;
  public myCareerPath: any;
  public mc_loading: boolean;

  constructor(private courses_service: CoursesService) {}
  ngOnInit() {
    this.subscription = this.courses_service.getMyTeam().subscribe(
      resp => {
        if (resp['data']['teamcount'] > 0) {
          this.my_team = true;
          this.mt_noData = false;
          this.mt_loading = true;
          setTimeout(() => {
            this.myTeamData = resp['data']['teammembers'];
            this.mt_loading = false;
          }, 1000);
        } else {
          this.mt_loading = false;
          this.mt_errorPresent = true;
          this.mt_error_message = 'No records found';
        }
      },
      error => {
        this.mt_errorPresent = true;
        this.mt_error_message = error;
      }
    );
    this.subscription = this.courses_service.getMyCareerPath().subscribe( resp => {
        this.mc_noData = false;
        this.mc_loading = true;
        if (resp['data'].length) {
          this.my_career = true;
          setTimeout(() => {
            this.myCareerPath = resp['data'];
            this.mc_loading = false;
          }, 1000);
        } else {
          this.mc_loading = false;
          this.mc_errorPresent = true;
          this.mc_error_message = 'No records found';
        }
      },
      error => {
        this.mc_errorPresent = true;
        this.mc_error_message = error;
      }
    );
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
}
