import { Component, OnInit, Input, OnDestroy } from '@angular/core';
import { CoursesService } from '../../../../services/courses.service';
import { environment } from '../../../../../environments/environment';

@Component({
  selector: 'app-my-career-path',
  templateUrl: './my-career-path.component.html',
  styleUrls: ['./my-career-path.component.css']
})
export class MyCareerPathComponent implements OnInit {
  BaseUrl: string;
  deafultCourseImgUrl: string;

  @Input() myCareerPath: any;
  @Input() loading: boolean ;
  @Input() errorPresent: boolean;
  @Input() error_message: string;
  @Input() noData: boolean = true;
  @Input() myCareerStatus: boolean;

  constructor(private courses_service: CoursesService) { }

  ngOnInit() {
    this.BaseUrl = environment.apiBaseUrl;
    this.deafultCourseImgUrl = environment.deafultCourseImgUrl;
  }

  all_my_career_path() {
    window.location.href = this.BaseUrl + '/employee/career_path?title=&type=Learning Path';
  }

}
