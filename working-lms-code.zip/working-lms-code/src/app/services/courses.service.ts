import { Injectable } from '@angular/core';
import {Observable, throwError, EMPTY} from 'rxjs';
import { map, filter, concatMap, catchError} from 'rxjs/operators';
import {HttpClient, HttpHeaders, HttpErrorResponse, HttpResponse } from '@angular/common/http';
import { environment } from '../../environments/environment';

import { AcademicCourses } from '../Model/Courses/academicCourses';

const headerDict = {
  'Content-Type': 'application/json',
  'Accept': 'application/json',
  'domainID': environment.doaminID,
  'X-CSRF-Token': environment.csrfToken
};
const requestOptions = {headers: new HttpHeaders(headerDict)};

@Injectable({
  providedIn: 'root'
})
export class CoursesService {
  apiBaseUrl: string;
  getPopularCourseUrl: string;
  getNewCoursesUrl: string;
  getMyTeamsUrl: string;
  getLearningTypeCoursesUrl: string;
  getLearningTabsUrl: string;
  getMyCareerPathUrl: string;
  getAcademicCoursesUrl: string;
  GetAcademyListUrl: string;
  getSubAcademyUrl: string;
  myRecommendationUrl: string;
  getAllCoursesUrl: string;
  getLearningPlanStatus: string;
  icertifyUrl: string;
  suggestedCourseDenyUrl: string;

  doaminID: string;
  deafultCourseImgUrl: string;
  teamMemberImg: string;

  getClassTypeListUrl: string;
  myAnnouncementsData: any;

  constructor(private http: HttpClient) {
    this.apiBaseUrl = environment.apiBaseUrl;
    this.getPopularCourseUrl = environment.getPopularCourseUrl;
    this.getNewCoursesUrl = environment.getNewCoursesUrl;
    this.getMyTeamsUrl = environment.getMyTeamsUrl;
    this.getLearningTypeCoursesUrl = environment.getLearningTypeCoursesUrl;
    this.getLearningTabsUrl = environment.getLearningTabsUrl;
    this.getMyCareerPathUrl = environment.getMyCareerPathUrl;
    this.getAcademicCoursesUrl = environment.getAcademicCoursesUrl;
    this.GetAcademyListUrl = environment.GetAcademyListUrl;
    this.getSubAcademyUrl = environment.getSubAcademyUrl;
    this.myRecommendationUrl = environment.myRecommendationUrl;
    this.icertifyUrl = environment.icertifyUrl;

    this.doaminID = environment.doaminID;
    this.deafultCourseImgUrl = environment.deafultCourseImgUrl;

    this.getClassTypeListUrl = environment.getClassTypeListUrl;
    this.myAnnouncementsData = environment.myAnnouncementsData;

    this.getAllCoursesUrl = environment.getAllCoursesUrl;
    this.suggestedCourseDenyUrl = this.apiBaseUrl + '/course_recommendation/course_recommendation_resources/recommendation_deny.json';
  }

  navigateToUrl(searchBy: number) {
    window.location.href = this.getAllCoursesUrl + `?type=${searchBy}`;
  }
  suggestedCoursesDeny(flagId: number, courseId: number, recoByUId: number) {
    return this.http.post(this.suggestedCourseDenyUrl, {'flag_id': flagId, 'course_id': courseId, 'sender_uid': recoByUId}, requestOptions);
  }

  getPopularCourses(): Observable<any> {
    return this.http.post(this.getPopularCourseUrl, null, requestOptions);
  }

  getNewCourses(): Observable<any> {
    return this.http.post(this.getNewCoursesUrl, null, requestOptions);
  }

  getMyTeam(): Observable<any> {
    return this.http.post(this.getMyTeamsUrl, null, requestOptions);
  }
  getClassTypeList() {
    return this.http.post(this.getClassTypeListUrl, null, requestOptions);
  }

  getClassTypeListCourses(class_type_id: number) {
    return this.http.post(this.getLearningTypeCoursesUrl, {'class_id': class_type_id}, requestOptions);
  }

  GetLearningPlanStatus() {
    return this.http.post(this.getLearningTabsUrl, null , requestOptions);
  }

 getMyCareerPath() {
    return this.http.post(this.getMyCareerPathUrl, null , requestOptions);
 }

 getAcademicCourses(): Observable<AcademicCourses[]> {
    return this.http.post<AcademicCourses[]>(this.getAcademicCoursesUrl, null , requestOptions);
 }
// getAcademicCourses() {
//   return this.http.post(this.getAcademicCoursesUrl, null , requestOptions);
// }

 GetAcademyList() {
   return this.http.post(this.GetAcademyListUrl, {'domainID': this.doaminID, 'voc_name': 'course_catalog' }, requestOptions);
 }
 getSubAcademy(subAcademyID: number) {
  return this.http.post(this.getSubAcademyUrl, {'domainID': this.doaminID, 'academy_name': subAcademyID}, requestOptions);
 }
 GetRecommendedCourses() {
  return this.http.post(this.myRecommendationUrl, null, requestOptions);
 }
 iCertify() {
  return this.http.post(this.icertifyUrl, null, requestOptions);
 }
 GetmyAnnouncementsData() {
  return this.http.post(this.myAnnouncementsData, null, requestOptions);
 }

}

