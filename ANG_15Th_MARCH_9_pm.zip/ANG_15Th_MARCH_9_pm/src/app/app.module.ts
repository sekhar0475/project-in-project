import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import {APP_BASE_HREF} from '@angular/common';

// Import ng-circle-progress
import { NgCircleProgressModule } from 'ng-circle-progress';
// Import loader
import { NgxLoadingModule, ngxLoadingAnimationTypes } from 'ngx-loading';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NewCoursesComponent } from './components/home/courses/new-courses/new-courses.component';
import { PopularCoursesComponent } from './components/home/courses/popular-courses/popular-courses.component';
import { HomeComponent } from './components/home/home.component';
import { EngagementsComponent } from './components/home/engagements/engagements.component';
import { MyAccountComponent } from './components/home/my-account/my-account.component';
import { CoursesComponent } from './components/home/courses/courses.component';
import { MyTrainingComponent } from './components/home/my-account/my-training/my-training.component';
import { MyCareerPathComponent } from './components/home/my-account/my-career-path/my-career-path.component';
import { MyTeamComponent } from './components/home/my-account/my-team/my-team.component';
import { ReadyForRoleComponent } from './components/home/my-account/my-training/ready-for-role/ready-for-role.component';
import { MandatoryComponent } from './components/home/my-account/my-training/mandatory/mandatory.component';
import { RecommendedComponent } from './components/home/my-account/my-training/recommended/recommended.component';
import { ChannelsComponent } from './components/channels/channels.component';
import { TrainingProgramComponent } from './components/training-program/training-program.component';
import { LyndaComponent } from './components/lynda/lynda.component';
import { DiscussionComponent } from './components/discussion/discussion.component';
import { JioCertificationComponent } from './components/home/courses/jio-certification/jio-certification.component';

import { PerfectScrollbarModule } from 'ngx-perfect-scrollbar';
import { PERFECT_SCROLLBAR_CONFIG } from 'ngx-perfect-scrollbar';
import { PerfectScrollbarConfigInterface } from 'ngx-perfect-scrollbar';

const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
  suppressScrollX: true
};

@NgModule({
  declarations: [
    AppComponent,
    NewCoursesComponent,
    PopularCoursesComponent,
    HomeComponent,
    EngagementsComponent,
    MyAccountComponent,
    CoursesComponent,
    MyTrainingComponent,
    MyCareerPathComponent,
    MyTeamComponent,
    ReadyForRoleComponent,
    MandatoryComponent,
    RecommendedComponent,
    ChannelsComponent,
    TrainingProgramComponent,
    LyndaComponent,
    DiscussionComponent,
    JioCertificationComponent
  ],
  imports: [
    BrowserModule, HttpClientModule,
    PerfectScrollbarModule,
    NgxLoadingModule.forRoot({
      animationType: ngxLoadingAnimationTypes.cubeGrid,
      backdropBackgroundColour: 'rgba(255,255,255,0.8)',
      backdropBorderRadius: '4px',
      primaryColour: '#9966ff',
      secondaryColour: '#66ccff',
      tertiaryColour: '#ffffff'
    }),
    AppRoutingModule
  ],
  providers: [{provide: APP_BASE_HREF, useValue : '/' },
  {
    provide: PERFECT_SCROLLBAR_CONFIG,
    useValue: DEFAULT_PERFECT_SCROLLBAR_CONFIG
  }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
