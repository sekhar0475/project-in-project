import { Component, OnInit, OnDestroy } from '@angular/core';
import { CoursesService } from '../../../../services/courses.service';

@Component({
  selector: 'app-popular-courses',
  templateUrl: './popular-courses.component.html',
  styleUrls: ['./popular-courses.component.css']
})
export class PopularCoursesComponent implements OnInit, OnDestroy {

  private subscription: any;
  public popularCourses: any;
  public loading: boolean;
  BaseUrl: string;

  constructor(private courses_service: CoursesService) { }

  ngOnInit() {
    this.BaseUrl = window['appConfig'].apiBaseUrl;
    this.loading = true;
    this.subscription = this.courses_service.getPopularCourses()
      .subscribe( resp => {
        this.popularCourses = resp['data'];
        this.loading = false;
      }
    );
  }
  ngOnDestroy(): void { this.subscription.unsubscribe(); }
}
