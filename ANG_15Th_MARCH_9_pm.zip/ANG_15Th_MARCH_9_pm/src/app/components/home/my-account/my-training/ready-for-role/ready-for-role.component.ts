import { Component, OnInit, OnDestroy } from '@angular/core';
import {Input} from '@angular/core';

import { CoursesService } from '../../../../../services/courses.service';

@Component({
  selector: 'app-ready-for-role',
  templateUrl: './ready-for-role.component.html',
  styleUrls: ['./ready-for-role.component.css']
})
export class ReadyForRoleComponent implements OnInit, OnDestroy {
  private subscription: any;
  public learningTypeCourses:  any;
  public loading: boolean;
  public percent: number;

  constructor(private courses_service: CoursesService) {}

  ngOnInit() {
    this.loading = true;
    this.subscription = this.courses_service.getReadyForRoleCourses()
      .subscribe( resp => {
        this.learningTypeCourses = resp['data'];
        this.loading = false;
      });
    this.percent = 30;
  }
  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

}
