import { Component, OnInit, OnDestroy } from '@angular/core';
import { CoursesService } from '../../../../../services/courses.service';

@Component({
  selector: 'app-recommended',
  templateUrl: './recommended.component.html',
  styleUrls: ['./recommended.component.css']
})
export class RecommendedComponent implements OnInit, OnDestroy {
  private subscription: any;
  public recommendedCourses: any;
  public percent: number;
  public loader: boolean;

  constructor(private courses_service: CoursesService) { }

  ngOnInit() {
    this.loader = true;
    this.subscription = this.courses_service.getRecommendedCourses()
      .subscribe( resp => {
        this.recommendedCourses = resp['data'];
        this.loader = false;
      });
    this.percent = 50;
  }
  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

}
