import { Component, OnInit, OnDestroy } from '@angular/core';
import { CoursesService } from '../../../../services/courses.service';

@Component({
  selector: 'app-my-career-path',
  templateUrl: './my-career-path.component.html',
  styleUrls: ['./my-career-path.component.css']
})
export class MyCareerPathComponent implements OnInit, OnDestroy {
  private subscription: any;
  public myCareerPath: any;
  public loading: boolean;
  BaseUrl: string;
  constructor(private courses_service: CoursesService) { }

  ngOnInit() {
    this.BaseUrl = window['appConfig'].apiBaseUrl;
    this.loading = true;
    this.subscription = this.courses_service.getMyCareerPath()
      .subscribe( resp => {
        this.myCareerPath = resp['data'];
        this.loading = false;
      });
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

}
