import { Component, OnInit, OnDestroy } from '@angular/core';
import SimpleBar from 'simplebar';
import { CoursesService } from '../../../../services/courses.service';
import { PerfectScrollbarConfigInterface,
  PerfectScrollbarComponent, PerfectScrollbarDirective } from 'ngx-perfect-scrollbar';

@Component({
  selector: 'app-my-team',
  templateUrl: './my-team.component.html',
  styleUrls: ['./my-team.component.css']
})
export class MyTeamComponent implements OnInit, OnDestroy {
  private subscription: any;
  private BaseUrl: string;
  public myTeam: any;
  public loading: boolean;
  public config: PerfectScrollbarConfigInterface;
  constructor(private courses_service: CoursesService) { }

  ngOnInit() {
    // this.BaseUrl = window['appConfig'].apiBaseUrl;
    this.loading = true;
    this.subscription = this.courses_service.getMyTeam()
      .subscribe( resp => {
        this.myTeam = resp['data']['TeamMembers'];
        this.loading = false;
      });
  }
  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

}
