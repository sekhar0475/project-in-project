import { Component, OnInit, OnDestroy } from '@angular/core';
import { CoursesService } from '../../../services/courses.service';

@Component({
  selector: 'app-engagements',
  templateUrl: './engagements.component.html',
  styleUrls: ['./engagements.component.css']
})
export class EngagementsComponent implements OnInit, OnDestroy {
  private subscription: any;
  public academicCourses: any;
  public loading: boolean;
  BaseUrl: string;

  constructor(private courses_service: CoursesService) { }

  ngOnInit() {
    // this.BaseUrl = window['appConfig'].apiBaseUrl;
    // this.loading = true;
    // this.subscription = this.courses_service.getAcademicCourses()
    //   .subscribe( resp => {
    //     console.log(resp);
    //     this.academicCourses = resp;
    //     this.loading = false;
    //   });
  }

  ngOnDestroy(): void {
    // this.subscription.unsubscribe();
  }

}
