export class Block {
  id: string;
  admin_label: string;
}
