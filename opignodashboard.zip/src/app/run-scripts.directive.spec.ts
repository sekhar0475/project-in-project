/* tslint:disable:no-unused-variable */

import { ElementRef } from '@angular/core';
import { TestBed, async } from '@angular/core/testing';
import { RunScriptsDirective } from './run-scripts.directive';

describe('RunScriptsDirective', () => { });
