import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  public displayHomeChildRoutes: string = 'my_account';

  constructor(private router: Router) { }

  ngOnInit() {
    // this.navigateMyAccount();
  }

  // navigateMyAccount() {
  //   this.router.navigateByUrl('/home/my-account', { skipLocationChange: true });
  // }

  // navigateCourses() {
  //   this.router.navigateByUrl('/home/courses', { skipLocationChange: true });
  // }
  // navigateEngagements() {
  //   this.router.navigateByUrl('/home/engagements', { skipLocationChange: true });
  // }

}
