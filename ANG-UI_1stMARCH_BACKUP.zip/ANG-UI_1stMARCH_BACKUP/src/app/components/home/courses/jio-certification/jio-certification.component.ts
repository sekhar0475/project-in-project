import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-jio-certification',
  templateUrl: './jio-certification.component.html',
  styleUrls: ['./jio-certification.component.css']
})
export class JioCertificationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
