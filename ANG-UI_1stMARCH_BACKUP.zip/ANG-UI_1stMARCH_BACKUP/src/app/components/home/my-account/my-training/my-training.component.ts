import { Component, OnInit, Input } from '@angular/core';
import { CoursesService } from '../../../../services/courses.service';

@Component({
  selector: 'app-my-training',
  templateUrl: './my-training.component.html',
  styleUrls: ['./my-training.component.css']
})
export class MyTrainingComponent implements OnInit {

  public displayChildRoutes: string = 'ready_for_role';
  // public buttonClassId: number = 170952;

  public learningLearningPlanStatus:  any;
  // public readyForRoleTab:  any;
  // public mandatorytab:  any;
  // public recommendedTab:  any;

  constructor(private courses_service: CoursesService) { }

  ngOnInit() {
    // this.courses_service.tabsClassId = this.learningLearningPlanStatus[2]['class_type'];
    this.get_learning_plan_status();
  }

  get_learning_plan_status() {
    this.courses_service.GetLearningPlanStatus()
      .subscribe( resp => (this.learningLearningPlanStatus = resp['data'])
    );
  }
}
