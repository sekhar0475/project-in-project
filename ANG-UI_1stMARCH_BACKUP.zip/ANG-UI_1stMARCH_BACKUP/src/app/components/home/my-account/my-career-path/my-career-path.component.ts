import { Component, OnInit } from '@angular/core';
import { CoursesService } from '../../../../services/courses.service';

@Component({
  selector: 'app-my-career-path',
  templateUrl: './my-career-path.component.html',
  styleUrls: ['./my-career-path.component.css']
})
export class MyCareerPathComponent implements OnInit {
  public myCareerPath: any;
  constructor(private courses_service: CoursesService) { }

  ngOnInit() {
    this.get_my_career_path();
  }

  get_my_career_path() {
    this.courses_service.getMyCareerPath()
      .subscribe( resp => (this.myCareerPath = resp['data'])
      );
  }

}
