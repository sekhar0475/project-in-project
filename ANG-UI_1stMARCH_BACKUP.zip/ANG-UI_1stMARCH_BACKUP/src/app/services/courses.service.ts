import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders, HttpErrorResponse, HttpResponse } from '@angular/common/http';
import {Observable} from 'rxjs';
import { map } from 'rxjs/operators';

const headerDict = {
  'Content-Type': 'application/json',
  'Accept': 'application/json',
  'domainID': window['appConfig'].domainId
};
const requestOptions = {headers: new HttpHeaders(headerDict)};


@Injectable({
  providedIn: 'root'
})
export class CoursesService {

  apiBaseUrl: string;
  getPopularCourseUrl: string;
  getNewCoursesUrl: string;
  getMyTeamsUrl: string;
  getLearningTypeCoursesUrl: string;
  getLearningTabsUrl: string;
  getMyCareerPathUrl: string;
  doaminID: string;

  readyforroleTabId: number;
  mandatoryTabId: number;
  recommendedTabId: number;

  tabsClassId: number;

  constructor(private http: HttpClient) {

    this.apiBaseUrl = window['appConfig'].apiBaseUrl;
    this.getPopularCourseUrl = window['appConfig'].getPopularCourse;
    this.getNewCoursesUrl = window['appConfig'].getNewCourse;
    this.getMyTeamsUrl = window['appConfig'].getMyTeam;
    this.getLearningTypeCoursesUrl =  window['appConfig'].getLearningTypeCourses;
    this.getLearningTabsUrl =  window['appConfig'].getLearningTabs;
    this.getMyCareerPathUrl =  window['appConfig'].MyCareerPath;
    // EmployeeCourseUrl

    this.doaminID = window['appConfig'].domainId;
    this.readyforroleTabId = window['appConfig'].readyFor;
    this.mandatoryTabId = window['appConfig'].mandatory;
    this.recommendedTabId = window['appConfig'].recommended;
  }

  getPopularCourses(): Observable<any> {
    return this.http.post(this.getPopularCourseUrl, null, requestOptions);
    // return this.http.get('../../assets/GetPopularCourses.json');
  }

  getNewCourses(): Observable<any> {
    return this.http.post(this.getNewCoursesUrl, null, requestOptions);
    // return this.http.get('../../assets/GetNewCourses.json');
  }

  getMyTeam(): Observable<any> {
    return this.http.post(this.getMyTeamsUrl, null, requestOptions);
    // return this.http.get('../../assets/MyTeam.json');
  }
  getReadyForRoleCourses() {
    return this.http.post(this.getLearningTypeCoursesUrl, {'class_id': this.readyforroleTabId}, requestOptions);
    // return this.http.get('../../assets/GetLearningTypeCourses.json');
  }
 getMandatoryCourses() {
  return this.http.post(this.getLearningTypeCoursesUrl, {'class_id': this.mandatoryTabId}, requestOptions);
   // return this.http.get('../../assets/GetLearningTypeCourses.json');
 }
 getRecommendedCourses() {
  return this.http.post(this.getLearningTypeCoursesUrl, {'class_id': this.recommendedTabId}, requestOptions);
  // return this.http.get('../../assets/GetLearningTypeCourses.json');
 }

  GetLearningPlanStatus() {
    return this.http.post(this.getLearningTabsUrl, null , requestOptions);
    // return this.http.get('../../assets/GetLearningPlanStatus.json');
 }
 getMyCareerPath() {
  return this.http.post(this.getMyCareerPathUrl, null , requestOptions);
  // return this.http.get('../../assets/GetLearningPlanStatus.json');
 }

}

