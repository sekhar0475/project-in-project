import { environment } from './../../../../../environments/environment';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { CoursesService } from '../../../../services/courses.service';
import { PerfectScrollbarConfigInterface,
  PerfectScrollbarComponent, PerfectScrollbarDirective } from 'ngx-perfect-scrollbar';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-my-training',
  templateUrl: './my-training.component.html',
  styleUrls: ['./my-training.component.css']
})
export class MyTrainingComponent implements OnInit, OnDestroy {
  private subscription: any;
  public coursesTypeRouteId: number = environment.readyforroleTabId;
  classTypeListCourses: any;
  public getClassTypeList: any;
  public config: PerfectScrollbarConfigInterface;
  public loading: boolean = false;
  errorPresent: boolean;
  deafultCourseImgUrl = environment.deafultCourseImgUrl;

  constructor(private courses_service: CoursesService) {}

  ngOnInit() {
    this.errorPresent = false;
    this.subscription = this.courses_service.getClassTypeList()
      .subscribe(
        resp => { this.getClassTypeList = resp['data']; },
        err => { this.errorPresent = true; }
    );
    this.subscription = this.courses_service.getClassTypeListCourses(this.coursesTypeRouteId)
      .subscribe(
        resp => {
          this.loading = true;
          if (resp['data'].length) {
            this.classTypeListCourses = resp['data'];
            this.loading = false;
          } else {
            this.loading = false;
            this.errorPresent = true;
          }
        },
        error => {
            this.errorPresent = true;
        }
    );
  }

  onCourseTypeChange($event, course_type_id: number) {
    this.errorPresent = false;
    this.coursesTypeRouteId = course_type_id;
    this.subscription = this.courses_service.getClassTypeListCourses(course_type_id)
      .subscribe(
        resp => {
          this.loading = true;
          if (resp['data'].length) {
            this.classTypeListCourses = resp['data'];
            this.loading = false;
          } else {
            this.loading = false;
            this.errorPresent = true;
          }
        },
        error => {
            this.errorPresent = true;
        }
    );
  }

  goToAllCourses(paramValue: number): void {
    this.courses_service.navigateToUrl(paramValue);
  }

  ngOnDestroy(): void {
    if (this.subscription) {
      this.subscription.unsubscribe();
    }
  }
}

