import { Component, OnInit, OnDestroy } from '@angular/core';
import { CoursesService } from './../../../services/courses.service';
import { environment } from '../../../../environments/environment';

@Component({
  selector: 'app-my-account',
  templateUrl: './my-account.component.html',
  styleUrls: ['./my-account.component.css']
})
export class MyAccountComponent implements OnInit, OnDestroy {
  BaseUrl: string;
  subscription: any;

  my_team: boolean = false;
  my_career: boolean = false;

  public myTeamData: any;
  mt_loading: boolean = true;
  public mt_error_message: string;
  mt_errorPresent: boolean;
  mt_noData: boolean = true;


  public mc_error_message: string;
  mc_errorPresent: boolean;
  mc_noData: boolean = true;
  public myCareerPath: any;
  mc_loading: boolean;

  carrer_isShow = false;
  team_isShow = false;

  toggle_carrer_display() {
    this.carrer_isShow = !this.carrer_isShow;
    if (this.carrer_isShow === true) {
      this.getCarrerCourses();
    }
  }

  getCarrerCourses() {
      this.subscription = this.courses_service.getMyCareerPath().subscribe( resp => {
        this.mc_noData = false;
        if (resp['data'].length) {
          this.my_career = true;
          this.myCareerPath = resp['data'];
          this.mc_loading = false;
        } else {
          this.mc_loading = false;
          this.mc_errorPresent = true;
          this.mc_error_message = 'No records found';
        }
      },
      error => {
        this.mc_errorPresent = true;
        this.mc_error_message = error;
      }
    );
  }

  toggle_team_display() {
    this.team_isShow = !this.team_isShow;
    if (this.team_isShow === true) {
      this.getMyTeam();
    }
  }

  getMyTeam() {
    this.subscription = this.courses_service.getMyTeam().subscribe(
      resp => {
        if (resp['data']['teamcount'] > 0) {
          this.my_team = true;
          this.mt_noData = false;
          this.myTeamData = resp['data']['teammembers'];
          this.mt_loading = false;
        } else {
          this.mt_loading = false;
          this.mt_errorPresent = true;
          this.mt_error_message = 'No records found';
        }
      },
      error => {
        this.mt_errorPresent = true;
        this.mt_error_message = error;
      }
    );
  }

  constructor(private courses_service: CoursesService) {}
  ngOnInit() {
    this.BaseUrl = environment.apiBaseUrl;
  }

  all_my_career_path() {
    window.location.href = this.BaseUrl + '/employee/career_path?title=&type=Learning Path';
  }
  all_team_members() {
    window.location.href = this.BaseUrl + '/my/training/status';
  }
  ngOnDestroy(): void {
    if (this.subscription) {
      this.subscription.unsubscribe();
    }
  }
}
