import { Component, OnInit, OnDestroy } from '@angular/core';
import { CoursesService } from '../../../../services/courses.service';
import { PerfectScrollbarConfigInterface,
  PerfectScrollbarComponent, PerfectScrollbarDirective } from 'ngx-perfect-scrollbar';
import { environment } from '../../../../../environments/environment';

@Component({
  selector: 'app-icertification',
  templateUrl: './icertification.component.html',
  styleUrls: ['./icertification.component.css']
})
export class IcertificationComponent implements OnInit, OnDestroy {
  private subscription: any;
  BaseUrl: string;
  deafultCourseImgUrl: string;
  learning_plan_status: any;
  learning_plan_status_value: any;
  i_certify_button: boolean;
  is_certified: boolean;
  loading: boolean;
  config: PerfectScrollbarConfigInterface;
  noDomainId: boolean;
  noData: any;
  iCertifyStatus: string;
  btn_active: boolean = false;

  constructor(private courses_service: CoursesService) { }
  ngOnInit() {
    this.BaseUrl = environment.apiBaseUrl;
    this.deafultCourseImgUrl = environment.deafultCourseImgUrl;
    this.noData = false;
    this.iCertifyStatus = 'false';
    this.is_certified = false;
    this.subscription = this.courses_service.GetLearningPlanStatus()
      .subscribe( resp => {
          this.noDomainId = false;
          this.learning_plan_status = resp['data'].filter(item => item.class_type === 'Ready for Role');
          if (!this.learning_plan_status[0].status) {
            this.learning_plan_status_value = 0;
          } else {
            this.learning_plan_status_value = this.learning_plan_status[0].status;
          }

          this.iCertifyStatus = resp['iCertifyFlag'];
          if (this.learning_plan_status_value === 100  && (this.iCertifyStatus === 'false')) {
            this.btn_active = true;
            this.is_certified = false;
          } else if (this.learning_plan_status_value === 100  && (this.iCertifyStatus === 'true')) {
            this.is_certified = true;
          } else if (this.iCertifyStatus === 'true') {
            this.is_certified = true;
          }
        },
        error => {
          this.noDomainId = true;
        });
  }

  icertify() {
    if (this.iCertifyStatus === 'false' && this.btn_active === true) {
        this.subscription = this.courses_service.iCertify()
        .subscribe( resp => { this.is_certified = true; });
    }
  }

  ngOnDestroy(): void {
    if (this.subscription) {
      this.subscription.unsubscribe();
    }
  }
}
