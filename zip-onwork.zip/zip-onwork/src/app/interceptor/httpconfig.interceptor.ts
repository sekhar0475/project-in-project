import { HttpEvent,
    HttpInterceptor,
    HttpHandler,
    HttpRequest,
    HttpResponse,
    HttpErrorResponse} from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

export class HttpErrorInterceptor implements HttpInterceptor {
        intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
            return next.handle(request)
            .pipe(
                catchError( (error: HttpErrorResponse) => {
                let errMsg = '';

                if (error.error instanceof ErrorEvent) {                    // Client Side Error
                    // errMsg = `Error: ${error.error.message}`;
                    errMsg = 'No records are found';
                } else {                                                    // Server Side Error
                    // errMsg = `Error Code: ${error.status},  Message: ${error.message}` + 'Server side Error...!';
                    errMsg = 'No records found';
                    // if (error.status === 404) {
                    //     // errMsg = 'The server has not found anything matching the Request-URI';
                    //     errMsg = 'No records found';
                    // } else if (error.status === 401) {
                    //     // errMsg = 'UNAUTHORIZED ACCESS - lacks valid authentication credentials for the target resource';
                    //     errMsg = 'No records assigned';
                    // } else if (error.status === 500) {
                    //     // errMsg = '500 error...!';
                    //     errMsg = 'No records found';
                    // }
                }
                return throwError(errMsg);
                })
            );
    }
}
