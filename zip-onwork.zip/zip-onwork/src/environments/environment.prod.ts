export const environment = {
  production: true,
  doaminID : window['appConfig'].domainId,
  csrfToken : window['appConfig'].csrfToken,
  apiBaseUrl : window['appConfig'].apiBaseUrl,
  deafultCourseImgUrl : window['appConfig'].deafultCourseImgUrl,
  teamMemberImg : window['appConfig'].teamMemberImgUrl,
  getPopularCourseUrl : window['appConfig'].getPopularCourse,
  getNewCoursesUrl : window['appConfig'].getNewCourse,
  getMyTeamsUrl : window['appConfig'].getMyTeam,
  getLearningTypeCoursesUrl :  window['appConfig'].getLearningTypeCourses,
  getLearningTabsUrl :  window['appConfig'].getLearningTabs,
  getMyCareerPathUrl :  window['appConfig'].MyCareerPath,
  getAcademicCoursesUrl : window['appConfig'].getAcademicCourses,
  GetAcademyListUrl : window['appConfig'].GetAcademyList,
  getSubAcademyUrl : window['appConfig'].getSubAcademy,
  myRecommendationUrl : window['appConfig'].myRecommendation,
  icertifyUrl : window['appConfig'].icertify,
  getAllCoursesUrl : window['appConfig'].EmployeeCourseUrl,
  getClassTypeListUrl : window['appConfig'].getClassTypeList,
  myAnnouncementsData : window['appConfig'].myAnnouncements,
  readyforroleTabId : window['appConfig'].readyFor
};

