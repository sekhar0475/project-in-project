import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { JioCertificationComponent } from './jio-certification.component';

describe('JioCertificationComponent', () => {
  let component: JioCertificationComponent;
  let fixture: ComponentFixture<JioCertificationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ JioCertificationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(JioCertificationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
