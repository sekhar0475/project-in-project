import { Component, OnInit, OnDestroy } from '@angular/core';

import { CoursesService } from '../../../../services/courses.service';
@Component({
  selector: 'app-new-courses',
  templateUrl: './new-courses.component.html',
  styleUrls: ['./new-courses.component.css']
})
export class NewCoursesComponent implements OnInit, OnDestroy {
  private subscription: any;
  public newCourses:  any;
  public loading: boolean = false;
  BaseUrl: string;
  deafultCourseImgUrl: string;
  errorPresent: boolean;
  public error_message: string;

  constructor(private courses_service: CoursesService) { }
   ngOnInit() {
    this.BaseUrl = window['appConfig'].apiBaseUrl;
    this.deafultCourseImgUrl = window['appConfig'].deafultCourseImgUrl;
    this.subscription = this.courses_service.getNewCourses().subscribe( resp => {
        this.loading = true;
        setTimeout(() => {
          this.newCourses = resp['data'];
          this.loading = false;
        }, 1000);
      }, error => {
        this.errorPresent = true;
        this.error_message = error;
      });
  }
  ngOnDestroy(): void { this.subscription.unsubscribe(); }
}
