import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import {APP_BASE_HREF} from '@angular/common';
// Import ng-circle-progress
import { NgCircleProgressModule } from 'ng-circle-progress';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NewCoursesComponent } from './components/home/courses/new-courses/new-courses.component';
import { PopularCoursesComponent } from './components/home/courses/popular-courses/popular-courses.component';
import { HomeComponent } from './components/home/home.component';
import { EngagementsComponent } from './components/home/engagements/engagements.component';
import { MyAccountComponent } from './components/home/my-account/my-account.component';
import { CoursesComponent } from './components/home/courses/courses.component';
import { MyTrainingComponent } from './components/home/my-account/my-training/my-training.component';
import { MyCareerPathComponent } from './components/home/my-account/my-career-path/my-career-path.component';
import { MyTeamComponent } from './components/home/my-account/my-team/my-team.component';
import { ReadyForRoleComponent } from './components/home/my-account/my-training/ready-for-role/ready-for-role.component';
import { MandatoryComponent } from './components/home/my-account/my-training/mandatory/mandatory.component';
import { RecommendedComponent } from './components/home/my-account/my-training/recommended/recommended.component';
import { ChannelsComponent } from './components/channels/channels.component';
import { TrainingProgramComponent } from './components/training-program/training-program.component';
import { LyndaComponent } from './components/lynda/lynda.component';
import { DiscussionComponent } from './components/discussion/discussion.component';
import { JioCertificationComponent } from './components/home/courses/jio-certification/jio-certification.component';

@NgModule({
  declarations: [
    AppComponent,
    NewCoursesComponent,
    PopularCoursesComponent,
    HomeComponent,
    EngagementsComponent,
    MyAccountComponent,
    CoursesComponent,
    MyTrainingComponent,
    MyCareerPathComponent,
    MyTeamComponent,
    ReadyForRoleComponent,
    MandatoryComponent,
    RecommendedComponent,
    ChannelsComponent,
    TrainingProgramComponent,
    LyndaComponent,
    DiscussionComponent,
    JioCertificationComponent
  ],
  imports: [
    BrowserModule, HttpClientModule,
    NgCircleProgressModule.forRoot({
      'radius': 60,
      'space': -10,
      // 'outerStrokeGradient': true,
      'outerStrokeWidth': 3,
      // 'outerStrokeColor': '#4882c2',
      'outerStrokeGradientStopColor': '#53a9ff',
      'innerStrokeColor': '#e7e8ea',
      'innerStrokeWidth': 3,
      // 'title': 'UI',
      'animateTitle': true,
      'animationDuration': 1000,
      // 'showUnits': true,
      'showBackground': false,
      'clockwise': false,
      'startFromZero': false,
       'showSubtitle' : false
    }),
    AppRoutingModule
  ],
  providers: [{provide: APP_BASE_HREF, useValue : '/' }],
  bootstrap: [AppComponent]
})
export class AppModule { }
