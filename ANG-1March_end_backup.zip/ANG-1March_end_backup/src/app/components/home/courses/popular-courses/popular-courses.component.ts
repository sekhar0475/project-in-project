import { Component, OnInit } from '@angular/core';

import { CoursesService } from '../../../../services/courses.service';
@Component({
  selector: 'app-popular-courses',
  templateUrl: './popular-courses.component.html',
  styleUrls: ['./popular-courses.component.css']
})
export class PopularCoursesComponent implements OnInit {

  public popularCourses:  any;

  constructor(private courses_service: CoursesService) { }

  ngOnInit() {
    this.get_new_courses();
  }

  get_new_courses() {
    this.courses_service.getPopularCourses()
      .subscribe( resp => (this.popularCourses = resp['data'])
      );
  }

}
