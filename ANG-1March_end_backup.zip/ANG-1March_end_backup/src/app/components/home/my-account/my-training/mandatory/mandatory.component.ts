import { Component, OnInit, Input } from '@angular/core';
import { CoursesService } from '../../../../../services/courses.service';

@Component({
  selector: 'app-mandatory',
  templateUrl: './mandatory.component.html',
  styleUrls: ['./mandatory.component.css']
})
export class MandatoryComponent implements OnInit {
  public mandatoryCourses: any;
  public percent: number;

  @Input() courses_type_class_id: number;

  constructor(private courses_service: CoursesService) { }

  ngOnInit() {
    this.get_mandatory_courses();
  }
  get_mandatory_courses() {
    this.courses_service.getMandatoryCourses()
      .subscribe( resp => (this.mandatoryCourses = resp['data'])
    );
    this.percent = 40;
  }

}
