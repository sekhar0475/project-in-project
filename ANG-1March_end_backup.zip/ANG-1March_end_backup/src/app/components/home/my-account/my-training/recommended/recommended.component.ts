import { Component, OnInit, Input } from '@angular/core';
import { CoursesService } from '../../../../../services/courses.service';

@Component({
  selector: 'app-recommended',
  templateUrl: './recommended.component.html',
  styleUrls: ['./recommended.component.css']
})
export class RecommendedComponent implements OnInit {

  public recommendedCourses: any;
  public percent: number;
  @Input() courses_type_class_id: number;


  constructor(private courses_service: CoursesService) { }

  ngOnInit() {
    this.get_rcommended_courses();
  }

  get_rcommended_courses() {
    this.courses_service.getRecommendedCourses()
      .subscribe( resp => (this.recommendedCourses = resp['data'])
    );
    this.percent = 50;
  }

}
