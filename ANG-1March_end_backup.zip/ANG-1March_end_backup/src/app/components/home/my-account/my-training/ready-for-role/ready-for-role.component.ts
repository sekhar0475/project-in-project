import { Component, OnInit } from '@angular/core';
import {Input} from '@angular/core';

import { CoursesService } from '../../../../../services/courses.service';

@Component({
  selector: 'app-ready-for-role',
  templateUrl: './ready-for-role.component.html',
  styleUrls: ['./ready-for-role.component.css']
})
export class ReadyForRoleComponent implements OnInit {
  public learningTypeCourses:  any;
  public ede: number;
  public percent: number;
  @Input() courses_type_class_id: number;


  constructor(private courses_service: CoursesService) {
    // this.ede = this.courses_service.tabsClassId;
  }

  ngOnInit() {
    this.get_ready_for_role_courses();
  }

  get_ready_for_role_courses() {
    this.courses_service.getReadyForRoleCourses()
      .subscribe( resp => (this.learningTypeCourses = resp['data'])
    );
    this.percent = 30;
  }

}
