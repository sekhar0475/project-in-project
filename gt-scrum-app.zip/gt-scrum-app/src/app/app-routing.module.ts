import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './UC/login/login.component';
import { HomeComponent } from './home/home.component';
import { AppComponent } from './app.component';
// import { LoginGenComponent } from './login-gen/login-gen.component';
import { DahsboardComponent } from './UC/dahsboard/dahsboard.component';
import { MenubarComponent } from './UC/menubar/menubar.component';
import { Component1Component } from './lazymodule/component1/component1.component';
import { CardCreationComponent } from './CC/card-creation/card-creation.component';
import { HeaderComponent } from './UC/header-rr/header.component'
import { HeaderHydrocarbonComponent } from './UC/header-hc/header-hydrocarbon.component'
import { DashboardRetailComponent } from './UC/dashboard-retail/dashboard-retail.component';
import { HeaderJioComponent } from './UC/header-jo/header-jio.component';
import { DashboardHydrocarbonComponent } from './UC/dashboard-hydrocarbon/dashboard-hydrocarbon.component';
import { CardCreationCssComponent } from './card-creation-css/card-creation-css.component';
import { MatAccordianangComponent } from './mat-accordianang/mat-accordianang.component';
//import { SecureRequestComponent } from './secure-request/secure-request.component';
import { ReactiveFormsValidationsComponent } from './reactive-forms-validations/reactive-forms-validations.component';
import { MatTableExampleComponent } from './mat-table-example/mat-table-example.component';
import { ReadExcelComponent } from './read-excel/read-excel.component';
import { ExportToExcelComponent } from './export-to-excel/export-to-excel.component';
import { UserCreationComponent } from './MDM/user-creation/user-creation.component';
import { SearchComponent } from './RPT/search/search.component';
import { ExportToExcelCardCreationFormatComponent } from './CC/export-to-excel-card-creation-format/export-to-excel-card-creation-format.component';
import { AuthGuard } from './Services/authGuard';
import { MultiselectDropDownScrumComponent } from './multiselect-drop-down-scrum/multiselect-drop-down-scrum.component';

import { SearchListComponent } from './RPT/search-list/search-list.component';
import { UserRolesComponent } from './MDM/user-roles/user-roles.component';
import { RoleMasterComponent } from './MDM/role-master/role-master.component';
import { RolemenuMasterComponent } from './MDM/rolemenu-master/rolemenu-master.component';
import { SiteConfigComponent } from './MDM/site-config/site-config.component';
import { SiteFieldConfigComponent } from './MDM/site-field-config/site-field-config.component';
import { MstSiteComponent } from './RPT/mst-site/mst-site.component';
import { SiteApprovalConfigComponent } from './MDM/site-approval-config/site-approval-config.component';
import { CardCreationResourceListComponent } from './CC/card-creation-resource-list/card-creation-resource-list.component';
// import {ExportCardCreationExcelComponentTest} from './CC/export-card-creation-excel/export-card-creation-excel.component' ;
import { MatScrumDropDownTestComponent } from './mat-scrum-drop-down-test/mat-scrum-drop-down-test.component';
import { MenuMasterComponent } from './MDM/menu-master/menu-master.component';
import { OimLoginComponent } from './oim-login/oim-login.component';
import { SiteFieldEditConfigComponent } from './MDM/site-field-edit-config/site-field-edit-config.component';

const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'logingen', component: AppComponent },
  { path: 'home', component: HomeComponent },
  { path: 'dashboard', component: DahsboardComponent },
  { path: 'cardcreation', component: CardCreationComponent },
  { path: 'reactiveformsvalidations', component: ReactiveFormsValidationsComponent },
  { path: 'header', component: HeaderComponent },
  { path: 'header1', component: HeaderHydrocarbonComponent },
  { path: 'dashboardretail', component: DashboardRetailComponent },
  { path: 'dashboardhydrocarbon', component: DashboardHydrocarbonComponent },
  { path: 'headerjio', component: HeaderJioComponent },
  { path: 'cardcreationcss', component: CardCreationCssComponent },
  { path: 'google', redirectTo: 'www.yahoo.com/' },
  { path: 'exporttoexcel', component: ExportToExcelComponent },
  { path: 'mattableexample', component: MatTableExampleComponent },
  { path: 'readexcel', component: ReadExcelComponent },
  { path: 'exportcardcreation', component: ExportToExcelCardCreationFormatComponent },
  { path: 'mataccordian', component: MatAccordianangComponent },
  // { path: 'component1', loadChildren :'./lazymodule/component1/component1.module#Component1Module'},
  // { path: 'tst', loadChildren :'./lazymodule/component1/component1.module#Component1Module'},
  { path: 'usercreations', component: UserCreationComponent },
  { path: 'search', component: SearchComponent },
  { path: 'multiselect', component: MultiselectDropDownScrumComponent },
  { path: 'userEdit', component: UserCreationComponent },
  { path: 'roleEdit', component: RoleMasterComponent },
  { path: 'rolemenuEdit', component: RolemenuMasterComponent },
  { path: 'MstUsers', component: SearchComponent },
  { path: 'searchlist', component: SearchListComponent },
  { path: 'userroles', component: UserRolesComponent },
  { path: 'siteconfig', component: SiteConfigComponent },
  { path: 'sitefield', component: SiteFieldConfigComponent },
  { path: 'mstsite', component: MstSiteComponent },
  { path: 'menuEdit', component: MenuMasterComponent },
  { path: 'oim', component: OimLoginComponent },
  { path: 'SitefieldEdit',component:SiteFieldEditConfigComponent},
  // { path: 'exportcardcreationexcel', component: ExportCardCreationExcelComponentTest },
  { path: 'cardcreationresourcelistcomponent', component: CardCreationResourceListComponent },
  { path: 'matscrumdropdown', component: MatScrumDropDownTestComponent },
  { path: 'menu', component: MenubarComponent },
  { path: 'siteconfig', component: SiteConfigComponent },
  { path: 'sitefield', component: SiteFieldConfigComponent },
  { path: 'MstSite', component: MstSiteComponent },
  { path: 'SiteAppConfig', component:SiteApprovalConfigComponent  },
  { path: '**', component: OimLoginComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
