import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { FormControl } from '@angular/forms';

@Component({
  selector: 'app-multiselect-drop-down-scrum',
  templateUrl: './multiselect-drop-down-scrum.component.html',
  styleUrls: ['./multiselect-drop-down-scrum.component.css'],
  encapsulation:ViewEncapsulation.Emulated
  })

export class MultiselectDropDownScrumComponent implements OnInit {
  toppings = new FormControl();
  toppingList: string[] = ['Extra cheese', 'Mushroom', 'Onion', 'Pepperoni', 'Sausage', 'Tomato'];

  ngOnInit() {

  }

}


