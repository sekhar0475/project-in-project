import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MultiselectDropDownScrumComponent } from './multiselect-drop-down-scrum.component';

describe('MultiselectDropDownScrumComponent', () => {
  let component: MultiselectDropDownScrumComponent;
  let fixture: ComponentFixture<MultiselectDropDownScrumComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MultiselectDropDownScrumComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MultiselectDropDownScrumComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
