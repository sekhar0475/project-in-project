import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MstSiteComponent } from './mst-site.component';

describe('SearchComponent', () => {
  let component: MstSiteComponent;
  let fixture: ComponentFixture<MstSiteComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MstSiteComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MstSiteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
