import { Router } from '@angular/router';
import { Component, OnInit, ViewChild, Pipe } from '@angular/core';
import { dropDownDetail } from '../../Model/CcModel/dropDownDetail';
import { MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import { Observable, of } from 'rxjs';
import { requestDetail } from '../../Model/CCModel/requestDetail';
import { HttpClientModule, HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { isNullOrUndefined } from 'util';
import { searchRequester, SharedState } from 'src/app/Model/Common/InterPage';
import { CommonService } from 'src/app/Services/common.service';
import { CreateSiteConfigService } from '../../Services/createSiteConfig.service';
import { MdmService } from 'src/app/Services/mdm.service';

export interface UserData { userCode_0: string; "login ID": string; "user Name": string; "user ID": string; "mobile No": string; status: string; }

@Component({
  selector: 'app-mst-site',
  templateUrl: './mst-site.component.html',
  styleUrls: ['./mst-site.component.css']
})
export class MstSiteComponent implements OnInit {

  //#region  Parameters
  searchString: string = "";
  siteConfigDetails: any = [];
  pageHeader: string = "xgsd";
  users: any = [];
  UCObj: requestDetail = new requestDetail();
  searchRequester: searchRequester = new searchRequester();
  messageService: string[] = [];
  Dropdown1: string = "Dynamic";

  ddlStatus: dropDownDetail = new dropDownDetail();

  StatusText: string = "";
  statusTextDropdown1: string = "";
  StatusCode: string = "2";
  DropdownCode: string = "2";

  ddldynamic: dropDownDetail = new dropDownDetail();
  dynamicText: string = "";
  dynamicCode: string = "";
  dynamicDropdownCode: string = "2";

  displayedColumns = ['id', 'name', 'progress', 'color'];
  dataSource: MatTableDataSource<UserData>;
  paginator: MatPaginator;
  sort: MatSort;
  displayGrid: boolean = false;
  shared: SharedState = new SharedState();
  userName: string = "";
  //#endregion

  constructor(private _createSiteConfig: CreateSiteConfigService, private commonService: MdmService, private httpClient: HttpClient, private router: Router) {
    this.dataSource = new MatTableDataSource(this.users);
  }

  ngOnInit() {

    this.shared = JSON.parse(atob(localStorage.getItem('shared')));
    this.userName = this.shared.userName;
    if (!window.history.state.hasOwnProperty('pageHeader')) {
      this.router.navigateByUrl('searchlist', { state: this.searchRequester });
    }


    this.searchRequester = window.history.state;
    this.pageHeader = this.searchRequester.pageHeader;
    this.UCObj.RequestID = ""; this.UCObj.resCode = "2";
    this.StatusCode === "" ? "1" : this.StatusCode;

    this.Dropdown1 = this.searchRequester.navigateNext === "siteconfig" ||
      this.searchRequester.navigateNext === "sitefield" ? "Groups" : "";

    var VariableType = (this.searchRequester.navigateNext === "siteconfig" ? "SCGCV" :
      this.searchRequester.navigateNext === "sitefield" ? "SFCFGV" :
        this.searchRequester.navigateNext === "SitefieldEdit" ? "SFCFGV" :
          this.searchRequester.navigateNext === "SiteAppConfig" ? "SFCFGV" : "");
    var flag = "1";
    this.getStatus(this.shared.siteCode, "2", "COMMON", "0");

    this.getDynamic(this.shared.siteCode, flag, VariableType, "0");

    this.UCObj.RequestID = "1|" + "|" + this.shared.roleCode + "|2";

  }

  getStatus(siteCode: string, resCode: string, Entity: string, RefID: string) {
    this._createSiteConfig.getEntityInfo(siteCode, resCode, Entity, RefID).then((res) => {
      this.ddlStatus = res;
      var val = res.filter(f => f.mstcode === this.StatusCode);
      if (isNullOrUndefined(val) === false) {
        if (val.length > 0) {
          this.StatusCode = val[0].mstcode.toString();
          this.StatusText = val[0].mstText.toString();
        }
      }
    }, err => { });
  }

  getDynamic(siteCode: string, resCode: string, Entity: string, RefID: string) {
    this._createSiteConfig.getEntityInfo(siteCode, resCode, Entity, RefID).then((res) => {
      this.ddldynamic = res[0].listDetails;
      var val = res[0].listDetails.filter(f => f.mstcode === "");
      if (isNullOrUndefined(val) === false) {
        if (val.length > 0) {
          this.dynamicCode = val[0].mstcode.toString();
          this.dynamicText = val[0].mstText.toString();
        }
      }
    }, err => { });
  }


  Toggle() { this.ddlStatus.Visible = !this.ddlStatus.Visible; }

  Toggle1() { this.ddldynamic.Visible = !this.ddldynamic.Visible; }


  setStatusData(data: any) {
    this.StatusCode = data.mstcode; this.StatusText = data.mstText;
    this.ddlStatus.Visible = false; this.ddlStatus.IsDirty = true;
  }

  setDynamicData(data: any) {
    this.dynamicCode = data.mstcode; this.dynamicText = data.mstText;
    this.ddldynamic.Visible = false; this.ddldynamic.IsDirty = true;
  }

  ClickEdit(element: any) {
    if (element === 0) {
      this.searchRequester.stateElement = "";
      element = { "key": 0, "header": this.searchRequester.pageHeader }
    }
    else {
      this.searchRequester.stateElement = element;
      element["header"] = this.searchRequester.pageHeader;
    }

    this.router.navigateByUrl(this.searchRequester.navigateNext, { state: this.searchRequester });
  }

  SearchData() {
    this.UCObj.RequestID = this.searchRequester.ucObj.RequestID.toString().
      replace("@SEARCHTEXT", this.searchString).replace("@STATUS", this.StatusCode).
      replace("@GROUPCODE", this.dynamicCode);

    this.UCObj.resCode = this.searchRequester.ucObj.resCode;
    this.UCObj.siteCode = this.shared.siteCode;

    this._createSiteConfig.DataTable(this.UCObj).subscribe(
      res => {
        this.displayGrid = res.length > 0 ? true : false;

        if (res.length > 0) {
          this.displayedColumns = Object.keys(res[0]); this.displayedColumns.push("Edit");
          var el = this.displayedColumns.find(a => a.includes("_0"));

          this.displayedColumns = this.displayedColumns.filter
            (
              f => !this.displayedColumns.filter
                (
                  function (item) {
                    var finder = '_0'; return eval('/' + finder + '/').test(item);
                  }
                ).includes(f)
            );

          this.users = res; this.dataSource.data = res;
          this.dataSource = new MatTableDataSource(res);
          this.dataSource.paginator = this.paginator; this.dataSource.sort = this.sort;
        }
        else {
          this.users = res; this.dataSource.data = res;
          this.dataSource = new MatTableDataSource(res);
          this.dataSource.paginator = this.paginator; this.dataSource.sort = this.sort;
        }
      }, err => { });
  }

  private log(message: string) { this.messageService.push("a"); }


  @ViewChild(MatSort, { static: false }) set matSort(ms: MatSort) {
    this.sort = ms;
    this.setDataSourceAttributes();
  }

  @ViewChild(MatPaginator, { static: false }) set matPaginator(mp: MatPaginator) {
    this.paginator = mp;
    this.setDataSourceAttributes();
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator
  }

  setDataSourceAttributes() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); filterValue = filterValue.toLowerCase(); this.dataSource.filter = filterValue;
  }

  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {

      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead

      // TODO: better job of transforming error for user consumption
      console.log(`${operation} failed: ${error.message}`);

      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }

  hasProp(o, name) {
    return o.hasOwnProperty(name);
  }

  Back() {
    this.router.navigateByUrl('searchlist', { state: this.searchRequester });
  }


  Dynamicdropdownbind(item): boolean {

    return item.hasOwnProperty('mstText') ?
      true :
      item.hasOwnProperty('roleName') ? true : false;
  }
}

enum enumDropdown {
  GRP9USERLIST = "User Type",
  GRP9ROLELIST = "Role Type",
}
