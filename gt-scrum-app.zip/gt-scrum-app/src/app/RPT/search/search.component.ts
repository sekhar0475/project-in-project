import { Router } from '@angular/router';
import { Component, OnInit, ViewChild, Pipe } from '@angular/core';
import { UserCreation } from '../../Model/MDMModel/user-creation';
import { MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import { Observable, of } from 'rxjs';
import { requestDetail } from '../../Model/CCModel/requestDetail';
import { HttpClient } from '@angular/common/http';
import { isNullOrUndefined } from 'util';
import { searchRequester, SharedState } from 'src/app/Model/Common/InterPage';
import { CommonService } from 'src/app/Services/common.service';
import { MdmService } from 'src/app/Services/mdm.service';
import { Search } from 'src/app/Model/MDMModel/search';
import { mstCollection } from 'src/app/Model/CcModel/mstCollection';

export interface UserData { userCode_0: string; "login ID": string; "user Name": string; "user ID": string; "mobile No": string; status: string; }

@Component({
  selector: 'app-search', templateUrl: './search.component.html', styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  //#region DataGrid Params
  displayedColumns = ['id', 'name', 'progress', 'color'];
  dataSource: MatTableDataSource<UserData>;
  paginator: MatPaginator;
  sort: MatSort;
  displayGrid: boolean = false;
  users: any = [];
  searchString: string = "";
  Dropdown1: string = "";
  //#endregion

  //#region Load Time parameters
  pageHeader: string = "xgsd";
  UCObj: requestDetail = new requestDetail();
  searchRequester: searchRequester = new searchRequester();
  shared: SharedState = new SharedState();
  //#endregion

  Search: Search = new Search;

  constructor(private commonService: CommonService, private mdmService: MdmService, private httpClient: HttpClient, private router: Router) { this.dataSource = new MatTableDataSource(this.users); }

  ngOnInit() {

    //#region State Data handling
    this.shared = JSON.parse(atob(localStorage.getItem('shared')));

    if (!window.history.state.hasOwnProperty('pageHeader')) { this.router.navigateByUrl('searchlist', { state: this.searchRequester }); }

    this.searchRequester = window.history.state;

    this.pageHeader = this.searchRequester.pageHeader;

    this.UCObj.RequestID = ""; this.UCObj.resCode = this.searchRequester.ucObj.resCode;

    //#endregion

    //#region Data Load    
    this.UCObj.resCode = "DRP" + this.searchRequester.ucObj.resCode; this.UCObj.siteCode = this.shared.siteCode;
    this.UCObj.RequestID =  this.searchRequester.ucObj.resCode === "GRP9USERLIST" ? 
    "0|" + this.shared.userCode + "|" + this.shared.roleCode + "|2" : 
    "2|" + this.shared.userCode + "|" + this.shared.roleCode + "|2";

    this.mdmService.getData(this.UCObj, this.searchRequester.navigateNext).subscribe(
      res => {

        //#region Bind Search Dropdown

        this.Search = res;
        this.Search.statusVisible = false;
        this.Search.statusCode = this.Search.statusCode === "" ? "2" : this.Search.statusCode;

        var val = res.status.listDetails.filter(f => f.mstcode === this.Search.statusCode);

        if (isNullOrUndefined(val) === false) { if (val.length > 0) { this.Search.statusText = val[0].mstText.toString(); } }

        //#endregion

        //#region Bind Dynamic Dropdown

        this.Dropdown1 = this.searchRequester.ucObj.resCode === "GRP9USERLIST" ? "User Roles" :
          this.searchRequester.ucObj.resCode === "GRP9ROLELIST" ? "User Type" :
            this.searchRequester.ucObj.resCode === "GRP9MENULIST" ? "Menu Type" : "dynamic Value";
        this.Search.dynamicVisible = false;
        this.Search.dynamicCode = this.Search.dynamicCode === "" ? 
        this.searchRequester.ucObj.resCode === "GRP9USERLIST" ?  "0" : "2" : this.Search.dynamicCode;
        var val = res.dynamic.listDetails.filter(f => f.mstcode === this.Search.dynamicCode);

        if (isNullOrUndefined(val) === false) { if (val.length > 0) { this.Search.dynamicText = val[0].mstText.toString(); } }

        //#endregion
      }, err => { }
    );

    //#endregion
  }

  //#region Dropdown Functions
  Toggle() { this.Search.statusVisible = !this.Search.statusVisible; }

  Toggle1() { this.Search.dynamicVisible = !this.Search.dynamicVisible; }

  setStatusData(data: any) { this.Search.statusCode = data.mstcode; this.Search.statusText = data.mstText; this.Search.statusVisible = false; }

  setDropdownData(data: any) { this.Search.dynamicCode = data.mstcode; this.Search.dynamicText = data.mstText; this.Search.dynamicVisible = false; }
  //#endregion


  ClickEdit(element: any) {
    if (element === 0) {
      element = { "key": 0, "header": this.searchRequester.pageHeader }
    }
    else {
      this.searchRequester.stateElement = element;
      element["header"] = this.searchRequester.pageHeader;
    }

    this.searchRequester.ucObj.resCode = this.searchRequester.ucObj.resCode;
    this.router.navigateByUrl(this.searchRequester.navigateNext, { state: this.searchRequester });
  }

  SearchData() {
    this.UCObj.RequestID = this.searchRequester.ucObj.RequestID.toString().
      replace("@SEARCHTEXT", this.searchString).replace("@STATUS", this.Search.statusCode).
      replace("@USERCODE", this.shared.userCode).replace("@MENUCODE", this.Search.dynamicCode).
      replace("@ROLECODE", this.Search.dynamicCode);

    this.UCObj.resCode = this.searchRequester.ucObj.resCode;
    this.UCObj.siteCode = this.shared.siteCode;


    this.mdmService.getData(this.UCObj, this.searchRequester.navigateNext + "Search").subscribe(
      res => {
        this.displayGrid = res.length > 0 ? true : false;

        if (res.length > 0) {
          this.displayedColumns = Object.keys(res[0]); this.displayedColumns.push("Edit");
          var el = this.displayedColumns.find(a => a.includes("_0"));

          //this.displayedColumns.map(function (e) {     return e.toUpperCase()}).filter(f => !this.displayedColumns.map(function (e) {     return e.toUpperCase()}).filter(function (item) {var finder = '_0'; return eval('/' + finder + '/').test(item);}).includes(f.toUpperCase()));
          this.displayedColumns = this.displayedColumns.filter
            (
              f => !this.displayedColumns.filter
                (
                  function (item) {
                    var finder = '_0'; return eval('/' + finder + '/').test(item);
                  }
                ).includes(f)
            );

          this.users = res; this.dataSource.data = res;
          this.dataSource = new MatTableDataSource(res);
          this.dataSource.paginator = this.paginator; this.dataSource.sort = this.sort;
        }
        else {
          this.users = res; this.dataSource.data = res;
          this.dataSource = new MatTableDataSource(res);
          this.dataSource.paginator = this.paginator; this.dataSource.sort = this.sort;
        }
      }, err => { });
  }

  @ViewChild(MatSort, { static: false }) set matSort(ms: MatSort) {
    this.sort = ms;
    this.setDataSourceAttributes();
  }

  @ViewChild(MatPaginator, { static: false }) set matPaginator(mp: MatPaginator) {
    this.paginator = mp;
    this.setDataSourceAttributes();
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator
  }

  setDataSourceAttributes() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); filterValue = filterValue.toLowerCase(); this.dataSource.filter = filterValue;
  }

  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {

      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead

      // TODO: better job of transforming error for user consumption
      console.log(`${operation} failed: ${error.message}`);

      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }

  hasProp(o, name) {
    return o.hasOwnProperty(name);
  }

  Back() {
    this.router.navigateByUrl('searchlist', { state: this.searchRequester });
  }

  dashboard() {
    if (this.shared.siteUiCode == 'RR') {
      this.router.navigateByUrl('dashboard', { skipLocationChange: true });
    }
    else if (this.shared.siteUiCode == 'HC') {
      this.router.navigateByUrl('dashboardhydrocarbon', { skipLocationChange: true });
    }
    else {
      this.router.navigateByUrl('dashboardretail', { skipLocationChange: true });
    }
  }
}
