import { Router} from '@angular/router';
// import { Injectable } from '@angular/core';
import { UserCreationService  } from '../../Services/user-creation.service';
import { Component, OnInit,ViewChild, Input, OnChanges, SimpleChanges, SimpleChange, ViewChildren } from '@angular/core';
import {dropDownDetail } from '../../Model/CcModel/dropDownDetail';
import {UserCreation} from '../../Model/MDMModel/user-creation';
import {MatPaginator, MatSort, MatTableDataSource} from '@angular/material';
import { Observable, of } from 'rxjs';
import {requestDetail} from '../../Model/CCModel/requestDetail';
import { HttpClientModule,HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
// import { analyzeAndValidateNgModules } from '@angular/compiler';
import { map, tap, catchError } from "rxjs/operators";
import {httpOptions} from '../../Services/httpConstant';
import { isNullOrUndefined } from 'util';
import { searchRequester, SharedState } from 'src/app/Model/Common/InterPage';
import { CommonService } from 'src/app/Services/common.service';
import { UserData } from 'src/app/mat-table-example/mat-table-example.component';


@Component({
  selector: 'app-search-grid',
  templateUrl: './search-grid.component.html',
  styleUrls: ['./search-grid.component.css']
})
export class SearchGridComponent implements OnChanges,OnInit {

  @Input() dataSource: any;
  @Input() searchRequester : searchRequester;

  @Input() displayedColumns = ['id', 'name', 'progress', 'color'];
  @Input() paginator: MatPaginator;
  @Input() sort: MatSort;
  //dataSource: MatTableDataSource<UserData>;
  UserDetails : UserCreation = new UserCreation();
 

  constructor(private router: Router) { }

  ngOnInit() {
    
  }

  ngOnChanges(changes: SimpleChanges) {
    
    // changes.prop contains the old and the new value...
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.setDataSourceAttributes();
  }
  ClickEdit(element:any)
  {
    this.searchRequester.stateElement = element;
    element["header"] = this.searchRequester.pageHeader;
    this.router.navigateByUrl(this.searchRequester.navigateNext,{state: this.searchRequester });
  }

  SearchData()
  {
    
  }

  @ViewChildren(MatSort) set matSort(ms: MatSort) {
    this.sort = ms;
    this.setDataSourceAttributes();
  }

  @ViewChildren(MatPaginator) set matPaginator(mp: MatPaginator) {
    this.paginator = mp;
    this.setDataSourceAttributes();
  }

  
  setDataSourceAttributes() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  // applyFilter(filterValue: string)
  // {
  //   filterValue = filterValue.trim(); filterValue = filterValue.toLowerCase(); this.dataSource.filter = filterValue;
  // }

}
