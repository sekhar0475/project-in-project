import { Component, OnInit } from '@angular/core';
import { SharedState, searchRequester } from 'src/app/Model/Common/InterPage';
import { Router } from '@angular/router';
import { requestDetail } from 'src/app/Model/CCModel/requestDetail';
import { UserCreation } from 'src/app/Model/MDMModel/user-creation';
import { SiteConfig } from 'src/app/Model/MDMModel/siteConfig';
import { FetchDataComponent } from 'src/app/fetch-data/fetch-data.component';
import { UserCreationService } from 'src/app/Services/user-creation.service';
import { CommonService } from 'src/app/Services/common.service';

@Component({
  selector: 'app-search-list',
  templateUrl: './search-list.component.html',
  styleUrls: ['./search-list.component.css']
})
export class SearchListComponent implements OnInit {

  RequestString: RequestString;
  shared: SharedState = new SharedState();
  searchRequester: searchRequester = new searchRequester();
  userName: string = "";
  UCObj: requestDetail = new requestDetail();
  constructor(private router: Router, private ucs: CommonService) { }
  Data: any;
  ngOnInit() {
    try {
      this.shared = JSON.parse(atob(localStorage.getItem('shared')));
      this.userName = this.shared.userName;
      this.fetchData();

    }
    catch (err) {
    }
  }

  click(value: any) {
    this.searchRequester.pageHeader = value.pageHeader;

    this.searchRequester.stateElement = value;

    this.UCObj.RequestID = Object(RequestString)[value.pageLink];

    this.searchRequester.navigateNext = value.pageLink //value.menuLink.replace("?" + value.pageCode,"") + "Edit"; 

    this.UCObj.siteCode = this.shared.siteCode; this.UCObj.resCode = value.menuLink.split("?")[1];

    this.searchRequester.ucObj = this.UCObj;
    this.router.navigateByUrl(value.menuLink.split("?")[0], { state: this.searchRequester });
  }

  fetchData() {
    this.UCObj.RequestID = "MST|1|1|0";
    this.UCObj.resCode = "7";
    this.UCObj.siteCode = this.shared.siteCode;

    this.ucs.DataTable(this.UCObj).subscribe(
      res => {
        this.Data = res.filter(f => f.parentMenuCode === 22 || f.parentMenuCode === 21);
      }, err => { });
  }

}


enum RequestString {
  // userEdit = "1|@SEARCHTEXT|@USERCODE|@ROLECODE|@STATUS",
  userEdit = "1|@SEARCHTEXT|@USERCODE|@ROLECODE|@STATUS",
  roleEdit = "1|@SEARCHTEXT|@ROLECODE|@STATUS",
  menuEdit = "1|@SEARCHTEXT|@MENUCODE|0|@STATUS",
  siteconfig = "SC|@GROUPCODE|@STATUS",
  sitefield = "SFC|@GROUPCODE|@STATUS",
  SitefieldEdit = "SFEC|0|@STATUS",
  SiteAppConfig = "SFAC|0|@STATUS"

}


// export interface PeriodicElement {
//   pageHeader: string;
//   requestID: string;
//   resCode: string;
//   type : string;
// }

// const ELEMENT_DATA: PeriodicElement[] = [
//   {pageHeader: "Search User", requestID: '1|@SEARCHTEXT|0|0|@STATUS', resCode: "2",type : "user"},
// ];

