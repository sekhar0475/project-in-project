import { NgModule } from '@angular/core';
import { Component1Component } from '../lazymodule/component1/component1.component'
import { Routes, RouterModule } from '@angular/router';

export const routing: any = RouterModule.forChild([
    {
    path: '',
    component: Component1Component, 
        data: {
            title: 'Dashboard',
            meta: [{ name: 'description', content: 'Administration home screen. From here you have access to the configurable parts of the site.' }]
        },
    children: [
            { path: '', component: Component1Component, data: { title: 'Dashboard' } },
            { path: 'home', component: Component1Component, data: { title: 'Dashboard' } },
            { path: 'settings', component: Component1Component },
            { path: 'albums', component: Component1Component, data: { title: 'Album Management' } }
        ]
    },
    { path: '**', component: Component1Component }
]);