import { NgModule } from '@angular/core';
import { Component1Component } from './component1.component';
import { Routes, RouterModule } from '@angular/router';
import { routing } from '../ModuleWithProviders';

const routes: Routes = [

  { path: '', component: Component1Component, children:[{path: 'tst', component: Component1Component, data: { title: 'Dashboard' }}] }
];

@NgModule({
  imports: [routing],
  exports: [RouterModule]
})
export class Component1RoutingModule { }
