import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatOption, MatSelect } from '@angular/material';

@Component({
  selector: 'app-mat-scrum-drop-down-test',
  templateUrl: './mat-scrum-drop-down-test.component.html',
  styleUrls: ['./mat-scrum-drop-down-test.component.css']
})
export class MatScrumDropDownTestComponent implements OnInit {
  @ViewChild('mySelect', { static: true }) mySelect: MatSelect;
  @ViewChild('allSelected', { static: true }) private allSelected: MatOption;
  searchText: string;
  selectedList: string[];
  toppingSelectedValue: any;
  isSelectDisable: boolean = false;
  selectedListCount : number = 0;
  noOfColumnInTable : number = 0 ;
  tdCount : number = 1;
  data: any[] = [
    {
      mstText: 'Extra cheese',
      mstCode: '1'
    },
    {
      mstText: 'Mushroom',
      mstCode: '2'
    },
    {
      mstText: 'Onion',
      mstCode: '3'
    },
    {
      mstText: 'Pepperoni',
      mstCode: '4'
    },
    {
      mstText: 'Sausage',
      mstCode: '5'
    },
    {
      mstText: 'Tomato',
      mstCode: '6'
    },
    {
      mstText: 'potato',
      mstCode: '7'
    },
    {
      mstText: 'Extra butter',
      mstCode: '8'
    },
    {
      mstText: 'pulses',
      mstCode: '9'
    },
    {
      mstText: 'Jalapeno',
      mstCode: '10'
    },
    {
      mstText: 'Pepper',
      mstCode: '11'
    },
    {
      mstText: 'Wedge',
      mstCode: '12'
    },
    {
      mstText: 'Pizza',
      mstCode: '13'
    },
    {
      mstText: 'Pav Bhaji',
      mstCode: '14'
    },
    {
      mstText: 'Burger',
      mstCode: '15'
    },
    {
      mstText: 'Burge1r',
      mstCode: '153'
    },
    {
      mstText: 'Bur2ger',
      mstCode: '154'
    }
  ]
 
  constructor() {
    //this.data.mstText="";
    this.selectedListCount = this.data.length;
    this.noOfColumnInTable = this.selectedListCount / 3;
  }

  ngOnInit() {

  }
  ngAfterViewInit() {
    this.mySelect.open();
  }
  toppings = new FormControl();

  toppingList: string[] = ['Extra cheese', 'Mushroom', 'Onion', 'Pepperoni', 'Sausage', 'Tomato',
    'potato', 'Extra butter', 'pulses'];

  changeTopping(toppingData) {
    this.selectedList = toppingData;

  }
  clients = [
    { id: 'id1', clientName: 'Bruce' },
    { id: 'id2', clientName: 'Ben' },
    { id: 'id3', clientName: 'Peter' }
  ];
  selectedCancelElement(data) {
    //alert(data);
    this.mySelect.close();
    this.isSelectDisable = true;
    this.toppingSelectedValue = this.toppingSelectedValue.filter(f => f !== data);
    this.selectedList = this.selectedList.filter(f => f !== data);
   // this.allSelected.selected;
   // this.toppings.value.pop();
    // const index = this.toppings.value.indexOf(data, 0);
    // if (index > -1) {
    //   this.toppings.value.splice(index, 1);
    // }
  }

  changeClient(data) {
    alert("selected --->" + data);
    this.mySelect.close();
  }
  openedChange(data) {
    data = false;
  }
  formFieldClick() {
    this.isSelectDisable = false;
  }
  toggleAllSelection() {
    if (this.allSelected.selected) {

    } else {

    }
  }

  selectedCars = [3];
  cars = [
      { id: 1, name: 'Volvo' },
      { id: 2, name: 'Saab', disabled: true },
      { id: 3, name: 'Opel' },
      { id: 4, name: 'Audi' },
       { id: 1, name: 'Volvo' },
      { id: 2, name: 'Saab', disabled: true },
      { id: 3, name: 'Opel' },
      { id: 4, name: 'Audi' },
       { id: 1, name: 'Volvo' },
      { id: 2, name: 'Saab', disabled: true },
      { id: 3, name: 'Opel' },
      { id: 4, name: 'Audi' },
       { id: 1, name: 'Volvo' },
      { id: 2, name: 'Saab', disabled: true },
      { id: 3, name: 'Opel' },
      { id: 4, name: 'Audi' },
       { id: 1, name: 'Volvo' },
      { id: 2, name: 'Saab', disabled: true },
      { id: 3, name: 'Opel' },
      { id: 4, name: 'Audi' },
       { id: 1, name: 'Volvo' },
      { id: 2, name: 'Saab', disabled: true },
      { id: 3, name: 'Opel' },
      { id: 4, name: 'Audi' },
       { id: 1, name: 'Volvo' },
      { id: 2, name: 'Saab', disabled: true },
      { id: 3, name: 'Opel' },
      { id: 4, name: 'Audi' },
  ];

  pokemonControl = new FormControl();
  pokemonGroups: PokemonGroup[] = [
    {
      name: 'Grass',
      pokemon: this.data
    },
    {
      name: 'Water',
      pokemon: this.data
    },
    {
      name: 'Fire',
      pokemon: this.data
    },
    {
      name: 'Psychic',
      pokemon: this.data
    }
  ];

}


export interface Pokemon {
  value: string;
  viewValue: string;
}

export interface PokemonGroup {
  disabled?: boolean;
  name: string;
  pokemon: Pokemon[];
}