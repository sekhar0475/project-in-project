import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MatScrumDropDownTestComponent } from './mat-scrum-drop-down-test.component';

describe('MatScrumDropDownTestComponent', () => {
  let component: MatScrumDropDownTestComponent;
  let fixture: ComponentFixture<MatScrumDropDownTestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MatScrumDropDownTestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MatScrumDropDownTestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
