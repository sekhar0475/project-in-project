import { Component, OnInit } from '@angular/core';
import { ExcelService } from '../../Services/excel.service';
import { CardcreationService } from '../../Services/cardcreation.service'

@Component({
  selector: 'app-export-to-excel-card-creation-format',
  templateUrl: './export-to-excel-card-creation-format.component.html',
  styleUrls: ['./export-to-excel-card-creation-format.component.css']
})
export class ExportToExcelCardCreationFormatComponent implements OnInit {
  excelDataExport: any;
  data: any = [{
    eid: 'e101',
    ename: 'ravi',
    esal: 1000
  },
  {
    eid: 'e102',
    ename: 'ram',
    esal: 2000
  },
  {
    eid: 'e103',
    ename: 'rajesh',
    esal: 3000
  }];
  constructor(private excelService:ExcelService , private CardcreationService :CardcreationService) { }

  ngOnInit() {
    this.GetExcelForCardCreationRequest();
  }

  GetExcelForCardCreationRequest(){
    this.CardcreationService.GetExcelForCardCreationRequest().subscribe(
      res =>{
            this.excelDataExport = res.table;
      }
    )
  }

  exportAsXLSX():void {
    for (var data in this.excelDataExport )
    {
      data;
    }
    this.data;
    this.excelService.exportAsExcelFile(this.excelDataExport, 'sample');
  }

}
