import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExportToExcelCardCreationFormatComponent } from './export-to-excel-card-creation-format.component';

describe('ExportToExcelCardCreationFormatComponent', () => {
  let component: ExportToExcelCardCreationFormatComponent;
  let fixture: ComponentFixture<ExportToExcelCardCreationFormatComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExportToExcelCardCreationFormatComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExportToExcelCardCreationFormatComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
