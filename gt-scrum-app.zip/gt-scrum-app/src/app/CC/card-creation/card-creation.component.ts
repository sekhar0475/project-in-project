import { Component, OnInit, OnDestroy, ViewChild, AfterViewInit, ViewEncapsulation, TemplateRef } from '@angular/core';
import { ModalService } from '../../Services/modal.service';
import { CardcreationService } from '../../Services/cardcreation.service';
import { BlockUI, NgBlockUI } from 'ng-block-ui';
import { PersonalInformationComponent } from '../personal-information/personal-information.component';
import { DomSanitizer } from '@angular/platform-browser';
import { SharedState } from 'src/app/Model/Common/InterPage';
import { commonReturnData } from 'src/app/Model/CcModel/commonReturnData';

@Component({
  selector: 'app-card-creation',
  templateUrl: './card-creation.component.html',
  styleUrls: ['./card-creation.component.css'],
   encapsulation: ViewEncapsulation.None
  // styleUrls: [condition ? url1 : url2]
})
export class CardCreationComponent implements OnInit, OnDestroy, AfterViewInit {

  isPersonalInformation: Boolean = true;
  isWorkDetail: Boolean = false;
  isOtherDetail: Boolean = false;
  isApprovals: Boolean = false;
  isAppearanceLinkVisible: Boolean = false;
  showDialog: Boolean = false;
  showRelegionDialog: Boolean = false;
  @BlockUI() blockUI: NgBlockUI;
  test: string = "demo";

  isFirstTabMediaVisible: boolean = true;
  isSecondTabMediaVisible: boolean = true;
  isThirdTabMediaVisible: boolean = true;
  isFourthTabMediaVisible: boolean = true;


  currentActiveModule: string = 'isCard';
  isPersonalDetailProceed: boolean = false;
  isWorkDetailProceed: boolean = false;
  isOtherDetailProceed: boolean = false;

  isApprovalProceed: boolean = false;
  isViewPersonalParent: string = 'parent';
  @ViewChild(PersonalInformationComponent, { static: true }) isViewPersonalInfo: PersonalInformationComponent;
  epCode: string = '0';

  resCode: string = '0';
  cssUrl: any;
  cssUrlStyle: any;
  shared : SharedState = new SharedState();

  commonReturnData : commonReturnData;

 

  isHCUi : boolean ;
// breadcrumbRedirection : string ;
  @ViewChild('otherContent' , {static:false})
  private defaultTabButtonsTpl: TemplateRef<any>;

  constructor(private CardcreationService: CardcreationService, private sanitizer: DomSanitizer) {
    this.resCode = typeof(window.history.state.resCode) === 'undefined' ? '0' : window.history.state.resCode;
    this.shared  = JSON.parse(atob(localStorage.getItem('shared')));
    console.log('---------card creation component--------------------');
    console.log(this.shared.siteUiCode);
    // this.cssUrl = this.sanitizer.bypassSecurityTrustResourceUrl('../../../assets/main.css');
    // this.cssUrlStyle = this.sanitizer.bypassSecurityTrustStyle('../../../assets/main.css');

  }

  ngOnInit() {
  console.log(this.defaultTabButtonsTpl);
  //this.breadcrumbRedirection = '/dashboard';
    this.isHCUi = true;
    
    this.isViewPersonalParent = this.isViewPersonalInfo.isViewPersonal;
  }

  ngAfterViewInit() {
    this.isViewPersonalParent = this.isViewPersonalInfo.isViewPersonal;
  }

  mouseEvent(div: string) {
    if (div == "mouseEnter") {
      this.isAppearanceLinkVisible = true;
    }
    else {
      this.isAppearanceLinkVisible = false;
    }
    console.log("mouse enter : " + div);
  }

  onEpCodeUpdate(epCode: string) {
    this.epCode = epCode;
  }

  currentActiveModuleEventHander($event: string) {

    switch ($event) {
      case 'isPersonalInfoProceed':
        {
          this.personalDetailCall();
          break;
        }

      case 'isWorkDetailProceed':
        {
          this.workDetailCall();
          break;
        }
      case 'isWorkDetailBack':
        {
          this.isPersonalInformation = true;
          this.isWorkDetail = false;
          this.isOtherDetail = false;
          this.isApprovals = false;
          break;
        }
      case 'isOtherDetailProceed':
        {
          this.otherDetailCall();
          break;
        }
      case 'isOtherDetailBack':
        {
          this.personalDetailCall();
          break;
        }
    }
  }
  onBack() {
    this.workDetailCall();
  }  
  personalDetailCall() {
    this.isPersonalDetailProceed = true;
    this.isPersonalInformation = false;
    this.isWorkDetail = true;
    this.isOtherDetail = false;
    this.isApprovals = false;
    this.isViewPersonalParent = this.isViewPersonalInfo.isViewPersonal;
  }
  workDetailCall() {
    this.isWorkDetailProceed = true;
    this.isPersonalInformation = false;
    this.isWorkDetail = false;
    this.isOtherDetail = true;
    this.isApprovals = false;
    this.isViewPersonalParent = this.isViewPersonalInfo.isViewPersonal;
  }
  otherDetailCall() {
    this.isOtherDetailProceed = true;
    this.isPersonalInformation = false;
    this.isWorkDetail = false;
    this.isOtherDetail = false;
    this.isApprovals = true;
  }

  onTabClick(selectedTab: string) {
    if (selectedTab == "isPersonalInformation") {
      this.isPersonalInformation = true;
      this.isWorkDetail = false;
      this.isOtherDetail = false;
      this.isApprovals = false;
    }
    else if (selectedTab == "isWorkDetail") {
      this.isPersonalInformation = false;
      this.isWorkDetail = true;
      this.isOtherDetail = false;
      this.isApprovals = false;
    }
    else if (selectedTab == "isOtherDetail") {
      this.isPersonalInformation = false;
      this.isWorkDetail = false;
      this.isOtherDetail = true;
      this.isApprovals = false;
    }
    else if (selectedTab == "isApprovals") {
      this.isPersonalInformation = false;
      this.isWorkDetail = false;
      this.isOtherDetail = false;
      this.isApprovals = true;
    }

  }
  onFirstTabh2Click() {
    this.isFirstTabMediaVisible = !this.isFirstTabMediaVisible;
    this.isPersonalInformation = true;
    this.isWorkDetail = false;
    this.isOtherDetail = false;
    this.isApprovals = false;
  }
  onSecondTabh2Click() {
    this.isSecondTabMediaVisible = !this.isSecondTabMediaVisible;
    this.isPersonalInformation = false;
    this.isWorkDetail = true;
    this.isOtherDetail = false;
    this.isApprovals = false;
  }
  onThirdTabh2Click() {
    this.isThirdTabMediaVisible = !this.isThirdTabMediaVisible;
    this.isPersonalInformation = false;
    this.isWorkDetail = false;
    this.isOtherDetail = true;
    this.isApprovals = false;
  }
  onFourthTabh2Click() {
    this.isFourthTabMediaVisible = !this.isFourthTabMediaVisible;
    this.isPersonalInformation = false;
    this.isWorkDetail = false;
    this.isOtherDetail = false;
    this.isApprovals = true;
  }
 
  ngOnDestroy(): void {

  }
}

