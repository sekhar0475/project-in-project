import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CardCreationResourceListComponent } from './card-creation-resource-list.component';

describe('CardCreationResourceListComponent', () => {
  let component: CardCreationResourceListComponent;
  let fixture: ComponentFixture<CardCreationResourceListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CardCreationResourceListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CardCreationResourceListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
