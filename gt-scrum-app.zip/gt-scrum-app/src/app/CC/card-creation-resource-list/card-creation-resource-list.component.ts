import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material';
import * as XLSX from 'xlsx';
import { CardcreationService } from '../../Services/cardcreation.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-card-creation-resource-list',
  templateUrl: './card-creation-resource-list.component.html',
  styleUrls: ['./card-creation-resource-list.component.css']
})
export class CardCreationResourceListComponent {

  displayedColumns = ['ep Code', 'ep Name', 'contractor', 'sector', 'plant', 'department', 'activeStatus'];
  dataSource: MatTableDataSource<resourceData>;
  @ViewChild('TABLE', { static: true }) table: ElementRef;
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;

  selectedStatus: number = 0;
  status: any[] = [
    {value: '0', viewValue: 'Submitted-Approval Pending'},
    {value: '1', viewValue: 'Active'},
    {value: '2', viewValue: 'Validity Expired'},
    {value: '3', viewValue: 'Terminated'}
  ];

  constructor(private cardcreationService: CardcreationService, private router: Router) {
    // Create 100 users
    // const users: UserData[] = [];
    // for (let i = 1; i <= 300; i++) { users.push(createNewUser(i)); }

    // Assign the data to the data source for the table to render
    this.dataSource = new MatTableDataSource();
    this.getCardCreationResourceDetails();
  }

  getCardCreationResourceDetails() {
    this.cardcreationService.getCardCreationResourceDetails(this.selectedStatus).subscribe(
      res => {
        this.dataSource.data = (res);
      }
    )
  }

  changeStatus(changeStatus : any)
  {
    this.selectedStatus = changeStatus.value;
    this.getCardCreationResourceDetails();
    //alert(changeStatus.value);
  }
  /**
   * Set the paginator and sort after the view init since this component will
   * be able to query its view for the initialized paginator and sort.
   */
  ngAfterViewInit() {
    alert('test');
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
    this.dataSource.filter = filterValue;
  }

  cardCreationDetail(data: any) {
    console.log(data);
    this.router.navigateByUrl('cardcreation', { state: { resCode: data.code_0 } });
  }

}
export interface resourceData {
  code_0: string;
  'ep Code': string;
  'ep Name': string;
  contractor: string;
  sector: string;
  plant: string;
  department: string;
  activeStatus: string;
}
