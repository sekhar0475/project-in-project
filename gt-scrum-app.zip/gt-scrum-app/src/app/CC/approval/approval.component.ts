// import { Component, OnInit, Output, EventEmitter, Input, Inject } from '@angular/core';
// import { ApprovalDetailsData } from '../../Model/CcModel/approval';
// import { CardcreationService } from '../../Services/cardcreation.service';
// import { commonReturnData } from 'src/app/Model/CcModel/commonReturnData';
// import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
// import { approvalGridDetails } from '../../Model/CcModel/approvalGridDetails';
// import { Subscription } from 'rxjs';
// import { Router } from '@angular/router';
// import { SharedState } from 'src/app/Model/Common/InterPage';

// export interface DialogData {
//   buttonname: string;
//   message: string;
// }

// @Component({
//   selector: 'app-approval',
//   templateUrl: './approval.component.html',
//   styleUrls: ['./approval.component.css']
// })
// export class ApprovalComponent implements OnInit {

//   approvalDetail: ApprovalDetailsData;
//   showDialog: boolean = false;
//   @Input() resCode: string;
//   @Input() epCode: string;
//   approvalGridDetails: approvalGridDetails[];
//   initVlaue: string = " ";
//   shared : SharedState = new SharedState();

//   @Output() currentActiveModuleEvent = new EventEmitter<string>();
//   commonReturnData: commonReturnData;
//   photo: string;
//   errorMessage: string;
//   subscription: Subscription;


//   constructor(private CardcreationService: CardcreationService, public dialog: MatDialog, private router: Router) {
//     this.approvalDetail = new ApprovalDetailsData();
//     this.shared  = JSON.parse(atob(localStorage.getItem('shared')));
//    }



//   ngOnInit() { this.getApprovalDataTable(); this.getApprovalDataDisplay(); }

//   onBack() { this.currentActiveModuleEvent.emit("isApprovalBack"); }

//   getApprovalDataDisplay() {
//     this.CardcreationService.GetApprovalDetailsData(this.resCode).subscribe(
//       res => {
//         this.approvalDetail = res;
//       }
//     )
//   }
//   getApprovalDataTable() {
//     this.subscription = this.CardcreationService.getApprovalDataTable(this.resCode).subscribe(
//       res => {
//         this.approvalGridDetails = res;
//       },
//       err => {

//       }
//     )
//   }

//   onProceed() {

//     this.CardcreationService.SaveApproval(this.epCode, this.photo).subscribe(
//       res => {
//         this.commonReturnData = res;
//         if (this.commonReturnData.code == 0) {
//           const dialogRef = this.dialog.open(DialogOverview, {
//             width: '250px',
//             data: { buttonname: 'OK', message: this.commonReturnData.message }
//           });
//           dialogRef.afterClosed().subscribe(result => {
//             this.router.navigateByUrl('cardcreation');
//           });

//         }
//         else {
//           this.errorMessage = this.commonReturnData.message;
//         }
//       })
//   }
// }

// @Component({
//   selector: 'dialog-overview-example-dialog',
//   templateUrl: '../scrum-dialog/dialog-overview-example-dialog.html',
// })
// export class DialogOverview {

//   constructor(
//     public dialogRef: MatDialogRef<DialogOverview>,
//     @Inject(MAT_DIALOG_DATA) public data: DialogData) { }

//   onNoClick(): void {
//     this.dialogRef.close();
//   }
// }

