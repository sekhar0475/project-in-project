import {
  Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
  import { trigger, state, style, animate, transition } from '@angular/animations';
  import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

@Component({
  selector: 'app-app-dialog',
  templateUrl: './app-dialog.component.html',
  styleUrls: ['./app-dialog.component.css'],
  animations: [
    trigger('dialog', [
      transition('void => *', [
        style({ transform: 'scale3d(.3, .3, .3)' }),
        animate(100)
      ]),
      transition('* => void', [
        animate(100, style({ transform: 'scale3d(.0, .0, .0)' }))
      ])
    ])
  ]
})
export class AppDialogComponent implements OnInit {
  @Input() isPopoverExpanded :boolean = false ;
  @Input() isPopoverDown :boolean = false ;
  @Input() closable : boolean = true;
  @Input() visible:boolean;
  @Input() moduleName :string;

  @Output() visibleChange: EventEmitter<boolean> = new EventEmitter<boolean>();

  constructor() { }

  ngOnInit() {

  }
  close() {
    this.visible = false;
    this.visibleChange.emit(this.visible);
  }
}
