import { Component, OnInit, OnDestroy, Output, EventEmitter, Input } from '@angular/core';
import { otherDetail } from '../../Model/CcModel/otherDetail';
import { CardcreationService } from '../../Services/cardcreation.service';
import { Subscription } from 'rxjs';
import { commonReturnData } from '../../Model/CcModel/commonReturnData';
import { validationTest } from '../../validationTest';
import { mstDetails } from 'src/app/Model/CcModel/MstDetails';
import { SharedState } from 'src/app/Model/Common/InterPage';

@Component({
  selector: 'app-other-detail',
  templateUrl: './other-detail.component.html',
  styleUrls: ['./other-detail.component.css']
})
export class OtherDetailComponent implements OnInit, OnDestroy {
  @Output() currentActiveModuleEvent = new EventEmitter<string>();
  @Input() resCode: string;
  @Input() epCode: string;
  //otherDetails:otherDetail;
  otherDetails: otherDetail;
  idProofTypeCodes1: any[];
  searchText: string;

  isWordDetailsDropDownVisible: boolean = false;
  wordDetailValue: string = "";
  workDetailIsDirty: boolean = false;
  isPopoverDown: boolean = true;

  isIdProofTypeCode2Visible: boolean = false;
  IdProofTypeCode2Value: string = "";
  IdProofTypeCode2IsDirty: boolean = false;

  EpName: string = "epnamelabel";
  subscription: Subscription;
  commonReturnData: commonReturnData;

  showDialog: boolean = false;
  showReferenceDialog: boolean = false;

  panelOpenState: boolean = false;
  showAddressDialog: boolean = false;
  initVlaue: string = " ";

  isRemarkCodeDropDownVisible: boolean = false;
  CheckFlag: boolean = true;
  remarkCodeIsDirty: boolean = false;
  remarkCodeValue: string = "";
  validationTest: validationTest;
  isOtherDProceed = false;

  ccRemarkDetail : mstDetails;
  bankDetail : mstDetails;
  shared : SharedState = new SharedState();

  errorMessage: string = '';

  constructor(private cardCreationService: CardcreationService) {
    this.otherDetails = new otherDetail();
   this.validationTest = new validationTest();
   this.ccRemarkDetail = new mstDetails();
   this.bankDetail = new mstDetails();
   this.shared  = JSON.parse(atob(localStorage.getItem('shared')));
  }

  ngOnInit() {
    this.getOtherDetailConfiguration();
  }

  getOtherDetailConfiguration() {
    this.subscription = this.cardCreationService.getOtherDetailConfiguration(this.resCode).subscribe(
      res => {
        this.otherDetails = res;

        if (this.otherDetails.ccRemarks.fieldDetail.value != null || (this.otherDetails.ccRemarks.fieldDetail.value == '')) {
          this.ccRemarkDetail.mstcode = this.otherDetails.ccRemarks.fieldDetail.value;
          this.ccRemarkDetail.mstText = this.otherDetails.ccRemarks.listDetails.filter(x => x.mstcode == this.ccRemarkDetail.mstcode)[0].mstText;
          this.setRemarkCodeDetail(this.ccRemarkDetail);
        }
        if (this.otherDetails.bankCode.fieldDetail.value != null || (this.otherDetails.bankCode.fieldDetail.value == '')) {
          this.bankDetail.mstcode = this.otherDetails.bankCode.fieldDetail.value;
          this.bankDetail.mstText = this.otherDetails.bankCode.listDetails.filter(x => x.mstcode == this.bankDetail.mstcode)[0].mstText;
          this.BankDset(this.bankDetail);
        }
        if (this.otherDetails.idProofTypeCode1.fieldDetail.value != null || (this.otherDetails.idProofTypeCode1.fieldDetail.value == '')) {
          this.idProofTypeCode1Value = this.otherDetails.idProofTypeCode1.listDetails.filter(f => f.mstcode == this.otherDetails.idProofTypeCode1.fieldDetail.value)[0].mstText;
          this.idProofTypeCode1IsDirty = true;
        }
        if (this.otherDetails.idProofTypeCode2.fieldDetail.value != null || (this.otherDetails.idProofTypeCode2.fieldDetail.value == '')) {
          this.IdProofTypeCode2Value = this.otherDetails.idProofTypeCode2.listDetails.filter(f => f.mstcode == this.otherDetails.idProofTypeCode2.fieldDetail.value)[0].mstText;
          this.IdProofTypeCode2IsDirty = true;
        }
        if (this.otherDetails.isHandicapped.fieldDetail.value != null) {
          this.otherDetails.isHandicapped.fieldDetail.value = (this.otherDetails.isHandicapped.fieldDetail.value == 'True' ? '1' : '0');
        }
        if (this.otherDetails.isRelative.fieldDetail.value != null) {
          this.otherDetails.isRelative.fieldDetail.value = (this.otherDetails.isRelative.fieldDetail.value == 'True' ? '1' : '0');
        }
        if (this.otherDetails.isMarried.fieldDetail.value != null) {
          this.otherDetails.isMarried.fieldDetail.value = (this.otherDetails.isMarried.fieldDetail.value == 'True' ? '1' : '0');
        }
        if (this.otherDetails.isHibenationException.fieldDetail.value != null) {
          this.otherDetails.isHibenationException.fieldDetail.value = (this.otherDetails.isHibenationException.fieldDetail.value == 'True' ? '1' : '0');
        }
      },
      err => {
      }
    );
  }

  remarkCodeDropDownToggle() {
    this.searchText = '';
    this.isRemarkCodeDropDownVisible = !this.isRemarkCodeDropDownVisible;
  }

  workDetailsDropDownToggle() {
    this.isWordDetailsDropDownVisible = !this.isWordDetailsDropDownVisible;
  }
  idProofTypeCode2Toggle() {
    this.isIdProofTypeCode2Visible = !this.isIdProofTypeCode2Visible;
  }
  setWorkDetail(data: any) {
    this.wordDetailValue = data.mstText;
    this.isWordDetailsDropDownVisible = false;
    //this.otherDetails.passport.countryIdOfOrigin.isMandatory;
    this.workDetailIsDirty = true;
    this.otherDetails.idProofTypeCode1.fieldDetail.value = data.mstcode;
    this.searchText = '';
  }

  setRemarkCodeDetail(data: any) {
    this.otherDetails.ccRemarks.fieldDetail.value = data.mstcode;
    this.remarkCodeValue = data.mstText;
    this.isRemarkCodeDropDownVisible = false;
    this.remarkCodeIsDirty = true;

  }

  setIdProofTypeCode2(data: any) {
    this.IdProofTypeCode2Value = data.mstText;
    this.isIdProofTypeCode2Visible = false;
    this.IdProofTypeCode2IsDirty = true;
    this.otherDetails.idProofTypeCode2.fieldDetail.value = data.mstcode;
    this.searchText = '';
  }
  onBack() {
    this.currentActiveModuleEvent.emit("isOtherDetailBack");
  }
  onPorceed() {
    this.isOtherDProceed = true;

    if (this.validationTest.isRequired(this.otherDetails.bankAccountNo) +
      this.validationTest.isRequired(this.otherDetails.bankBranch) +
      this.validationTest.isRequired(this.otherDetails.bankCode.fieldDetail) +
      this.validationTest.isRequired(this.otherDetails.ccRemarks.fieldDetail) +
      this.validationTest.isRequired(this.otherDetails.ctc) +
      this.validationTest.isRequired(this.otherDetails.grossSalary) +
      this.validationTest.isRequired(this.otherDetails.handicappedReason) +
      this.validationTest.isRequired(this.otherDetails.idProofNo1) +
      this.validationTest.isRequired(this.otherDetails.idProofNo2) +
      this.validationTest.isRequired(this.otherDetails.idProofTypeCode1.fieldDetail) +
      this.validationTest.isRequired(this.otherDetails.idProofTypeCode2.fieldDetail) +
      this.validationTest.isRequired(this.otherDetails.ifscCode) +
      this.validationTest.isRequired(this.otherDetails.idProofTypeCode2) +
      this.validationTest.isRequired(this.otherDetails.marriageDate) +
      this.validationTest.isRequired(this.otherDetails.noOfFemaleChild) +
      this.validationTest.isRequired(this.otherDetails.noOfMaleChild) +
      this.validationTest.isRequired(this.otherDetails.refDLink.refAddress) +
      this.validationTest.isRequired(this.otherDetails.refDLink.refContact) +
      this.validationTest.isRequired(this.otherDetails.refDLink.refAddress) +
      this.validationTest.isRequired(this.otherDetails.refDLink.refName) +
      this.validationTest.isRequired(this.otherDetails.refDLink2.refContact) +
      this.validationTest.isRequired(this.otherDetails.refDLink2.refAddress) +
      this.validationTest.isRequired(this.otherDetails.refDLink2.refName) +
      this.validationTest.isRequired(this.otherDetails.refDLink3.refContact) +
      this.validationTest.isRequired(this.otherDetails.refDLink3.refAddress) +
      this.validationTest.isRequired(this.otherDetails.refDLink3.refName) +
      this.validationTest.isRequired(this.otherDetails.refDLink4.refContact) +
      this.validationTest.isRequired(this.otherDetails.refDLink4.refAddress) +
      this.validationTest.isRequired(this.otherDetails.refDLink4.refName)  +
      this.validationTest.checkAaddharValidNumber(this.otherDetails.idProofNo1,  this.idProofTypeCode1Value   ) +
      this.validationTest.checkAaddharValidNumber(this.otherDetails.idProofNo2,  this.IdProofTypeCode2Value  ) 
      
      == '') {
        
      if (this.otherDetails.isRelative.fieldDetail.value == '1' && this.otherDetails.relativeReason.value == '' && this.otherDetails.relativeReason.isMandatory == true) {
        if (this.validationTest.isRequired(this.otherDetails.relativeReason) != '') {
          this.CheckFlag = false;
        }
      }
      if (this.otherDetails.isHandicapped.fieldDetail.value == '1' && this.otherDetails.handicappedReason.value == '' && this.otherDetails.handicappedReason.isMandatory == true) {
        if (this.validationTest.isRequired(this.otherDetails.handicappedReason) != '') {
          this.CheckFlag = false;
        }
      }
      if (this.otherDetails.isMarried.fieldDetail.value == '1' && this.otherDetails.marriageDate.value == '' && this.otherDetails.marriageDate.isMandatory == true) {
        if (this.validationTest.isRequired(this.otherDetails.marriageDate) != '') {
          this.CheckFlag = false;
        }
      }
      if (this.CheckFlag == true) {
        this.otherDetails.requestDetails.resCode = this.epCode;
        this.cardCreationService.saveOtherDetail(this.otherDetails).subscribe(
          res => {
            if (res.code == 0) {
              this.isOtherDProceed = true;
              this.currentActiveModuleEvent.emit("isOtherDetailProceed");
              this.otherDetails.requestDetails.resCode = this.epCode;
              this.commonReturnData = res;
            }
            else {
              this.errorMessage = res.message;
            }
          }
        );
      }
    }
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }
  BankDsearchText: string;
  BankDIsDropDownVisible: boolean = false;
  BankDValue: string = "";
  BankDIsDirty: boolean = false;
  BankDDropDownToggle() {
    this.BankDIsDropDownVisible = !this.BankDIsDropDownVisible;
  }
  BankDset(data: any) {
    this.BankDValue = data.mstText;
    this.otherDetails.bankCode.fieldDetail.value = data.mstcode;
    this.BankDIsDropDownVisible = false;
    this.BankDIsDirty = true;
  }

  IdProofTypeCode1searchText: string;
  idProofTypeCode1IsDropDownVisible: boolean = false;
  idProofTypeCode1Value: string = "";
  idProofTypeCode1IsDirty: boolean = false;

  idProofTypeCode1DropDownToggle() {
    this.idProofTypeCode1IsDropDownVisible = !this.idProofTypeCode1IsDropDownVisible;
  }
  idProofTypeCode1set(data: any) {
    this.idProofTypeCode1Value = data.mstText;
    this.otherDetails.idProofTypeCode1.fieldDetail.value = data.mstcode;
    this.idProofTypeCode1IsDropDownVisible = false;
    this.idProofTypeCode1IsDirty = true;
  }

}
