import { Component, OnInit, Input, Output, EventEmitter, ViewEncapsulation, OnDestroy } from '@angular/core';
import { NgbDateStruct, NgbCalendar } from '@ng-bootstrap/ng-bootstrap';
import { MatButtonModule, MatCardModule, MatFormFieldModule, MatCheckboxModule, MatDatepickerModule, MatRadioModule, MatSelectModule } from '@angular/material';
import { CardcreationService } from '../../Services/cardcreation.service';
import { personalInfo } from '../../Model/CcModel/personalInfo';
import { dropDownDetail } from '../../Model/CcModel/dropDownDetail';
import { commonReturnData } from '../../Model/CcModel/commonReturnData';
import { fieldDetail } from 'src/app/Model/CcModel/fieldDetail';
import {clscastmodel} from 'src/app/Model/CcModel/clscastmodel';
import { address } from 'src/app/Model/CcModel/address';
import { validationTest } from '../../validationTest';
import { FormControl } from '@angular/forms';
import { Observable } from 'rxjs';
import {
  MatInputModule, DateAdapter, MatNativeDateModule, MatExpansionPanelTitle,
  MatExpansionPanelDescription, MatExpansionPanelHeader, MatExpansionPanel, MatAccordion,
  MAT_DIALOG_DEFAULT_OPTIONS, MatTableModule, MatPaginatorModule, MatSortModule
}
  from '@angular/material';
import { mstDetails } from 'src/app/Model/CcModel/MstDetails';
import { SharedState } from 'src/app/Model/Common/InterPage';

@Component({
  selector: 'app-personal-information',
  templateUrl: './personal-information.component.html',
  styleUrls: ['./personal-information.component.css']
  // encapsulation: ViewEncapsulation.ShadowDom
})
export class PersonalInformationComponent implements OnInit, OnDestroy {
  ngOnDestroy(): void {

  }
  dropdownList = [];
  selectedItems = [];
  dropdownSettings = {};

  @Input() epCode: string;
  @Input() resCode: string;
  @Output() personalInfoEpCodeEvent = new EventEmitter<string>();

  moduleName: string = 'personalInfoModule';
  isPopoverExpanded: boolean = true;
  toppings = new FormControl();

  @Output() currentActiveModuleEvent = new EventEmitter<string>();
  isViewPersonal: string = "child";
  personalInformationConfigDetail: personalInfo;
  micrDisplay: boolean = false;
  model: NgbDateStruct;
  selected: number = 1;
  startDate: any = '';
  showDialog: boolean = false;
  showPassportDialog: boolean = false;
  showRelegionDialog: boolean = false;
  religioncode: string;
  date: { year: number, month: number };
  subcastedata: dropDownDetail[];
  commonReturnData: commonReturnData;

  firstName: string = "My First Name";
  isFirstNameVisible: boolean = false;
  initValue: string = " ";
  type: string = 'StateCode';
  // isPopoverExpanded : boolean = true;

  isStateDirtyLoc: boolean = false;
  isStateDirtyDom: boolean = false;
  isStateDirtyPer: boolean = false;
  isStateCodeDropDownVisible = false;
  stateValueLoc: string = "";
  stateValueDom: string = "";
  stateValuePer: string = "";

  isDistrictDirtyLoc: boolean = false;
  isDistrictDirtyDom: boolean = false;
  isDistrictDirtyPer: boolean = false;
  isDistrictCodeDropDownVisible = false;
  districtValueLoc: string = "";
  districtValueDom: string = "";
  districtValuePer: string = "";

  isTalukaDirtyLoc: boolean = false;
  isTalukaDirtyDom: boolean = false;
  isTalukaDirtyPer: boolean = false;
  isTalukaCodeDropDownVisible = false;
  talukaValueLoc: string = "";
  talukaValueDom: string = "";
  talukaValuePer: string = "";

  isVillegeDirtyLoc: boolean = false;
  isVillegeDirtyDom: boolean = false;
  isVillegeDirtyPer: boolean = false;
  isVillegeCodeDropDownVisible = false;
  villegeValueLoc: string = "";
  villegeValueDom: string = "";
  villegeValuePer: string = "";

  GenderIsDropDownVisible: boolean = false;
  GenderValue: string = "";
  GenderIsDirty: boolean = false;

  ReligionIsDropDownVisible: boolean = false;
  ReligionValue: string = "";
  ReligionIsDirty: boolean = false;

  CastIsDropDownVisible: boolean = false;
  CastValue: string = "";
  CastIsDirty: boolean = false;

  SubcastIsDropDownVisible: boolean = false;
  SubcastValue: string = "";
  SubcastIsDirty: boolean = false;

  QualiIsDropDownVisible: boolean = false;
  QualiValue: string = "";
  QualiIsDirty: boolean = false;

  BloodIsDropDownVisible: boolean = false;
  BloodValue: string = "";
  BloodIsDirty: boolean = false;
  validationTest: validationTest;

  isPersonalInfoProceed: boolean = false;
  isPersonalDetailValidated: boolean = true;

  showAddressDialog: boolean = false;
  QualisearchText: any;
  errorMessage: string = '';

  searchText: string = '';
  PerStatesearchText: string = '';
  PerDistrictsearchText: string = '';
  PertalukasearchText: string = '';
  PerVillagesearchText: string = '';
  locstatesearchText: string = '';
  locdistictsearchText: string = '';
  loctalukasearchText: string = '';
  locvillagesearchText: string = '';
  domstatesearchText: string = '';
  domdistrictsearchText: string = '';
  domTalukasearchText: string = '';
  domVillagesearchText: string = '';

  shared : SharedState = new SharedState();

  selectedCasteCode: number;
  selectedSubCasteValue: number;

  stateDetail: mstDetails;
  districtDetail: mstDetails;
  talukaDetail: mstDetails;
  mstSectorDetail: clscastmodel;

  constructor(private calendar: NgbCalendar, private CardcreationService: CardcreationService) {
    this.personalInformationConfigDetail = new personalInfo();
    this.validationTest = new validationTest();
    this.stateDetail = new mstDetails();
    this.districtDetail = new mstDetails();
    this.talukaDetail = new mstDetails();
    this.shared  = JSON.parse(atob(localStorage.getItem('shared')));
  }

  ngOnInit() {
    this.dropdownList = [
      { item_id: 1, item_text: 'Mumbai' },
      { item_id: 2, item_text: 'Bangaluru' },
      { item_id: 3, item_text: 'Pune' },
      { item_id: 4, item_text: 'Navsari' },
      { item_id: 5, item_text: 'New Delhi' }
    ];
    this.selectedItems = [
      { item_id: 3, item_text: 'Pune' },
      { item_id: 4, item_text: 'Navsari' }
    ];
    this.dropdownSettings = {
      singleSelection: false,
      idField: 'item_id',
      textField: 'item_text',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      allowSearchFilter: true
    };

    this.personalInformationConfigDetail;
    this.getPersonalInformationConfiguration();
  }
  onItemSelect(item: any) {
    console.log(item);
  }
  onSelectAll(items: any) {
    console.log(items);
  }
  selectToday() {
    this.model = this.calendar.getToday();
  }

  stateDropDownToggle() {
    this.isStateCodeDropDownVisible = !this.isStateCodeDropDownVisible;
  }
  StatePopulatePer(event: any) {
    this.PermanantPincodeStatePopulate('PER', 1);
  }
  StatePopulateLoc(event: any) {
    this.PermanantPincodeStatePopulate('LOC', 1);
  }
  StatePopulateDom(event: any) {
    this.PermanantPincodeStatePopulate('DOM', 1);
  }

  PermanantPincodeStatePopulate(typeOfAddress: string, mode: any) {
    switch (typeOfAddress) {
      case "LOC":
        {

          if (this.personalInformationConfigDetail.locAddType.pinCode.value != null) {
            if (mode == "1") {
              this.stateValuePer = "";
              this.personalInformationConfigDetail.locAddType.stateCode.fieldDetail.value = "";
              this.districtValuePer = "";
              this.personalInformationConfigDetail.locAddType.districtCode.fieldDetail.value = "";
              this.talukaValuePer = "";
              this.personalInformationConfigDetail.locAddType.talukaCode.fieldDetail.value = "";
              this.villegeValuePer = "";
              this.personalInformationConfigDetail.locAddType.villegeCode.fieldDetail.value = "";

              this.personalInformationConfigDetail.locAddType.villegeCode.listDetails = null;
              this.personalInformationConfigDetail.locAddType.talukaCode.listDetails = null;
              this.personalInformationConfigDetail.locAddType.districtCode.listDetails = null;
              this.personalInformationConfigDetail.locAddType.stateCode.listDetails = null;
            }
            this.getAddressDetailsMapping('', 'StateCode', typeOfAddress);
          }
          break;
        }
      case "DOM":
        {
          if (this.personalInformationConfigDetail.domAddType.pinCode.value != null) {
            if (mode == "1") {
              this.stateValuePer = "";
              this.personalInformationConfigDetail.domAddType.stateCode.fieldDetail.value = "";
              this.districtValuePer = "";
              this.personalInformationConfigDetail.domAddType.districtCode.fieldDetail.value = "";
              this.talukaValuePer = "";
              this.personalInformationConfigDetail.domAddType.talukaCode.fieldDetail.value = "";
              this.villegeValuePer = "";
              this.personalInformationConfigDetail.domAddType.villegeCode.fieldDetail.value = "";

              this.personalInformationConfigDetail.domAddType.villegeCode.listDetails = null;
              this.personalInformationConfigDetail.domAddType.talukaCode.listDetails = null;
              this.personalInformationConfigDetail.domAddType.districtCode.listDetails = null;
              this.personalInformationConfigDetail.domAddType.stateCode.listDetails = null;
            }

            this.getAddressDetailsMapping('', 'StateCode', typeOfAddress);
          }
          break;
        }
      case "PER":
        {
          if (this.personalInformationConfigDetail.perAddType.pinCode.value != null) {
            if (mode == "1") {
              this.stateValuePer = "";
              this.personalInformationConfigDetail.perAddType.stateCode.fieldDetail.value = "";
              this.districtValuePer = "";
              this.personalInformationConfigDetail.perAddType.districtCode.fieldDetail.value = "";
              this.talukaValuePer = "";
              this.personalInformationConfigDetail.perAddType.talukaCode.fieldDetail.value = "";
              this.villegeValuePer = "";
              this.personalInformationConfigDetail.perAddType.villegeCode.fieldDetail.value = "";

              this.personalInformationConfigDetail.perAddType.villegeCode.listDetails = null;
              this.personalInformationConfigDetail.perAddType.talukaCode.listDetails = null;
              this.personalInformationConfigDetail.perAddType.districtCode.listDetails = null;
              this.personalInformationConfigDetail.perAddType.stateCode.listDetails = null;
            }
            this.getAddressDetailsMapping('', 'StateCode', typeOfAddress);
            break;
          }
        }
    }
  }

  setStateDetail(data: any, typeOfAddress: string) {

    switch (typeOfAddress) {
      case "LOC":
        {
          this.personalInformationConfigDetail.locAddType.stateCode.fieldDetail.value = data.mstcode;
          this.stateValueLoc = data.mstText;
          this.isStateDirtyLoc = true;
          break;
        }
      case "DOM":
        {
          this.personalInformationConfigDetail.domAddType.stateCode.fieldDetail.value = data.mstcode;
          this.stateValueDom = data.mstText;
          this.isStateDirtyDom = true;
          break;
        }
      case "PER":
        {
          this.personalInformationConfigDetail.perAddType.stateCode.fieldDetail.value = data.mstcode;
          this.stateValuePer = data.mstText;
          this.isStateDirtyPer = true;
          break;
        }
    }

    this.stateDropDownToggle();
    this.getAddressDetailsMapping('', 'DistrictCode', typeOfAddress);
  }

  districtDropDownToggle() {
    this.isDistrictCodeDropDownVisible = !this.isDistrictCodeDropDownVisible;
  }
  setDistrictDetail(data: any, typeOfAddress: string) {
    switch (typeOfAddress) {
      case "LOC":
        {
          this.personalInformationConfigDetail.locAddType.districtCode.fieldDetail.value = data.mstcode;
          this.districtValueLoc = data.mstText;
          this.isDistrictDirtyLoc = true;
          break;
        }
      case "DOM":
        {
          this.personalInformationConfigDetail.domAddType.districtCode.fieldDetail.value = data.mstcode;
          this.districtValueDom = data.mstText;
          this.isDistrictDirtyDom = true;
          break;
        }
      case "PER":
        {
          this.personalInformationConfigDetail.perAddType.districtCode.fieldDetail.value = data.mstcode;
          this.districtValuePer = data.mstText;
          this.isDistrictDirtyPer = true;
          break;
        }
    }

    this.districtDropDownToggle();
    this.getAddressDetailsMapping('', 'TalukaCode', typeOfAddress);
  }
  talukaDropDownToggle() {
    this.isTalukaCodeDropDownVisible = !this.isTalukaCodeDropDownVisible;
  }
  setTalukaDetail(data: any, typeOfAddress: string) {
    switch (typeOfAddress) {
      case "LOC":
        {
          this.personalInformationConfigDetail.locAddType.talukaCode.fieldDetail.value = data.mstcode;
          this.talukaValueLoc = data.mstText;
          this.isTalukaDirtyLoc = true;
          break;
        }
      case "DOM":
        {
          this.personalInformationConfigDetail.domAddType.talukaCode.fieldDetail.value = data.mstcode;
          this.talukaValueDom = data.mstText;
          this.isTalukaDirtyDom = true;
          break;
        }
      case "PER":
        {
          this.personalInformationConfigDetail.perAddType.talukaCode.fieldDetail.value = data.mstcode;
          this.talukaValuePer = data.mstText;
          this.isTalukaDirtyPer = true;
          break;
        }
    }

    this.talukaDropDownToggle();
    this.getAddressDetailsMapping('', 'VillegeCode', typeOfAddress);
  }

  villegeDropDownToggle() {
    this.isVillegeCodeDropDownVisible = !this.isVillegeCodeDropDownVisible;
  }
  setVillegeDetail(data: any, typeOfAddress: String) {
    switch (typeOfAddress) {
      case "LOC":
        {
          this.personalInformationConfigDetail.locAddType.villegeCode.fieldDetail.value = data.mstcode;
          this.villegeValueLoc = data.mstText;
          this.isVillegeDirtyLoc = true;
          break;
        }
      case "DOM":
        {
          this.personalInformationConfigDetail.domAddType.villegeCode.fieldDetail.value = data.mstcode;
          this.villegeValueDom = data.mstText;
          this.isVillegeDirtyDom = true;
          break;
        }
      case "PER":
        {
          this.personalInformationConfigDetail.perAddType.villegeCode.fieldDetail.value = data.mstcode;
          this.villegeValuePer = data.mstText;
          this.isVillegeDirtyPer = true;
          break;
        }
    }

    this.villegeDropDownToggle();
  }
  // get personal information configuration details (cloumns and their respective configurations)
  getPersonalInformationConfiguration() {
    this.CardcreationService.getPersonalInformationConfiguration(this.resCode).subscribe(
      res => {
        this.personalInformationConfigDetail = res;
        this.isFirstNameVisible = this.personalInformationConfigDetail.firstName.isDisplayed;
        if (this.personalInformationConfigDetail.gender.fieldDetail.value != null) {
          this.GenderValue = this.personalInformationConfigDetail.gender.listDetails.filter(f => f.mstcode == this.personalInformationConfigDetail.gender.fieldDetail.value)[0].mstText;
          this.personalInformationConfigDetail.gender.fieldDetail.value = this.GenderValue;
          this.GenderIsDirty = true;
        }
        if (this.personalInformationConfigDetail.qualificationCode.fieldDetail.value != null) {
          this.QualiValue = this.personalInformationConfigDetail.qualificationCode.listDetails.filter(f => f.mstcode == this.personalInformationConfigDetail.qualificationCode.fieldDetail.value)[0].mstText;

          this.QualiIsDirty = true;
        }
        if (this.personalInformationConfigDetail.bloodGroup.fieldDetail.value != null) {
          this.BloodValue = this.personalInformationConfigDetail.bloodGroup.listDetails.filter(f => f.mstcode == this.personalInformationConfigDetail.bloodGroup.fieldDetail.value)[0].mstText;
          this.personalInformationConfigDetail.bloodGroup.fieldDetail.value = this.BloodValue;
          this.BloodIsDirty = true;
        }
        if (this.personalInformationConfigDetail.religionCode.fieldDetail.value != null) {
          this.ReligionValue = this.personalInformationConfigDetail.religionCode.listDetails.filter(f => f.mstcode == this.personalInformationConfigDetail.religionCode.fieldDetail.value)[0].mstText;
          this.ReligionIsDirty = true;
        }
       
        if (this.personalInformationConfigDetail.domAddType.pinCode.value != null) {
          this.PermanantPincodeStatePopulate('DOM', 0);
          this.getAddressDetailsMapping('', 'VillegeCode', 'DOM');
          
        }
        if (this.personalInformationConfigDetail.locAddType.pinCode.value != null) {
          this.PermanantPincodeStatePopulate('LOC', 0);
        
          this.getAddressDetailsMapping('', 'VillegeCode', 'LOC');
        }
        if (this.personalInformationConfigDetail.perAddType.pinCode.value != null) {

          this.PermanantPincodeStatePopulate('PER', 0);
        
          this.getAddressDetailsMapping('', 'VillegeCode', 'PER');
        }
        if (this.personalInformationConfigDetail.castesList.casteFieldDetail.value != null) {
        
            this.CastValue = this.personalInformationConfigDetail.castesList.casteListDetails.filter(f => f.code ==  this.personalInformationConfigDetail.castesList.casteFieldDetail.value)[0].name;
            this.mstSectorDetail.name = this.CastValue
            this.mstSectorDetail.code = this.personalInformationConfigDetail.castesList.casteFieldDetail.value
            this.mstSectorDetail.subCasteListDetails = this.personalInformationConfigDetail.castesList.casteListDetails.filter(f => f.code ==  this.personalInformationConfigDetail.castesList.casteFieldDetail.value)[0].subCasteListDetails;
            this.castset(this.mstSectorDetail);
            this.CastIsDirty = true;
                
      }
      if (this.personalInformationConfigDetail.castesList.subCasteFieldDetail.value != null) 
      {
        this.SubcastValue =  this.personalInformationConfigDetail.castesList.casteListDetails.filter(f => f.code ==  this.personalInformationConfigDetail.castesList.casteFieldDetail.value)[0].subCasteListDetails.filter(d => d.mstcode == this.personalInformationConfigDetail.castesList.subCasteFieldDetail.value )[0].mstText;
        this.SubcastIsDirty = true;
      }
      }
    )
  }

  copyPermanentAddress(data: any, type: string) {
    if (data.checked) {
      switch (type) {
        case 'LOC': {
          this.personalInformationConfigDetail.locAddType = this.personalInformationConfigDetail.perAddType;

          this.stateValueLoc = this.stateValuePer;
          this.isStateDirtyLoc = true;


          this.districtValueLoc = this.districtValuePer;
          this.isDistrictDirtyLoc = true;


          this.talukaValueLoc = this.talukaValuePer;
          this.isTalukaDirtyLoc = true;

          this.villegeValueLoc = this.villegeValuePer;
          this.isVillegeDirtyLoc = true;

          break;
        }
        case 'DOM': {
          this.personalInformationConfigDetail.domAddType = this.personalInformationConfigDetail.perAddType;
          this.stateValueDom = this.stateValuePer;
          this.isStateDirtyDom = true;


          this.districtValueDom = this.districtValuePer;
          this.isDistrictDirtyDom = true;


          this.talukaValueDom = this.talukaValuePer;
          this.isTalukaDirtyDom = true;

          this.villegeValueDom = this.villegeValuePer;
          this.isVillegeDirtyDom = true;
        }
      }
    }

  }
  //get all the address related list here eg. state list, district list etc
  getAddressDetailsMapping(strSiteCode: string, type: string, typeOfAddress: string) {
    switch (typeOfAddress) {
      case "DOM":
        {
          this.CardcreationService.getAddressMapping('1', type, this.personalInformationConfigDetail.domAddType).subscribe(
            res => {
              this.personalInformationConfigDetail.domAddType = res;


              if (this.personalInformationConfigDetail.domAddType.stateCode.fieldDetail.value != null) {
                this.stateValueDom = this.personalInformationConfigDetail.domAddType.stateCode.listDetails.filter(f => f.mstcode == this.personalInformationConfigDetail.domAddType.stateCode.fieldDetail.value)[0].mstText;
                this.isStateDirtyDom = true;
              }              
              if (this.personalInformationConfigDetail.domAddType.districtCode.fieldDetail.value != null) {
                this.districtValueDom = this.personalInformationConfigDetail.domAddType.districtCode.listDetails.filter(f => f.mstcode == this.personalInformationConfigDetail.domAddType.districtCode.fieldDetail.value)[0].mstText;
                this.isDistrictDirtyDom = true;
              }
              if (this.personalInformationConfigDetail.domAddType.talukaCode.fieldDetail.value != null) {
                this.talukaValueDom = this.personalInformationConfigDetail.domAddType.talukaCode.listDetails.filter(f => f.mstcode == this.personalInformationConfigDetail.domAddType.talukaCode.fieldDetail.value)[0].mstText;
                this.isTalukaDirtyDom = true;
              }
              if (this.personalInformationConfigDetail.domAddType.villegeCode.fieldDetail.value != null &&  type =='VillegeCode') {

                this.villegeValueDom = this.personalInformationConfigDetail.domAddType.villegeCode.listDetails.filter(f => f.mstcode == this.personalInformationConfigDetail.domAddType.villegeCode.fieldDetail.value)[0].mstText;
                this.isVillegeDirtyDom = true;
              }
            }
          );
          break;
        }
      case "PER":
        {
          this.CardcreationService.getAddressMapping('1', type, this.personalInformationConfigDetail.perAddType).subscribe(
            res => {
              this.personalInformationConfigDetail.perAddType = res;

              if (this.personalInformationConfigDetail.perAddType.stateCode.fieldDetail.value != null) {
                this.stateValuePer = this.personalInformationConfigDetail.perAddType.stateCode.listDetails.filter(f => f.mstcode == this.personalInformationConfigDetail.perAddType.stateCode.fieldDetail.value)[0].mstText;
                this.isStateDirtyPer = true;
              }
              if (this.personalInformationConfigDetail.perAddType.districtCode.fieldDetail.value != null) {
                this.districtValuePer = this.personalInformationConfigDetail.perAddType.districtCode.listDetails.filter(f => f.mstcode == this.personalInformationConfigDetail.perAddType.districtCode.fieldDetail.value)[0].mstText;
                this.isDistrictDirtyPer = true;
              }
              if (this.personalInformationConfigDetail.perAddType.talukaCode.fieldDetail.value != null) {
                this.talukaValuePer = this.personalInformationConfigDetail.perAddType.talukaCode.listDetails.filter(f => f.mstcode == this.personalInformationConfigDetail.perAddType.talukaCode.fieldDetail.value)[0].mstText;
                this.isTalukaDirtyPer= true;
              }
              if (this.personalInformationConfigDetail.perAddType.villegeCode.fieldDetail.value != null &&  type =='VillegeCode') {

                this.villegeValuePer = this.personalInformationConfigDetail.perAddType.villegeCode.listDetails.filter(f => f.mstcode == this.personalInformationConfigDetail.perAddType.villegeCode.fieldDetail.value)[0].mstText;
                this.isVillegeDirtyPer = true;
              }
            }
          );
          break;
        }
      case "LOC":
        {
          this.CardcreationService.getAddressMapping('1', type, this.personalInformationConfigDetail.locAddType).subscribe(
            res => {
              this.personalInformationConfigDetail.locAddType = res;
              if (this.personalInformationConfigDetail.locAddType.stateCode.fieldDetail.value != null) {
                this.stateValueLoc = this.personalInformationConfigDetail.locAddType.stateCode.listDetails.filter(f => f.mstcode == this.personalInformationConfigDetail.locAddType.stateCode.fieldDetail.value)[0].mstText;
                this.isStateDirtyLoc = true;
              }
              if (this.personalInformationConfigDetail.locAddType.districtCode.fieldDetail.value != null) {
                this.districtValueLoc = this.personalInformationConfigDetail.locAddType.districtCode.listDetails.filter(f => f.mstcode == this.personalInformationConfigDetail.locAddType.districtCode.fieldDetail.value)[0].mstText;
                this.isDistrictDirtyLoc = true;
              }
              if (this.personalInformationConfigDetail.locAddType.talukaCode.fieldDetail.value != null) {
                this.talukaValueLoc = this.personalInformationConfigDetail.locAddType.talukaCode.listDetails.filter(f => f.mstcode == this.personalInformationConfigDetail.locAddType.talukaCode.fieldDetail.value)[0].mstText;
                this.isTalukaDirtyLoc = true;
              }
              if (this.personalInformationConfigDetail.locAddType.villegeCode.fieldDetail.value != null &&  type =='VillegeCode') {

                this.villegeValueLoc = this.personalInformationConfigDetail.locAddType.villegeCode.listDetails.filter(f => f.mstcode == this.personalInformationConfigDetail.locAddType.villegeCode.fieldDetail.value)[0].mstText;
                this.isVillegeDirtyLoc = true;
              }
            }
          );
          break;
        }
    }
  }

  onBack() {
    this.currentActiveModuleEvent.emit("isPersonalInfoBack");
  }
  //triggers when proceed button is clicked . here after validation we are saving records in database.
  proceedClick() {
    this.isPersonalInfoProceed = true;
    if (
      this.validationTest.isRequired(this.personalInformationConfigDetail.firstName) +
      this.validationTest.isRequired(this.personalInformationConfigDetail.middleName) +
      this.validationTest.isRequired(this.personalInformationConfigDetail.lastName) +
      this.validationTest.isRequired(this.personalInformationConfigDetail.fatherName) +
      this.validationTest.isRequired(this.personalInformationConfigDetail.motherName) +
      this.validationTest.isRequired(this.personalInformationConfigDetail.emailID) +
      this.validationTest.isEmail(this.personalInformationConfigDetail.emailID) +
      this.validationTest.isRequired(this.personalInformationConfigDetail.phoneNo) +
      this.validationTest.isRequired(this.personalInformationConfigDetail.emerContactNo) +
      this.validationTest.isRequired(this.personalInformationConfigDetail.imeiNo) +
      this.validationTest.isRequired(this.personalInformationConfigDetail.dob) +
      this.validationTest.isRequired(this.personalInformationConfigDetail.gender.fieldDetail) +
      this.validationTest.isRequired(this.personalInformationConfigDetail.bloodGroup.fieldDetail) +
      this.validationTest.isRequired(this.personalInformationConfigDetail.experience) +

      this.validationTest.isRequired(this.personalInformationConfigDetail.height) +
      this.validationTest.isRequired(this.personalInformationConfigDetail.weight) +
      this.validationTest.isRequired(this.personalInformationConfigDetail.hairColor) +
      this.validationTest.isRequired(this.personalInformationConfigDetail.eyeColor) +

      this.validationTest.isRequired(this.personalInformationConfigDetail.religionCode.fieldDetail) +
      this.validationTest.isRequired(this.personalInformationConfigDetail.castesList.casteFieldDetail) +

      this.validationTest.isRequired(this.personalInformationConfigDetail.locAddType.stateCode.fieldDetail) +
      this.validationTest.isRequired(this.personalInformationConfigDetail.locAddType.districtCode.fieldDetail) +
      this.validationTest.isRequired(this.personalInformationConfigDetail.locAddType.talukaCode.fieldDetail) +
      this.validationTest.isRequired(this.personalInformationConfigDetail.locAddType.villegeCode.fieldDetail) +
      this.validationTest.isRequired(this.personalInformationConfigDetail.locAddType.policeStation) +
      this.validationTest.isRequired(this.personalInformationConfigDetail.locAddType.addLine1) +
      this.validationTest.isRequired(this.personalInformationConfigDetail.locAddType.addLine2) +
      this.validationTest.isRequired(this.personalInformationConfigDetail.locAddType.addLine3) +
      this.validationTest.isRequired(this.personalInformationConfigDetail.locAddType.pinCode) +

      this.validationTest.isRequired(this.personalInformationConfigDetail.perAddType.stateCode.fieldDetail) +
      this.validationTest.isRequired(this.personalInformationConfigDetail.perAddType.districtCode.fieldDetail) +
      this.validationTest.isRequired(this.personalInformationConfigDetail.perAddType.talukaCode.fieldDetail) +
      this.validationTest.isRequired(this.personalInformationConfigDetail.perAddType.villegeCode.fieldDetail) +
      this.validationTest.isRequired(this.personalInformationConfigDetail.perAddType.policeStation) +
      this.validationTest.isRequired(this.personalInformationConfigDetail.perAddType.addLine1) +
      this.validationTest.isRequired(this.personalInformationConfigDetail.perAddType.addLine2) +
      this.validationTest.isRequired(this.personalInformationConfigDetail.perAddType.addLine3) +
      this.validationTest.isRequired(this.personalInformationConfigDetail.perAddType.pinCode) +      

      this.validationTest.isRequired(this.personalInformationConfigDetail.domAddType.stateCode.fieldDetail) +
      this.validationTest.isRequired(this.personalInformationConfigDetail.domAddType.districtCode.fieldDetail) +
      this.validationTest.isRequired(this.personalInformationConfigDetail.domAddType.talukaCode.fieldDetail) +
      this.validationTest.isRequired(this.personalInformationConfigDetail.domAddType.villegeCode.fieldDetail) +
      this.validationTest.isRequired(this.personalInformationConfigDetail.domAddType.policeStation) +
      this.validationTest.isRequired(this.personalInformationConfigDetail.domAddType.addLine1) +
      this.validationTest.isRequired(this.personalInformationConfigDetail.domAddType.addLine2) +
      this.validationTest.isRequired(this.personalInformationConfigDetail.domAddType.addLine3) +
      this.validationTest.isRequired(this.personalInformationConfigDetail.domAddType.pinCode) +

      this.validationTest.isRequired(this.personalInformationConfigDetail.isIndian.fieldDetail) +

      this.validationTest.isRequiredFronRadioSelected(this.personalInformationConfigDetail.isIndian.fieldDetail, this.personalInformationConfigDetail.passportNumber) +
      this.validationTest.isRequiredFronRadioSelected(this.personalInformationConfigDetail.isIndian.fieldDetail ,this.personalInformationConfigDetail.passportValidFrom) +
      this.validationTest.isRequiredFronRadioSelected(this.personalInformationConfigDetail.isIndian.fieldDetail ,this.personalInformationConfigDetail.passportValidTo) +
      this.validationTest.isRequiredFronRadioSelected(this.personalInformationConfigDetail.isIndian.fieldDetail ,this.personalInformationConfigDetail.visaDetails)

      == ''
    ) {

      this.personalInformationConfigDetail.requestDetails.resCode = this.resCode;

      this.personalInformationConfigDetail.firstName.label;
      this.CardcreationService.SavePersonalInformation(this.personalInformationConfigDetail).subscribe(
        res => {
          if (res.code == 0) {
            this.errorMessage = res.message;
          }
          else {
           
            this.isViewPersonal = 'isViewPersonal';
            this.getAddressDetailsMapping('', this.type, 'DOM');
            this.currentActiveModuleEvent.emit("isPersonalInfoProceed");
            this.epCode = res.code;
            this.personalInformationConfigDetail.requestDetails.resCode = res.code;
            this.personalInfoEpCodeEvent.emit(this.epCode);
          }
        }
      )
    }
  }
  validateaddress()
  {
    this.isPersonalInfoProceed = true;
    if (
          this.validationTest.isRequired(this.personalInformationConfigDetail.locAddType.stateCode.fieldDetail) +
          this.validationTest.isRequired(this.personalInformationConfigDetail.locAddType.districtCode.fieldDetail) +
          this.validationTest.isRequired(this.personalInformationConfigDetail.locAddType.talukaCode.fieldDetail) +
          this.validationTest.isRequired(this.personalInformationConfigDetail.locAddType.villegeCode.fieldDetail) +
          this.validationTest.isRequired(this.personalInformationConfigDetail.locAddType.policeStation) +
          this.validationTest.isRequired(this.personalInformationConfigDetail.locAddType.addLine1) +
          this.validationTest.isRequired(this.personalInformationConfigDetail.locAddType.addLine2) +
          this.validationTest.isRequired(this.personalInformationConfigDetail.locAddType.addLine3) +
          this.validationTest.isRequired(this.personalInformationConfigDetail.locAddType.pinCode) +

          this.validationTest.isRequired(this.personalInformationConfigDetail.perAddType.stateCode.fieldDetail) +
          this.validationTest.isRequired(this.personalInformationConfigDetail.perAddType.districtCode.fieldDetail) +
          this.validationTest.isRequired(this.personalInformationConfigDetail.perAddType.talukaCode.fieldDetail) +
          this.validationTest.isRequired(this.personalInformationConfigDetail.perAddType.villegeCode.fieldDetail) +
          this.validationTest.isRequired(this.personalInformationConfigDetail.perAddType.policeStation) +
          this.validationTest.isRequired(this.personalInformationConfigDetail.perAddType.addLine1) +
          this.validationTest.isRequired(this.personalInformationConfigDetail.perAddType.addLine2) +
          this.validationTest.isRequired(this.personalInformationConfigDetail.perAddType.addLine3) +
          this.validationTest.isRequired(this.personalInformationConfigDetail.perAddType.pinCode) +      

          this.validationTest.isRequired(this.personalInformationConfigDetail.domAddType.stateCode.fieldDetail) +
          this.validationTest.isRequired(this.personalInformationConfigDetail.domAddType.districtCode.fieldDetail) +
          this.validationTest.isRequired(this.personalInformationConfigDetail.domAddType.talukaCode.fieldDetail) +
          this.validationTest.isRequired(this.personalInformationConfigDetail.domAddType.villegeCode.fieldDetail) +
          this.validationTest.isRequired(this.personalInformationConfigDetail.domAddType.policeStation) +
          this.validationTest.isRequired(this.personalInformationConfigDetail.domAddType.addLine1) +
          this.validationTest.isRequired(this.personalInformationConfigDetail.domAddType.addLine2) +
          this.validationTest.isRequired(this.personalInformationConfigDetail.domAddType.addLine3) +
          this.validationTest.isRequired(this.personalInformationConfigDetail.domAddType.pinCode) 
          == ''
    ) {}
  }
  validateapperance()
  {
    this.validationTest.isRequired(this.personalInformationConfigDetail.height) +
      this.validationTest.isRequired(this.personalInformationConfigDetail.weight) +
      this.validationTest.isRequired(this.personalInformationConfigDetail.hairColor) +
      this.validationTest.isRequired(this.personalInformationConfigDetail.eyeColor) +
      this.validationTest.isRequired(this.personalInformationConfigDetail.idMark) 
  }
  validateCastdetails()
  {
    this.validationTest.isRequired(this.personalInformationConfigDetail.religionCode.fieldDetail) +
    this.validationTest.isRequired(this.personalInformationConfigDetail.castesList.casteFieldDetail) +
    this.validationTest.isRequired(this.personalInformationConfigDetail.castesList.subCasteFieldDetail) 
  }
  validatePassportdetails()
  {
    this.validationTest.isRequiredFronRadioSelected(this.personalInformationConfigDetail.isIndian.fieldDetail, this.personalInformationConfigDetail.passportNumber) +
    this.validationTest.isRequiredFronRadioSelected(this.personalInformationConfigDetail.isIndian.fieldDetail ,this.personalInformationConfigDetail.passportValidFrom) +
    this.validationTest.isRequiredFronRadioSelected(this.personalInformationConfigDetail.isIndian.fieldDetail ,this.personalInformationConfigDetail.passportValidTo) +
    this.validationTest.isRequiredFronRadioSelected(this.personalInformationConfigDetail.isIndian.fieldDetail ,this.personalInformationConfigDetail.visaDetails)

  }

  ReligionDropDownToggle() {
    this.ReligionIsDropDownVisible = !this.ReligionIsDropDownVisible;
  }
  Religionset(data: any) {
    this.ReligionValue = data.mstText;
    this.personalInformationConfigDetail.religionCode.fieldDetail.value = data.mstcode;
    this.ReligionIsDropDownVisible = false;
    this.ReligionIsDirty = true;
  }

  CastDropDownToggle() {
    this.CastIsDropDownVisible = !this.CastIsDropDownVisible;
  }

  castset(data: any) {
    this.CastValue = data.name;
    this.personalInformationConfigDetail.castesList.casteFieldDetail.value = data.code;
    this.CastIsDropDownVisible = false;
    this.CastIsDirty = true;
    this.subcastedata = data.subCasteListDetails;
  }

  QualiDropDownToggle() {
    this.QualiIsDropDownVisible = !this.QualiIsDropDownVisible;
  }
  Qualiset(data: any) {
    this.QualiValue = data.mstText;
    this.personalInformationConfigDetail.qualificationCode.fieldDetail.value = data.mstcode;
    this.QualiIsDropDownVisible = false;
    this.QualiIsDirty = true;
  }

  BloodDropDownToggle() {
    this.BloodIsDropDownVisible = !this.BloodIsDropDownVisible;
  }

  Bloodset(data: any) {
    this.BloodValue = data.mstText;
    this.personalInformationConfigDetail.bloodGroup.fieldDetail.value = data.mstcode;
    this.BloodIsDropDownVisible = false;
    this.BloodIsDirty = true;
  }

  SubcastDropDownToggle() {
    this.SubcastIsDropDownVisible = !this.SubcastIsDropDownVisible;
  }
  Subcastset(data: any) {
    this.SubcastValue = data.mstText;
    this.personalInformationConfigDetail.castesList.subCasteFieldDetail.value = data.mstcode;
    this.SubcastIsDropDownVisible = false;
    this.SubcastIsDirty = true;
  }

  GenderDropDownToggle() {
    this.GenderIsDropDownVisible = !this.GenderIsDropDownVisible;
  }

  Genderset(data: any) {
    this.GenderValue = data.mstText;
    this.personalInformationConfigDetail.gender.fieldDetail.value = data.mstcode;
    this.GenderIsDropDownVisible = false;
    this.GenderIsDirty = true;
  }
}
