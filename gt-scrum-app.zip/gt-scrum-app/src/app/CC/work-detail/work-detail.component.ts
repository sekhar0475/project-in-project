import { Component, OnInit, OnDestroy, Output, EventEmitter, Input } from '@angular/core';

import { workDetail } from '../../Model/CcModel/workDetail';
import { CardcreationService } from '../../Services/cardcreation.service';
import { Subscription } from 'rxjs';
import { plant } from '../../Model/CcModel/plant';
import { department } from '../../Model/CcModel/department';
import { trade } from '../../Model/CcModel/trade';
import { workSkill } from '../../Model/CcModel/workSkill';
import { Router } from '@angular/router';
import { FormGroup, FormControl } from '@angular/forms';
import { commonReturnData } from '../../Model/CcModel/commonReturnData';
import { validationTest } from '../../validationTest';
import { mstCollection } from 'src/app/Model/CcModel/mstCollection';
import { mstDetails } from 'src/app/Model/CcModel/MstDetails';
import { IfStmt } from '@angular/compiler';

@Component({
  selector: 'app-work-detail',
  templateUrl: './work-detail.component.html',
  styleUrls: ['./work-detail.component.css']
})

export class WorkDetailComponent implements OnInit, OnDestroy {

  @Output() currentActiveModuleEvent = new EventEmitter<string>();
  @Input() resCode: string;
  @Input() epCode: string;

  errorMessage: string = '';

  commonReturnData: commonReturnData;
  searchText: string;
  workDetailConfiguration: workDetail;
  isPersonalWorkInfoProceed: boolean = false;
  entity: any[];
  showDialog: boolean = false;
  showLocationDialog: boolean = false;

  isWordDetailsDropDownVisible: boolean = false;
  wordDetailValue: string = "";
  workDetailIsDirty: boolean = false;

  isSectorDropDownVisible: boolean = false;
  sectorValue: string = "";
  sectorIsDirty: boolean = false;

  isPlantDropDownVisible: boolean = false;
  plantValue: string = "";
  plantIsDirty: boolean = false;

  isDepartmentDropDownVisible: boolean = false;
  departmentValue: string = "";
  departmentIsDirty: boolean = false;

  isTradeDropDownVisible: boolean = false;
  tradeValue: string = "";
  tradeIsDirty: boolean = false;

  isWorkSkillDropDownVisible: boolean = false;
  workSkillValue: string = "";
  workSkillIsDirty: boolean = false;

  isCardTypeDropDownVisible: boolean = false;
  cardTypeValue: string = "";
  cardTypeIsDirty: boolean = false;

  isAOMDropDownVisible: boolean = false;
  aomValue: string = "";
  aomIsDirty: boolean = false;

  isActivityDropDownVisible: boolean = false;
  activityValue: string = "";
  activityIsDirty: boolean = false;

  isCardCategoryDropDownVisible: boolean = false;
  cardCategoryValue: string = "";
  cardCategoryIsDirty: boolean = false;

  isEicDropDownVisible: boolean = false;
  eicValue: string = "";
  eicIsDirty: boolean = false;

  isLevelDropDownVisible: boolean = false;
  levelValue: string = "";
  levelIsDirty: boolean = false;

  isMgrDropDownVisible: boolean = false;
  mgrValue: string = "";
  mgrIsDirty: boolean = false;

  isJioLocationDropDownVisible: boolean = false;
  jioLocationValue: string = "";
  jioLocationIsDirty: boolean = false;

  isMpDropDownVisible: boolean = false;
  mpValue: string = "";
  mpIsDirty: boolean = false;

  isAreaDropDownVisible: boolean = false;
  areaValue: string = "";
  areaIsDirty: boolean = false;

  isStateDropDownVisible: boolean = false;
  stateValue: string = "";
  stateIsDirty: boolean = false;

  isRegionDropDownVisible: boolean = false;
  regionValue: string = "";
  regionIsDirty: boolean = false;

  isContractorCodeDropDownVisible: boolean = false;
  contractorCodeValue: string = "";
  contractorCodeIsDirty: boolean = false;

  isEsicDropDownVisible: boolean = false;
  esicValue: string = "";
  esicIsDirty: boolean = false;

  isWcDropDownVisible: boolean = false;
  wcValue: string = "";
  wcIsDirty: boolean = false;

  isLicenseNoDropDownVisible: boolean = false;
  licenseNoValue: string = "";
  licenseNoIsDirty: boolean = false;

  isShiftCodeDropDownVisible: boolean = false;
  shiftCodeValue: string = "";
  shiftCodeIsDirty: boolean = false;

  isWeeklyOffCodeWcDropDownVisible: boolean = false;
  weeklyOffCodeValue: string = "";
  weeklyOffCodeIsDirty: boolean = false;

  isJCSearchDropDownVisible: boolean = false;
  JCSearchCodeValue: string = "";
  JCSearchCodeIsDirty: boolean = false;

  subscription: Subscription;
  dropdownList: any[];


  plant: IListDetail = {};
  department: IListDetail = {};
  trade: IListDetail = {};
  workSkill: IListDetail = {};

  href: any;
  people$: object;
  cardType: IListDetail = {};
  aom: IListDetail = {};
  activity: IListDetail = {};
  cardCategory: IListDetail = {};
  eic: IListDetail = {};
  esic: IListDetail = {};
  wc: IListDetail = {};
  licenseNo: IListDetail = {};
  shiftCode: IListDetail = {};
  weeklyOffCode: IListDetail = {};
  validationTest: validationTest;
  initVlaue: string = " ";

  locTypeValue: string = '';
  isLocTypeDropDownVisible: boolean = false;
  locTypeIsDirty: boolean = false;

  mstSectorDetail: mstDetails;
  msDeptDetail: mstDetails;
  ATTStopDate: Date;
  constructor(private CardcreationService: CardcreationService, private Router: Router) {
    this.workDetailConfiguration = new workDetail();
    this.validationTest = new validationTest();
    this.mstSectorDetail = new mstDetails();
    this.msDeptDetail = new mstDetails();
  }

  ngOnInit() {
    // this.workDetailConfiguration.isWC;
    this.href = this.Router.url;
    var obj = [{ name: "John", id: 30 }, { name: "John1", id: 31 }, { name: "John2", id: 32 }];
    this.people$ = obj;
    //this.countries.push({id:'test',name:'twat',code:'rwsr'});
    this.getWorkDetailConfiguration();
    this.getEntityInfo('SHIFTGROUPCODE', 0);
    this.getEntityInfo('WEEKLYOFFCODE', 0);
  }
  // getting field details along with their configuration details
  getWorkDetailConfiguration() {
    this.subscription = this.CardcreationService.getWorkDetailConfiguration(this.resCode).subscribe(
      res => {
        this.workDetailConfiguration = res;
        this.plant = this.workDetailConfiguration.plantCode;
        this.department = this.workDetailConfiguration.deptCode;
        this.trade = this.workDetailConfiguration.tradeCode;
        this.workSkill = this.workDetailConfiguration.workSkillCode;
        this.cardType = this.workDetailConfiguration.cardTypeCode;
        console.log(this.workDetailConfiguration.esicNo.label);

        if (this.workDetailConfiguration.contractorCode.fieldDetail.value != null) {


          this.mstSectorDetail.mstText = this.workDetailConfiguration.contractorCode.listDetails.filter(f => f.mstcode == this.workDetailConfiguration.contractorCode.fieldDetail.value)[0].mstText;
          this.mstSectorDetail.mstcode = this.workDetailConfiguration.contractorCode.fieldDetail.value;
          this.setContractorCodeDetail(this.mstSectorDetail);
        }
        if (this.workDetailConfiguration.workOrderCode.fieldDetail.value != null) {

          this.wordDetailValue = this.workDetailConfiguration.workOrderCode.listDetails.filter(f => f.mstcode == this.workDetailConfiguration.workOrderCode.fieldDetail.value)[0].mstText;

          this.workDetailIsDirty = true;
        }
        if (this.workDetailConfiguration.sectorCode.fieldDetail.value != null) {

          this.sectorValue = this.workDetailConfiguration.sectorCode.listDetails.filter(f => f.mstcode == this.workDetailConfiguration.sectorCode.fieldDetail.value)[0].mstText;

          this.sectorIsDirty = true;

          this.mstSectorDetail.mstText = this.sectorValue;
          this.mstSectorDetail.mstcode = this.workDetailConfiguration.sectorCode.fieldDetail.value;
          this.setSectorDetail(this.mstSectorDetail);
        }
        if (this.workDetailConfiguration.plantCode.fieldDetail.value != null) {

          this.msDeptDetail.mstcode = this.workDetailConfiguration.plantCode.fieldDetail.value;
          this.setPlantDetail(this.msDeptDetail);
        }
        if (this.workDetailConfiguration.workSkillCode.fieldDetail.value != null) {

          this.mstSectorDetail.mstcode = this.workDetailConfiguration.workSkillCode.fieldDetail.value;
          this.setTradeDetail(this.mstSectorDetail);
        }
        if (this.workDetailConfiguration.deptCode.fieldDetail.value != null) {

          this.mstSectorDetail.mstcode = this.workDetailConfiguration.deptCode.fieldDetail.value;
          this.setDepartmentDetail(this.mstSectorDetail);
        }
        if (this.workDetailConfiguration.cardCategoryCode.fieldDetail.value != null) {

          this.mstSectorDetail.mstText = this.workDetailConfiguration.cardCategoryCode.listDetails.filter(f => f.mstcode == this.workDetailConfiguration.cardCategoryCode.fieldDetail.value)[0].mstText;
          this.mstSectorDetail.mstcode = this.workDetailConfiguration.cardCategoryCode.fieldDetail.value;
          this.setCardCategoryDetail(this.mstSectorDetail);
        }
        if (this.workDetailConfiguration.activityCode.fieldDetail.value != null) {

          this.mstSectorDetail.mstcode = this.workDetailConfiguration.activityCode.fieldDetail.value;
          this.setActivityDetail(this.mstSectorDetail);
        }
        if (this.workDetailConfiguration.shiftGroupCode.fieldDetail.value != null) {

          this.mstSectorDetail.mstText = this.workDetailConfiguration.shiftGroupCode.listDetails.filter(f => f.mstcode == this.workDetailConfiguration.shiftGroupCode.fieldDetail.value)[0].mstText;
          this.mstSectorDetail.mstcode = this.workDetailConfiguration.shiftGroupCode.fieldDetail.value;
          this.setShiftCodeDetail(this.mstSectorDetail);
        }
        if (this.workDetailConfiguration.weeklyOffCode.fieldDetail.value != null) {

          this.mstSectorDetail.mstText = this.workDetailConfiguration.weeklyOffCode.listDetails.filter(f => f.mstcode == this.workDetailConfiguration.weeklyOffCode.fieldDetail.value)[0].mstText;
          this.mstSectorDetail.mstcode = this.workDetailConfiguration.weeklyOffCode.fieldDetail.value;
          this.setWeeklyOffCodeDetail(this.mstSectorDetail);
        }
        if (this.workDetailConfiguration.attStopDate.value != null) {

          this.ATTStopDate = new Date(new Date(this.workDetailConfiguration.attStopDate.value));
          this.workDetailConfiguration.attStopDate.value = this.ATTStopDate.toDateString();

        }
        if (this.workDetailConfiguration.attStopDate.value != null) {
          this.ATTStopDate = new Date(new Date(this.workDetailConfiguration.attStopDate.value));
          this.workDetailConfiguration.attStopDate.value = this.ATTStopDate.toDateString();
        }
        if (this.workDetailConfiguration.jcMapping.levelName.fieldDetail.value != null) {

          this.mstSectorDetail.mstText = this.workDetailConfiguration.jcMapping.levelName.listDetails.filter(f => f.mstcode == this.workDetailConfiguration.jcMapping.levelName.fieldDetail.value)[0].mstText;
          this.mstSectorDetail.mstcode = this.workDetailConfiguration.jcMapping.levelName.fieldDetail.value;
          this.setLevelDetail(this.mstSectorDetail, '0');
        }
        if (this.workDetailConfiguration.tradeCode.fieldDetail.value != null) {

          this.tradeIsDirty = true;
        }
        if (this.workDetailConfiguration.isESIC.fieldDetail.value != null) {
          this.workDetailConfiguration.isESIC.fieldDetail.value = (this.workDetailConfiguration.isESIC.fieldDetail.value == 'True' ? '1' : '0');
        }
      }
    )
  }
  workDetailsDropDownToggle() {
    this.searchText = '';
    this.isWordDetailsDropDownVisible = this.workDetailConfiguration.workOrderCode.listDetails ? !this.isWordDetailsDropDownVisible : this.isWordDetailsDropDownVisible;
  }

  locTypeDropDownToggle() {
    this.isLocTypeDropDownVisible = this.workDetailConfiguration.jcMapping.locTypeSearch.listDetails ? !this.isLocTypeDropDownVisible : this.isLocTypeDropDownVisible;
  }

  plantDropDownToggle() {
    this.searchText = '';
    this.isPlantDropDownVisible = this.plant.listDetails.length > 0 ? !this.isPlantDropDownVisible : this.isPlantDropDownVisible;
  }

  sectorDropDownToggle() {
    this.searchText = '';
    this.isSectorDropDownVisible = !this.isSectorDropDownVisible;
  }

  departmentDropDownToggle() {
    this.searchText = '';
    this.isDepartmentDropDownVisible = this.department.listDetails.length > 0 ? !this.isDepartmentDropDownVisible : this.isDepartmentDropDownVisible;
  }

  tradeDropDownToggle() {
    this.searchText = '';
    this.isTradeDropDownVisible = this.trade.listDetails.length > 0 ? !this.isTradeDropDownVisible : this.isTradeDropDownVisible;
  }

  workSkillDropDownToggle() {
    this.searchText = '';
    this.isWorkSkillDropDownVisible = this.workSkill.listDetails.length > 0 ? !this.isWorkSkillDropDownVisible : this.isWorkSkillDropDownVisible;
  }

  cardTypeDropDownToggle() {
    this.searchText = '';
    this.isCardTypeDropDownVisible = this.cardType.listDetails.length > 0 ? !this.isCardTypeDropDownVisible : this.isCardTypeDropDownVisible;
  }

  aomDropDownToggle() {
    this.searchText = '';
    this.isAOMDropDownVisible = this.aom.listDetails.length > 0 ? !this.isAOMDropDownVisible : this.isAOMDropDownVisible;
  }

  activityDropDownToggle() {
    this.searchText = '';
    this.isActivityDropDownVisible = this.activity.listDetails.length > 0 ? !this.isActivityDropDownVisible : this.isActivityDropDownVisible;
  }

  cardCategoryDropDownToggle() {
    this.searchText = '';
    this.isCardCategoryDropDownVisible = !this.isCardCategoryDropDownVisible;
  }

  eicDropDownToggle() {
    this.searchText = '';
    this.isEicDropDownVisible = !this.isEicDropDownVisible;
  }

  levelDropDownToggle() {
    this.searchText = '';
    this.isLevelDropDownVisible = !this.isLevelDropDownVisible;
  }

  mgrDropDownToggle() {
    this.searchText = '';
    this.isMgrDropDownVisible = !this.isMgrDropDownVisible;
  }

  jioLocationDropDownToggle() {
    this.searchText = '';
    this.isJioLocationDropDownVisible = !this.isJioLocationDropDownVisible;
  }

  mpDropDownToggle() {
    this.searchText = '';
    this.isMpDropDownVisible = !this.isMpDropDownVisible;
  }

  areaDropDownToggle() {
    this.searchText = '';
    this.isAreaDropDownVisible = !this.isAreaDropDownVisible;
  }

  stateDropDownToggle() {
    this.searchText = '';
    this.isStateDropDownVisible = !this.isStateDropDownVisible;
  }

  regionDropDownToggle() {
    this.searchText = '';
    this.isRegionDropDownVisible = !this.isRegionDropDownVisible;
  }

  contractorCodeDropDownToggle() {
    this.searchText = '';
    this.isContractorCodeDropDownVisible = !this.isContractorCodeDropDownVisible;
  }

  esicDropDownToggle() {
    this.searchText = '';
    this.isEicDropDownVisible = !this.isEicDropDownVisible;
  }

  licenseNoDropDownToggle() {
    this.searchText = '';
    this.isLicenseNoDropDownVisible = !this.isLicenseNoDropDownVisible;
  }

  shiftCodeDropDownToggle() {
    this.searchText = '';
    this.isShiftCodeDropDownVisible = !this.isShiftCodeDropDownVisible;
  }

  weeklyOffCodeDropDownToggle() {
    this.searchText = '';
    this.isWeeklyOffCodeWcDropDownVisible = !this.isWeeklyOffCodeWcDropDownVisible;
  }

  wcDropDownToggle() {
    this.searchText = '';
    this.isWcDropDownVisible = !this.isWcDropDownVisible;
  }

  JCSearchDropDownToggle() {
    this.searchText = '';
    this.isJCSearchDropDownVisible = !this.isJCSearchDropDownVisible;
  }

  setSectorDetail(data: any) {

    this.sectorValue = data.mstText;
    this.workDetailConfiguration.sectorCode.fieldDetail.value = data.mstcode;
    this.isSectorDropDownVisible = false;
    this.sectorIsDirty = true;

    this.workSkillValue = '';
    this.tradeValue = '';
    this.departmentValue = '';
    this.plantValue = '';
    this.aomValue = '';
    this.cardTypeValue = '';

    this.getEntityInfo('PLANTCODE', data.mstcode);
    this.getEntityInfo('CARDTYPE', data.mstcode);
    this.getEntityInfo('AOM', data.mstcode);


    this.workDetailConfiguration.deptCode.listDetails = null;
    this.workDetailConfiguration.tradeCode.listDetails = null;
    this.workDetailConfiguration.workSkillCode.listDetails = null;
    this.workDetailConfiguration.eicCode.listDetails = null;


  }
  setWorkDetail(data: any) {
    this.wordDetailValue = data.mstText;
    this.workDetailConfiguration.workOrderCode.fieldDetail.value = data.mstcode;
    this.isWordDetailsDropDownVisible = false;
    this.workDetailIsDirty = true;
    this.countValidation('WO', data.mstcode);
  }
  setPlantDetail(data: any) {
    this.plantValue = data.mstText;
    this.workDetailConfiguration.plantCode.fieldDetail.value = data.mstcode;
    this.isPlantDropDownVisible = false;
    this.plantIsDirty = true;

    this.workSkillValue = '';
    this.tradeValue = '';
    this.departmentValue = '';

    this.workDetailConfiguration.tradeCode.listDetails = null;
    this.workDetailConfiguration.workSkillCode.listDetails = null;
    this.workDetailConfiguration.eicCode.listDetails = null;

    this.getEntityInfo('DEPTCODE', data.mstcode);
  }

  setDepartmentDetail(data: any) {
    this.departmentValue = data.mstText;
    this.workDetailConfiguration.deptCode.fieldDetail.value = data.mstcode;
    this.isDepartmentDropDownVisible = false;
    this.departmentIsDirty = true;
    this.workSkillValue = '';

    this.tradeValue = '';

    this.getEntityInfo('TRADECODE', data.mstcode);
    this.getEntityInfo('ACTIVITY', data.mstcode);
    this.getEntityInfo('EIC', data.mstcode);
  }

  setTradeDetail(data: any) {
    this.tradeValue = data.mstText;
    this.workDetailConfiguration.tradeCode.fieldDetail.value = data.mstcode;
    this.isTradeDropDownVisible = false;
    this.tradeIsDirty = true;
    this.workSkillValue = '';

    this.getEntityInfo('WORKSKILLCODE', data.mstcode);
  }

  setWorkSkillDetail(data: any) {
    this.workSkillValue = data.mstText;
    this.workDetailConfiguration.workSkillCode.fieldDetail.value = data.mstcode;
    this.isWorkSkillDropDownVisible = false;
    this.workSkillIsDirty = true;
    this.getEntityInfo('CARDTYPE', data.mstcode);
  }

  setCardTypeDetail(data: any) {
    this.cardTypeValue = data.mstText;
    this.workDetailConfiguration.cardTypeCode.fieldDetail.value = data.mstcode;
    this.isCardTypeDropDownVisible = false;
    this.cardTypeIsDirty = true;
  }

  setAOMDetail(data: any) {
    this.aomValue = data.mstText;
    this.workDetailConfiguration.aomCode.fieldDetail.value = data.mstcode;
    this.isAOMDropDownVisible = false;
    this.aomIsDirty = true;
  }

  setActivityDetail(data: any) {
    this.activityValue = data.mstText;
    this.workDetailConfiguration.activityCode.fieldDetail.value = data.mstcode;
    this.isActivityDropDownVisible = false;
    this.activityIsDirty = true;
  }

  setCardCategoryDetail(data: any) {
    this.cardCategoryValue = data.mstText;
    this.workDetailConfiguration.cardCategoryCode.fieldDetail.value = data.mstcode
    this.isCardCategoryDropDownVisible = false;
    this.cardCategoryIsDirty = true;
  }

  setEicDetail(data: any) {
    this.eicValue = data.mstText;
    this.workDetailConfiguration.eicCode.fieldDetail.value = data.mstcode
    this.isEicDropDownVisible = false;
    this.eicIsDirty = true;
  }

  setJCSearchDetail(data: any) {
    this.JCSearchCodeValue = data.mstText;
    this.workDetailConfiguration.jioLocationSearch.fieldDetail.value = data.mstcode
    this.isJCSearchDropDownVisible = false;
    this.JCSearchCodeIsDirty = true;

    this.subscription = this.CardcreationService.GetJIOLocationDetailsByJCCode(data.mstcode, this.workDetailConfiguration.jcMapping).subscribe(
      res => {
        this.workDetailConfiguration.jcMapping = res;

        if (this.workDetailConfiguration.jcMapping.levelName.fieldDetail.value != null) {

          this.mstSectorDetail.mstText = this.workDetailConfiguration.jcMapping.levelName.listDetails.filter(f => f.mstcode == this.workDetailConfiguration.jcMapping.levelName.fieldDetail.value)[0].mstText;
          this.mstSectorDetail.mstcode = this.workDetailConfiguration.jcMapping.levelName.fieldDetail.value;
          this.setLevelDetail(this.mstSectorDetail, '0');
        }
      });
  }

  setLevelDetail(data: any, mode: any) {

    if (mode == "1") {

      this.workDetailConfiguration.jcMapping.regionCode.fieldDetail.value = "";
      this.workDetailConfiguration.jcMapping.stateCode.fieldDetail.value = "";
      this.workDetailConfiguration.jcMapping.areaName.fieldDetail.value = "";
      this.workDetailConfiguration.jcMapping.mpName.fieldDetail.value = "";
      this.workDetailConfiguration.jcMapping.jioLocationCode.fieldDetail.value = "";
      this.workDetailConfiguration.jcMapping.locType.fieldDetail.value = "";
      this.workDetailConfiguration.jcMapping.mgrCode.fieldDetail.value = "";

    }
    this.regionValue = "";
    this.stateValue = "";
    this.areaValue = "";
    this.mpValue = "";
    this.jioLocationValue = "";

    this.mgrValue = "";


    this.levelValue = data.mstText;
    this.workDetailConfiguration.jcMapping.levelName.fieldDetail.value = data.mstText;
    this.isLevelDropDownVisible = false;
    this.levelIsDirty = true;

    this.workDetailConfiguration.jcMapping.regionCode.listDetails = null;
    this.workDetailConfiguration.jcMapping.stateCode.listDetails = null;
    this.workDetailConfiguration.jcMapping.areaName.listDetails = null;
    this.workDetailConfiguration.jcMapping.mpName.listDetails = null;
    this.workDetailConfiguration.jcMapping.jioLocationCode.listDetails = null;
    this.workDetailConfiguration.jcMapping.locType.listDetails = null;
    this.workDetailConfiguration.jcMapping.mgrCode.listDetails = null;

    this.getJIOLocationDetails('RegionCode');
  }
  setRegionDetail(data: any, mode: any) {

    if (mode == "1") {
      this.workDetailConfiguration.jcMapping.stateCode.fieldDetail.value = "";
      this.workDetailConfiguration.jcMapping.areaName.fieldDetail.value = "";
      this.workDetailConfiguration.jcMapping.mpName.fieldDetail.value = "";
      this.workDetailConfiguration.jcMapping.jioLocationCode.fieldDetail.value = "";
      this.workDetailConfiguration.jcMapping.locType.fieldDetail.value = "";
      this.workDetailConfiguration.jcMapping.mgrCode.fieldDetail.value = "";
    }
    this.stateValue = "";
    this.areaValue = "";
    this.mpValue = "";
    this.jioLocationValue = "";

    this.mgrValue = "";

    this.regionValue = data.mstText;
    this.workDetailConfiguration.jcMapping.regionCode.fieldDetail.value = data.mstText;
    this.isRegionDropDownVisible = false;
    this.regionIsDirty = true;

    this.workDetailConfiguration.jcMapping.stateCode.listDetails = null;
    this.workDetailConfiguration.jcMapping.areaName.listDetails = null;
    this.workDetailConfiguration.jcMapping.mpName.listDetails = null;
    this.workDetailConfiguration.jcMapping.jioLocationCode.listDetails = null;
    this.workDetailConfiguration.jcMapping.locType.listDetails = null;
    this.workDetailConfiguration.jcMapping.mgrCode.listDetails = null;




    this.getJIOLocationDetails('StateCode');
  }

  setStateDetail(data: any, mode: any) {

    if (mode == "1") {
      this.workDetailConfiguration.jcMapping.areaName.fieldDetail.value = "";
      this.workDetailConfiguration.jcMapping.mpName.fieldDetail.value = "";
      this.workDetailConfiguration.jcMapping.jioLocationCode.fieldDetail.value = "";
      this.workDetailConfiguration.jcMapping.locType.fieldDetail.value = "";
      this.workDetailConfiguration.jcMapping.mgrCode.fieldDetail.value = "";

    }
    this.stateValue = data.mstText;
    this.workDetailConfiguration.jcMapping.stateCode.fieldDetail.value = data.mstText;
    this.isStateDropDownVisible = false;
    this.stateIsDirty = true;

    this.workDetailConfiguration.jcMapping.areaName.listDetails = null;
    this.workDetailConfiguration.jcMapping.mpName.listDetails = null;
    this.workDetailConfiguration.jcMapping.jioLocationCode.listDetails = null;
    this.workDetailConfiguration.jcMapping.locType.listDetails = null;
    this.workDetailConfiguration.jcMapping.mgrCode.listDetails = null;

    this.areaValue = "";
    this.mpValue = "";
    this.jioLocationValue = "";

    this.mgrValue = "";



    this.getJIOLocationDetails('AreaName');
  }
  setAreaDetail(data: any, mode: any) {

    if (mode == "1") {
      this.workDetailConfiguration.jcMapping.mpName.fieldDetail.value = "";
      this.workDetailConfiguration.jcMapping.jioLocationCode.fieldDetail.value = "";
      this.workDetailConfiguration.jcMapping.locType.fieldDetail.value = "";
      this.workDetailConfiguration.jcMapping.mgrCode.fieldDetail.value = "";
    }
    this.areaValue = data.mstText;
    this.workDetailConfiguration.jcMapping.areaName.fieldDetail.value = data.mstText;
    this.isAreaDropDownVisible = false;
    this.areaIsDirty = true;

    this.workDetailConfiguration.jcMapping.mpName.listDetails = null;
    this.workDetailConfiguration.jcMapping.jioLocationCode.listDetails = null;
    this.workDetailConfiguration.jcMapping.locType.listDetails = null;
    this.workDetailConfiguration.jcMapping.mgrCode.listDetails = null;

    this.mpValue = "";
    this.jioLocationValue = "";

    this.mgrValue = "";

    this.getJIOLocationDetails('MPName');
  }
  setMpDetail(data: any, mode: any) {

    if (mode == "1") {
      this.workDetailConfiguration.jcMapping.jioLocationCode.fieldDetail.value = "";
      this.workDetailConfiguration.jcMapping.locType.fieldDetail.value = "";
      this.workDetailConfiguration.jcMapping.mgrCode.fieldDetail.value = "";
    }
    this.mpValue = data.mstText;
    this.workDetailConfiguration.jcMapping.mpName.fieldDetail.value = data.mstText;
    this.isMpDropDownVisible = false;
    this.mpIsDirty = true;

    this.workDetailConfiguration.jcMapping.jioLocationCode.listDetails = null;
    this.workDetailConfiguration.jcMapping.locType.listDetails = null;
    this.workDetailConfiguration.jcMapping.mgrCode.listDetails = null;

    this.jioLocationValue = "";

    this.mgrValue = "";

    this.getJIOLocationDetails('JioLocationCode');
  }
  setJioLocationDetail(data: any, mode: any) {

    if (mode == "1") {
      this.workDetailConfiguration.jcMapping.locType.fieldDetail.value = "";
      this.workDetailConfiguration.jcMapping.mgrCode.fieldDetail.value = "";
    }
    this.jioLocationValue = data.mstText;
    this.workDetailConfiguration.jcMapping.jioLocationCode.fieldDetail.value = data.mstcode;
    this.isJioLocationDropDownVisible = false;
    this.jioLocationIsDirty = true;

    this.workDetailConfiguration.jcMapping.locType.listDetails = null;
    this.workDetailConfiguration.jcMapping.mgrCode.listDetails = null;

    this.mgrValue = "";

    this.getJIOLocationDetails('MGRCode');


  }
  setMgrDetail(data: any) {
    this.mgrValue = data.mstText;
    this.workDetailConfiguration.jcMapping.mgrCode.fieldDetail.value = data.mstcode;
    this.isMgrDropDownVisible = false;
    this.mgrIsDirty = true;

  }

  setlocTypeDetail(data: any) {
    this.locTypeValue = data.mstText;
    this.workDetailConfiguration.jcMapping.locTypeSearch.fieldDetail.value = data.mstcode;
    this.isLocTypeDropDownVisible = false;
    this.locTypeIsDirty = true;
    this.getEntityInfo('JIOLOCATIONSEARCH', data.mstcode);
  }

  setContractorCodeDetail(data: any) {
    this.contractorCodeValue = data.mstText;
    this.workDetailConfiguration.contractorCode.fieldDetail.value = data.mstcode;
    this.isContractorCodeDropDownVisible = false;
    this.contractorCodeIsDirty = true;
    this.getEntityInfo('LICE', data.mstcode);
    this.getEntityInfo('WC', data.mstcode);
  }

  setEsicDetail(data: any) {
    this.esicValue = data.mstText;
    this.workDetailConfiguration.eicCode.fieldDetail.value = data.mstcode;
    this.isEsicDropDownVisible = false;
    this.esicIsDirty = true;
  }

  setWcDetail(data: any) {
    this.wcValue = data.mstText;
    this.workDetailConfiguration.wcPolicyCode.fieldDetail.value = data.mstcode;
    this.isWcDropDownVisible = false;
    this.wcIsDirty = true;
    if(data.mstcode != '-1')
    {
    this.workDetailConfiguration.pfNo.isDisplayed = false;
    this.workDetailConfiguration.insuranceNo.isDisplayed = false;
  }
  else{
    this.workDetailConfiguration.pfNo.isDisplayed = true;
    this.workDetailConfiguration.insuranceNo.isDisplayed = true;
  }
    this.countValidation('WC', data.mstcode);
  }

  setLicenseNoDetail(data: any) {
    this.licenseNoValue = data.mstText;
    this.workDetailConfiguration.licenseCode.fieldDetail.value = data.mstcode;
    this.isLicenseNoDropDownVisible = false;
    this.licenseNoIsDirty = true;
    this.countValidation('LICE', data.mstcode);
  }

  setShiftCodeDetail(data: any) {
    this.shiftCodeValue = data.mstText;
    this.workDetailConfiguration.shiftGroupCode.fieldDetail.value = data.mstcode;
    this.isShiftCodeDropDownVisible = false;
    this.shiftCodeIsDirty = true;
  }

  setWeeklyOffCodeDetail(data: any) {
    this.weeklyOffCodeValue = data.mstText;
    this.workDetailConfiguration.weeklyOffCode.fieldDetail.value = data.mstcode;
    this.isWeeklyOffCodeWcDropDownVisible = false;
    this.weeklyOffCodeIsDirty = true;
  }

  countValidation(type: string,code: string) {
    this.subscription = this.CardcreationService.countValidation(type, code).subscribe(
      res => {
        switch (type.toUpperCase()) {
          case 'WO': {
            this.workDetailConfiguration.wOcount = res;
            break;
          }
          case 'LICE': {
            this.workDetailConfiguration.licEcount = res;
            break;
          }
          case 'WC': {
            this.workDetailConfiguration.wCcount = res;
            break;
          }
        }
      } );
    }
  // getting level state region mgr mp etc detail related to jioLocation Module
  getJIOLocationDetails(type: string) {
    this.subscription = this.CardcreationService.getJIOLocationDetails(type, this.workDetailConfiguration.jcMapping).subscribe(
      res => {
        this.workDetailConfiguration.jcMapping = res;

        switch (type.toUpperCase()) {
          case 'REGIONCODE': {

            if (this.workDetailConfiguration.jcMapping.regionCode.fieldDetail.value != null) {

              this.mstSectorDetail.mstText = this.workDetailConfiguration.jcMapping.regionCode.fieldDetail.value;
              this.mstSectorDetail.mstcode = this.workDetailConfiguration.jcMapping.regionCode.fieldDetail.value;

              this.setRegionDetail(this.mstSectorDetail, '0');
            }
            this.regionValue = this.workDetailConfiguration.jcMapping.regionCode.listDetails.filter(f => f.mstcode == this.workDetailConfiguration.jcMapping.regionCode.fieldDetail.value)[0].mstText;

            this.regionIsDirty = true;
            break;
          }
          case 'STATECODE': {

            if (this.workDetailConfiguration.jcMapping.stateCode.fieldDetail.value != null) {
              this.mstSectorDetail.mstText = this.workDetailConfiguration.jcMapping.stateCode.fieldDetail.value
              this.mstSectorDetail.mstcode = this.workDetailConfiguration.jcMapping.stateCode.fieldDetail.value
              this.setStateDetail(this.mstSectorDetail, '0');
            }
            this.stateIsDirty = true;
            break;
          }
          case 'AREANAME': {

            if (this.workDetailConfiguration.jcMapping.areaName.fieldDetail.value != null) {
              this.mstSectorDetail.mstText = this.workDetailConfiguration.jcMapping.areaName.fieldDetail.value
              this.mstSectorDetail.mstcode = this.workDetailConfiguration.jcMapping.areaName.fieldDetail.value
              this.setAreaDetail(this.mstSectorDetail, '0');
            }
            this.areaIsDirty = true;
            break;
          }
          case 'MPNAME': {

            if (this.workDetailConfiguration.jcMapping.mpName.fieldDetail.value != null) {
              this.mstSectorDetail.mstText = this.workDetailConfiguration.jcMapping.mpName.fieldDetail.value;
              this.mstSectorDetail.mstcode = this.workDetailConfiguration.jcMapping.mpName.fieldDetail.value;
              this.setMpDetail(this.mstSectorDetail, '0');
            }
            this.areaIsDirty = true;
            break;
          }
          case 'JIOLOCATIONCODE': {

            if (this.workDetailConfiguration.jcMapping.jioLocationCode.fieldDetail.value != null) {
              this.mstSectorDetail.mstText = this.workDetailConfiguration.jcMapping.jioLocationCode.listDetails.filter(f => f.mstcode == this.workDetailConfiguration.jcMapping.jioLocationCode.fieldDetail.value)[0].mstText;
              this.mstSectorDetail.mstcode = this.workDetailConfiguration.jcMapping.jioLocationCode.fieldDetail.value;
              this.setJioLocationDetail(this.mstSectorDetail, '0');
            }
            this.jioLocationIsDirty = true;
            break;
          }
          case 'MGRCode': {

            if (this.workDetailConfiguration.jcMapping.mgrCode.fieldDetail.value != null) {
              this.mstSectorDetail.mstText = this.workDetailConfiguration.jcMapping.mgrCode.listDetails.filter(f => f.mstcode == this.workDetailConfiguration.jcMapping.mgrCode.fieldDetail.value)[0].mstText;
              this.mstSectorDetail.mstcode = this.workDetailConfiguration.jcMapping.mgrCode.fieldDetail.value;
              this.setMgrDetail(this.mstSectorDetail);
            }
            this.jioLocationIsDirty = true;
            break;
          }

        }
      }
    )
  }

  // getting list of entities
  getEntityInfo(entity: string, refID: number) {
    this.subscription = this.CardcreationService.getEntityInfo(entity, refID).subscribe(
      res => {
        this.entity = res;
        switch (entity.toUpperCase()) {
          case 'JIOLOCATIONSEARCH': {
            this.workDetailConfiguration.jioLocationSearch.listDetails = res[0].listDetails;
            break;
          }
          case 'PLANTCODE': {
            this.plant.listDetails = res[0].listDetails;

            if (this.workDetailConfiguration.plantCode.fieldDetail.value != null) {
              this.plantValue = this.workDetailConfiguration.plantCode.listDetails.filter(f => f.mstcode == this.workDetailConfiguration.plantCode.fieldDetail.value)[0].mstText;
              this.plantIsDirty = true;
            }
            break;
          }
          case 'DEPTCODE': {
            this.department.listDetails = res[0].listDetails;
            try {

              this.departmentValue = this.workDetailConfiguration.deptCode.listDetails.filter(f => f.mstcode == this.workDetailConfiguration.deptCode.fieldDetail.value)[0].mstText;
              // this.workDetailConfiguration.deptCode.fieldDetail.value = this.departmentValue;
              this.departmentIsDirty = true;
            } catch{ }
            break;
          }
          case 'TRADECODE': {
            this.trade.listDetails = res[0].listDetails;
            //   this.workDetailConfiguration.tradeCode.listDetails
            this.tradeValue = this.workDetailConfiguration.tradeCode.listDetails.filter(f => f.mstcode == this.workDetailConfiguration.tradeCode.fieldDetail.value)[0].mstText;
            // this.workDetailConfiguration.tradeCode.fieldDetail.value = this.tradeValue;
            this.tradeIsDirty = true;

            break;
          }
          case 'WORKSKILLCODE': {
            this.workSkill.listDetails = res[0].listDetails;
            this.workSkillValue = this.workDetailConfiguration.workSkillCode.listDetails.filter(f => f.mstcode == this.workDetailConfiguration.workSkillCode.fieldDetail.value)[0].mstText;
            //  this.workDetailConfiguration.workSkillCode.fieldDetail.value = this.workSkillValue;
            this.workSkillIsDirty = true;
            break;
          }
          case 'CARDTYPE': {
            this.cardType.listDetails = res[0].listDetails;

            this.cardTypeValue = this.workDetailConfiguration.cardTypeCode.listDetails.filter(f => f.mstcode == this.workDetailConfiguration.cardTypeCode.fieldDetail.value)[0].mstText;
            // this.workDetailConfiguration.cardTypeCode.fieldDetail.value = this.cardTypeValue;
            this.cardTypeIsDirty = true;

            break;
          }
          case 'AOM': {
            this.aom.listDetails = res[0].listDetails;
            this.workDetailConfiguration.aomCode.listDetails = res[0].listDetails;
            this.aomValue = this.workDetailConfiguration.aomCode.listDetails.filter(f => f.mstcode == this.workDetailConfiguration.aomCode.fieldDetail.value)[0].mstText;
            //  this.workDetailConfiguration.aomCode.fieldDetail.value = this.aomValue;
            this.aomIsDirty = true;
            break;
          }
          case 'ACTIVITY': {
            this.activity.listDetails = res[0].listDetails;
            this.workDetailConfiguration.activityCode.listDetails = res[0].listDetails;
            this.activityValue = this.workDetailConfiguration.activityCode.listDetails.filter(f => f.mstcode == this.workDetailConfiguration.activityCode.fieldDetail.value)[0].mstText;
            // this.workDetailConfiguration.activityCode.fieldDetail.value = this.activityValue;
            this.activityIsDirty = true;
            break;
          }
          case 'CARDCAT': {
            this.cardCategory.listDetails = res[0].listDetails;
            this.workDetailConfiguration.cardCategoryCode.listDetails = res[0].listDetails;
            this.cardCategoryValue = this.workDetailConfiguration.cardCategoryCode.listDetails.filter(f => f.mstcode == this.workDetailConfiguration.cardCategoryCode.fieldDetail.value)[0].mstText;
            // this.workDetailConfiguration.cardCategoryCode.fieldDetail.value = this.cardCategoryValue;
            this.cardCategoryIsDirty = true;
            break;
          }
          case 'EIC': {
            this.eic.listDetails = res[0].listDetails;
            this.workDetailConfiguration.eicCode.listDetails = res[0].listDetails;
            this.eicValue = this.workDetailConfiguration.eicCode.listDetails.filter(f => f.mstcode == this.workDetailConfiguration.eicCode.fieldDetail.value)[0].mstText;
            // this.workDetailConfiguration.eicCode.fieldDetail.value = this.eicValue;
            this.eicIsDirty = true;
            break;
          }
          // case 'SHIFTGROUPCODE': {
          //   this.shiftCode.listDetails = res[0].listDetails;
          //   this.workDetailConfiguration.shiftGroupCode.listDetails = res[0].listDetails;
          //   this.shiftCodeValue = this.workDetailConfiguration.shiftGroupCode.listDetails.filter(f => f.mstcode == this.workDetailConfiguration.shiftGroupCode.fieldDetail.value)[0].mstText;
          //   // this.workDetailConfiguration.shiftGroupCode.fieldDetail.value = this.shiftCodeValue;
          //   this.shiftCodeIsDirty = true;
          //   break;
          // }
          case 'WEEKLYOFFCODE': {
            this.weeklyOffCode.listDetails = res[0].listDetails;
            this.workDetailConfiguration.weeklyOffCode.listDetails = res[0].listDetails;
            //  this.weeklyOffCodeValue = this.workDetailConfiguration.weeklyOffCode.listDetails.filter(f => f.mstcode == this.workDetailConfiguration.weeklyOffCode.fieldDetail.value)[0].mstText;
            //  this.workDetailConfiguration.weeklyOffCode.fieldDetail.value = this.weeklyOffCodeValue;
            this.weeklyOffCodeIsDirty = true;
            break;
          }
          case 'LICE': {
            this.licenseNo.listDetails = res[0].listDetails;
            this.workDetailConfiguration.licenseCode.listDetails = res[0].listDetails;
            this.licenseNoValue = this.workDetailConfiguration.licenseCode.listDetails.filter(f => f.mstcode == this.workDetailConfiguration.licenseCode.fieldDetail.value)[0].mstText;
            // this.workDetailConfiguration.licenseCode.fieldDetail.value = this.licenseNoValue;
            this.licenseNoIsDirty = true;
            break;
          }
          case 'WC': {
            this.wc.listDetails = res[0].listDetails;
            this.workDetailConfiguration.wcPolicyCode.listDetails = res[0].listDetails;
            this.wcValue = this.workDetailConfiguration.wcPolicyCode.listDetails.filter(f => f.mstcode == this.workDetailConfiguration.wcPolicyCode.fieldDetail.value)[0].mstText;
            // this.workDetailConfiguration.wcPolicyCode.fieldDetail.value = this.wcValue;
            this.wcIsDirty = true;
            break;
          }
        }
      },
      err => {

      }
    )

  }
  onBack() {
    this.currentActiveModuleEvent.emit("isWorkDetailBack");
  }

  // saving records on proceed button click
  onProceed() {
    this.isPersonalWorkInfoProceed = true;

    if (this.validationTest.isRequired(this.workDetailConfiguration.contractorCode.fieldDetail) +
      this.validationTest.isRequired(this.workDetailConfiguration.contractorCode.fieldDetail) +
      this.validationTest.isRequired(this.workDetailConfiguration.deptCode.fieldDetail) +
      this.validationTest.isRequired(this.workDetailConfiguration.eicCode.fieldDetail) +
      this.validationTest.isRequired(this.workDetailConfiguration.activityCode.fieldDetail) +
      this.validationTest.isRequired(this.workDetailConfiguration.aomCode.fieldDetail) +
      this.validationTest.isRequired(this.workDetailConfiguration.attStopDate) +
      this.validationTest.isRequired(this.workDetailConfiguration.cardCategoryCode.fieldDetail) +
      this.validationTest.isRequired(this.workDetailConfiguration.cardTypeCode.fieldDetail) +
      this.validationTest.isRequired(this.workDetailConfiguration.contractEndDate) +
      this.validationTest.isRequired(this.workDetailConfiguration.doj) +
      this.validationTest.isRequired(this.workDetailConfiguration.epsNo) +
      this.validationTest.isRequired(this.workDetailConfiguration.esicNo) +
      this.validationTest.isRequired(this.workDetailConfiguration.insuranceNo) +
      this.validationTest.isRequired(this.workDetailConfiguration.licenseCode) +
      this.validationTest.isRequired(this.workDetailConfiguration.pfNo) +
      this.validationTest.isRequired(this.workDetailConfiguration.plantCode) +
      this.validationTest.isRequired(this.workDetailConfiguration.sectorCode) +
      this.validationTest.isRequired(this.workDetailConfiguration.shiftGroupCode) +
      this.validationTest.isRequired(this.workDetailConfiguration.tradeCode) +
      this.validationTest.isRequired(this.workDetailConfiguration.uanNo) +
      this.validationTest.isRequired(this.workDetailConfiguration.wcPolicyCode) +
      this.validationTest.isRequired(this.workDetailConfiguration.uanNo) +
      this.validationTest.isRequired(this.workDetailConfiguration.weeklyOffCode) +
      this.validationTest.isRequired(this.workDetailConfiguration.workOrderCode) +
      this.validationTest.isRequired(this.workDetailConfiguration.workSkillCode) +
      this.validationTest.isRequired(this.workDetailConfiguration.agencyID) +
      this.validationTest.checkWOCountvalidate('Workorder ',this.workDetailConfiguration.wOcount.maxValidCount, this.workDetailConfiguration.wOcount.epCount,this.workDetailConfiguration.wOcount.checkFlag ) +
      this.validationTest.checkWOCountvalidate('License ',this.workDetailConfiguration.licEcount.maxValidCount, this.workDetailConfiguration.licEcount.epCount,this.workDetailConfiguration.licEcount.checkFlag )+
      this.validationTest.checkWOCountvalidate('WC Policy ',this.workDetailConfiguration.wCcount.maxValidCount, this.workDetailConfiguration.wCcount.epCount,this.workDetailConfiguration.wCcount.checkFlag )
      == '')
      {
      this.workDetailConfiguration.requestDetails.resCode = this.epCode;
      this.CardcreationService.SaveWorkDetails(this.workDetailConfiguration).subscribe(
        res => {
          this.commonReturnData = res;
          if (res.code == 0) {
            this.isPersonalWorkInfoProceed = true;
            this.currentActiveModuleEvent.emit("isWorkDetailProceed");
            this.workDetailConfiguration.requestDetails.resCode = this.epCode;
          }
          else {
            this.errorMessage = res.message;
          }
        })
    }
  }
  ngOnDestroy() {
    this.subscription.unsubscribe();
  }
}
interface IListDetail {
  listDetails?: any[];
  fieldDetail?: any;
}
