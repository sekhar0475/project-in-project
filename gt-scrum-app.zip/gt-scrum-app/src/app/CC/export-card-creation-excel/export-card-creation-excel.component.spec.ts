import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExportCardCreationExcelComponent } from './export-card-creation-excel.component';

describe('ExportCardCreationExcelComponent', () => {
  let component: ExportCardCreationExcelComponent;
  let fixture: ComponentFixture<ExportCardCreationExcelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExportCardCreationExcelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExportCardCreationExcelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
