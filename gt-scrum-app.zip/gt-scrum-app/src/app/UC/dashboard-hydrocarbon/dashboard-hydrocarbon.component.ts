import { Component, OnInit, Inject, Output, EventEmitter, AfterViewInit } from '@angular/core';
import { userDetail } from 'src/app/Model/UcModel/userDetail';
import { LoginService } from '../../login.service';
import { DashboardService } from '../../../app/Services/dashboard.service';
import { siteDetail } from 'src/app/Model/UcModel/siteDetail';
import { menuDetail } from 'src/app/Model/UcModel/menuDetail';
import { roleDetail } from 'src/app/Model/UcModel/roleDetail';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { DomSanitizer } from '@angular/platform-browser';
//import { DOCUMENT } from "@angular/platform-browser";
import { BlockUI, NgBlockUI } from 'ng-block-ui';
import { SharedState } from 'src/app/Model/Common/InterPage';
import { SharedServiceService } from 'src/app/Services/shared-service.service';

@Component({
  selector: 'app-dashboard-hydrocarbon',
  templateUrl: './dashboard-hydrocarbon.component.html',
  styleUrls: ['./dashboard-hydrocarbon.component.css']
})
export class DashboardHydrocarbonComponent implements OnInit {

  @Output() selectedSiteForHeader = new EventEmitter<string>();
  shared : SharedState = new SharedState();
  userdetailresult: any;
  userdetailresults: userDetail;
  siteDetails: siteDetail[] = [];
  siteDetailsAlt: siteDetail[] = [];
  menuDetails: menuDetail[] = [];
  parentMessage: string = 'hello';
  roleDetails: roleDetail[] = [];
  roleDetailsAlt: roleDetail[] = [];
  selectedSite: any = 1;
  selectedRole: any = 1;
  selectedName: any;
  userCode: number;
  roledetTest: roleDetail;
  showDialog: Boolean = true;
  userName: string;
  siteUiCode: string;
  @BlockUI() blockUI: NgBlockUI;
  blockuiData: string = 'Loading...';

  loginSiteUrl: string;
  testSelectedSite : string;
  backgroundImage : string = '';

  domainDetails : string;

  constructor(private loginService: LoginService, public sanitizer: DomSanitizer, private dashboardService:
    DashboardService, private activatedRoute: ActivatedRoute, private router: Router, private spinner: NgxSpinnerService,
    private sharedServiceService : SharedServiceService) {
    this.roledetTest = new roleDetail();
    this.shared = JSON.parse(atob(localStorage.getItem('shared')));
    this.shared.siteCode = localStorage.getItem('SitetCode');
    localStorage.setItem('shared', btoa(JSON.stringify(this.shared)));

    //document.getElementById
  }

  ngOnInit() {

    this.loginSiteUrl = window.location.origin;
    this.shared = JSON.parse(atob(localStorage.getItem('shared')));

    try {
      this.loginService.ValidateUser(parseInt(this.shared.isVendor) , this.shared.userDomainId, '', this.loginSiteUrl, '', '').subscribe(
        res => {
          console.log('inside dashboard validate user');
          this.shared.siteCode = res.siteDetails[0].siteCode;
          localStorage.setItem('shared', btoa(JSON.stringify(this.shared)));
          console.log(this.shared);
          this.dashboardService.getUserDetailsFromSite(res.siteDetails[0].siteCode.toString()).subscribe(
            res => {
               // console.log(this.sharedServiceService.siteUICode.value);
               // this.userdetailresult = window.history.state;
               this.userdetailresults = res;
               this.shared.siteUiCode = this.userdetailresults.siteDetails[0].siteUICode;
               localStorage.setItem('shared', btoa(JSON.stringify(this.shared)));
               this.backgroundImage = 'data:image/jpeg;base64,' + this.userdetailresults.siteDetails[0].homePageImage;
               this.siteDetails = this.userdetailresults.siteDetails;
               this.roleDetails = this.siteDetails[0].roleDetails;
               this.menuDetails = this.siteDetails[0].roleDetails[0].menuDetails;
               this.userCode = this.userdetailresults.userCode;
               this.userName = this.userdetailresults.username;
               this.selectedSite = this.userdetailresults.siteDetails[0].siteCode;
               this.selectedSiteForHeader.emit(this.selectedSite.toString());
               this.sharedServiceService.changeSiteUICode(this.userdetailresults.siteDetails[0].siteShortCode);
               this.selectedRole = this.siteDetails[0].roleDetails[0].roleCode;
               this.sharedServiceService.changeSiteRoleCode(this.siteDetails[0].roleDetails[0].roleName);
               this.sharedServiceService.currentMessage.subscribe(message => this.testSelectedSite = message);
            });
        });

    }
    catch (err) {
      // this.router.navigateByUrl('login');
    }

  }

  modifyRoles() {
    this.siteDetailsAlt = this.siteDetails.filter(x => x.siteCode == this.selectedSite);
    if (this.siteDetailsAlt.length == 0) {
      this.selectedSite = this.siteDetails[0].siteCode;
      this.selectedSiteForHeader.emit(this.selectedSite.toString());
      this.sharedServiceService.changeSiteUICode(this.selectedSite[0].siteShortCode);
      this.siteDetailsAlt = this.siteDetails.filter(x => x.siteCode == this.selectedSite);
    }
    if (!this.siteDetailsAlt[0].roleDetails) {
      this.dashboardService.getRoleListData(this.selectedSite, this.userCode).subscribe(
        res => {

          if (res[0]) {
            var roleLength = res.length;
            this.roleDetails = [];
            for (var i = 0; i < roleLength; i++) {
              this.roleDetails.push(res[i]);
            }
            this.siteDetails.filter(x => x.siteCode == this.selectedSite)[0].roleDetails = this.roleDetails;
            this.getMenuOnBasisOfRole();
          }
          else {
            this.roleDetails = [];
            this.menuDetails = [];
          }
        }
      )
    }
    else {
      this.roleDetails = this.siteDetailsAlt[0].roleDetails;
      this.roleDetailsAlt = this.siteDetailsAlt[0].roleDetails.filter(x => x.roleCode == this.selectedRole);
      if (this.roleDetailsAlt.length == 0) {
        this.selectedRole = this.siteDetailsAlt[0].roleDetails[0].roleCode;
        this.sharedServiceService.changeSiteRoleCode(this.siteDetailsAlt[0].roleDetails[0].roleName);
        this.roleDetailsAlt = this.siteDetailsAlt[0].roleDetails.filter(x => x.roleCode == this.selectedRole);
      }
      this.menuDetails = this.roleDetailsAlt[0].menuDetails;
    }

  }

  getRolesOnBasisOfSite() {

    this.shared = JSON.parse(atob(localStorage.getItem('shared')));
    this.shared.siteCode = this.selectedSite.toString();


    this.siteDetailsAlt = this.siteDetails.filter(x => x.siteCode == this.selectedSite);
    this.selectedSiteForHeader.emit(this.siteDetailsAlt[0].siteUICode);
    this.sharedServiceService.changeSiteUICode(this.siteDetailsAlt[0].siteShortCode);
    this.shared.siteName = this.siteDetailsAlt[0].siteShortCode;
    localStorage.setItem('shared', btoa(JSON.stringify(this.shared)));

    if (!this.siteDetailsAlt[0].roleDetails) {
      this.dashboardService.getRoleListData(this.selectedSite, this.userCode).subscribe(
        res => {
          var roleLength = res.length;
          if (res[0]) {

            this.roleDetails = [];
            for (var i = 0; i < roleLength; i++) {
              this.roleDetails.push(res[i]);
            }
            this.siteDetails.filter(x => x.siteCode == this.selectedSite)[0].roleDetails = this.roleDetails;
            this.selectedRole = this.roleDetails[0].roleCode;
            this.sharedServiceService.changeSiteRoleCode(this.roleDetails[0].roleName);
            this.getMenuOnBasisOfRole();
          }
          else {
            this.roleDetails = [];
            this.menuDetails = [];
            this.sharedServiceService.changeSiteRoleCode('');
          }
        }
      )
    }
    else {
      this.roleDetails = this.siteDetailsAlt[0].roleDetails;
      this.roleDetailsAlt = this.siteDetailsAlt[0].roleDetails.filter(x => x.roleCode == this.siteDetailsAlt[0].roleDetails[0].roleCode);
      if (this.roleDetailsAlt[0].menuDetails == null) {
        this.selectedRole = this.siteDetailsAlt[0].roleDetails[0].roleCode;
        this.sharedServiceService.changeSiteRoleCode(this.roleDetailsAlt[0].roleName);
        this.getMenuOnBasisOfRole();
      }
      else {
        this.shared = JSON.parse(atob(localStorage.getItem('shared')));
        this.shared.roleCode = this.siteDetailsAlt[0].roleDetails[0].roleCode.toString();
        this.shared.roleName = this.siteDetailsAlt[0].roleDetails[0].roleName;
        localStorage.setItem('shared', btoa(JSON.stringify(this.shared)));
        this.sharedServiceService.changeSiteRoleCode(this.roleDetailsAlt[0].roleName);

        this.menuDetails = this.roleDetailsAlt[0].menuDetails;
      }
    }

  }

  getMenuOnBasisOfRole() {

    this.shared = JSON.parse(atob(localStorage.getItem('shared')));
    this.shared.roleCode = this.selectedRole.toString();


    this.siteDetailsAlt = this.siteDetails.filter(x => x.siteCode == this.selectedSite);
    this.roleDetailsAlt = this.siteDetailsAlt[0].roleDetails.filter(x => x.roleCode == this.selectedRole);

    this.shared.roleName = this.roleDetailsAlt[0].roleName;
    this.sharedServiceService.changeSiteRoleCode(this.roleDetailsAlt[0].roleName);
    localStorage.setItem('shared', btoa(JSON.stringify(this.shared)));

    if (!this.roleDetailsAlt[0].menuDetails) {
      this.dashboardService.getMenuListData(this.selectedSite, this.userCode, this.selectedRole).subscribe(
        res => {
          if (res[0]) {
            this.menuDetails = [];
            var menuLength = res.length;
            for (var i = 0; i < menuLength; i++) {
              this.menuDetails.push(res[i]);
            }

            this.siteDetails.filter(x => x.siteCode == this.selectedSite)[0].roleDetails.filter(x => x.roleCode == this.selectedRole)[0].menuDetails = this.menuDetails;
          }
          else {
            this.menuDetails = [];
            this.siteDetails.filter(x => x.siteCode == this.selectedSite)[0].roleDetails.filter(x => x.roleCode == this.selectedRole)[0].menuDetails = this.menuDetails;
          }

        }
      )
    }
    else {
      this.menuDetails = [];
      this.menuDetails = this.siteDetails.filter(x => x.siteCode == this.selectedSite)[0].roleDetails.filter(x => x.roleCode == this.selectedRole)[0].menuDetails;
    }

  }

  // changeReflection() {
  //   //alert('inside dashboard component');
  // }
  subscribe(email: string) {
    this.dashboardService.getMenuListData(this.selectedSite, this.userCode, this.selectedRole).subscribe(
      res => {
        this.siteDetails = res[0];
      }
    )

  }
}
