import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DashboardHydrocarbonComponent } from './dashboard-hydrocarbon.component';

describe('DashboardHydrocarbonComponent', () => {
  let component: DashboardHydrocarbonComponent;
  let fixture: ComponentFixture<DashboardHydrocarbonComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DashboardHydrocarbonComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DashboardHydrocarbonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
