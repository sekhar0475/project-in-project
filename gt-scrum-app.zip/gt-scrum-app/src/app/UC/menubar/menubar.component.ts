import { Component, OnInit, Input, ChangeDetectionStrategy, Output, EventEmitter } from '@angular/core';
import{menuDetail} from 'src/app/Model/UcModel/menuDetail';
import { Observable, of } from 'rxjs';

@Component({
  selector: 'app-menubar',
  templateUrl: './menubar.component.html',
  styleUrls: ['./menubar.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class MenubarComponent implements OnInit {
  @Input() childMessage: Observable<menuDetail[]>;
  @Input() selectedSite: Observable<any>;
  @Output() changeReflection = new EventEmitter();

  siteDetails: menuDetail[];
  constructor() { }

  ngOnInit() {
    this.changeReflection.emit();
//this.siteDetails = this.childMessage;
  }

}
