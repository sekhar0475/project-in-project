import { Component, OnInit, Input, ChangeDetectionStrategy, Output, EventEmitter, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { SharedState } from 'src/app/Model/Common/InterPage';
import { LoginService } from 'src/app/login.service';
import { Subscription } from 'rxjs';
import { headerDetails } from 'src/app/Model/UcModel/headerDetails';
import { SharedServiceService } from 'src/app/Services/shared-service.service';

@Component({
  selector: 'app-header-rr',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})

export class HeaderComponent implements OnInit, OnDestroy {
  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
  shared: SharedState = new SharedState();
  userName: string;
  compactHeaderIsVisible: boolean = false;

  subscription : Subscription;
  headerDetail : headerDetails[] = new Array();;

  headerLeftLogoUpperText : string = '';
  headerLeftLogoLowerText : string = '';

  headerLogoImage : string = '';
  myVal : string = 'myVal';

  constructor(private router: Router , private loginService : LoginService, private sharedServiceService : SharedServiceService) {
    this.shared = JSON.parse(atob(localStorage.getItem('shared')));

  }

  ngOnInit() {
    this.shared = JSON.parse(atob(localStorage.getItem('shared')));
    this.userName = this.shared.userName;
    this.shared.siteName;

    this.getHeaderConfigurationDetails();
  }

  logOut() {
    localStorage.clear();
   // window.location.href = 'https://www.google.com/';
     window.location.href = 'https://sitohs.jio.com:4443/oam/server/logout?end_url=http://scrumdvv2.ril.com';
    // this.router.navigateByUrl('oim');
  }

  getHeaderConfigurationDetails(){
    this.subscription = this.loginService.getHeaderConfigurationDetails(this.shared.siteCode, this.shared.userDomainId, this.shared.ipAddress, this.shared.isVendor, this.shared.siteUrl).subscribe(
      res=>{
          this.headerDetail = res;
           this.headerLeftLogoUpperText = this.headerDetail[0].headerLogoText.split('~')[0];
           this.headerLeftLogoLowerText = this.headerDetail[0].headerLogoText.split('~')[1];
           this.headerLogoImage = 'data:image/png;base64,' + this.headerDetail[0].headerLogoImage;
      }
    )
  }

  toggleHeader() {
    this.compactHeaderIsVisible = !this.compactHeaderIsVisible
  }
}
