import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DashboardRetailComponent } from './dashboard-retail.component';

describe('DashboardRetailComponent', () => {
  let component: DashboardRetailComponent;
  let fixture: ComponentFixture<DashboardRetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DashboardRetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DashboardRetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
