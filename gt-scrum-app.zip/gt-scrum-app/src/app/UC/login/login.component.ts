import { Component, OnInit, OnDestroy } from '@angular/core';
import { LoginService } from '../../login.service';
import { siteDetails } from '../../siteDetails';
import { Router, ActivatedRoute } from '@angular/router';
import { userDetailsResult } from '../../userDetailsResult';
import { userDetail } from 'src/app/Model/UcModel/userDetail';
import { NgxSpinnerService } from 'ngx-spinner';

import { DomSanitizer, SafeStyle, SafeResourceUrl } from '@angular/platform-browser';
import { BlockUI, NgBlockUI } from 'ng-block-ui';
import { SharedState } from 'src/app/Model/Common/InterPage';
import { siteDetail } from 'src/app/Model/UcModel/siteDetail';

import { oimError } from '../../Constants/oimError';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit, OnDestroy {

  shared: SharedState = new SharedState();
  selectedLink: string = "Male";
  visibility: boolean = true;
  textBoxDisabled = true;
  modelBindTest: string;
  data: any;

  UID: string = "1";
  fullImagePath: string;
  isVisible: boolean = true;
  userdetailresult: any;
  isValidCredential: boolean = false;

  errorMessage: string;
  isVendor: number = 0;

  userId: string;
  userPassword: string;
  userRequestId: string;

  ipAddress: string = "";
  cssUrl: string = './login.component.css';
  href: any;

  loginSiteUrl: string;
  siteConfigurationDetail: siteDetail;

  siteHeaderRightUpper: string;
  siteHeaderRightLower: string;

  siteHeaderLeftUpper: string;
  siteHeaderLeftLower: string;

  siteRightPanelHeader: string;
  siteRightPanelTextLabel: string;

  siteLeftPanelHeader: string;
  siteLeftPanelTextLabel: string;

  inType: string = '';
  domainId: string = '';
  oimRedirectionURL: string = '';

  isOimRedirection: boolean = true;
  userDomainName: string = '';
  oimErrorCode: string = '0';
  oimError: oimError = new oimError();

  @BlockUI() blockUI: NgBlockUI;
  constructor(private loginService: LoginService, public sanitizer: DomSanitizer,
    private router: Router, private spinner: NgxSpinnerService, private ActivatedRoute: ActivatedRoute) {
    this.fullImagePath = '../../../assets/logo.png';
    this.cssUrl = './login.component.css';
    this.siteConfigurationDetail = new siteDetail();
    this.loginService.getIpAddress().subscribe(
      res => {
        this.ipAddress = res.ip;
      }
    );
  }

  ngOnInit() {
    this.loginSiteUrl = window.location.origin;
    console.log('inside login component');
    this.shared.userCode = localStorage.getItem('UserCode');
    this.shared.windowsDomainId = localStorage.getItem('DomainName');
    this.shared.siteCode = localStorage.getItem('SitetCode');
    this.shared.siteUrl = this.loginSiteUrl;
    localStorage.setItem('shared', btoa(JSON.stringify(this.shared)));
    console.log('done login component');
    this.loginService.getOimRedirectApiURL().subscribe(
      res => {
        this.oimRedirectionURL = res.message.toString();
      }
    )

    this.loginSiteConfiguration(this.inType, this.loginSiteUrl, this.domainId);
    this.ActivatedRoute.queryParams.subscribe(params => {
      this.userRequestId = params['request_id'];
      this.oimErrorCode = params['p_error_code'].toString();
      if (this.oimErrorCode != '0' && this.oimErrorCode != '') {
        this.oimErrorCode = this.oimErrorCode.replace('-', '');
        alert(this.oimErrorCode);
        switch (this.oimErrorCode) {
          case 'OAM1': {
            this.errorMessage = this.oimError.OAM1
          }
          case 'OAM3': {
            this.errorMessage = this.oimError.OAM3
          }
          case 'OAM5': {
            this.errorMessage = this.oimError.OAM5
          }
          case 'OAM6': {
            this.errorMessage = this.oimError.OAM6
          }
          case 'OAM10': {
            this.errorMessage = this.oimError.OAM10
          }
          default : {
            this.errorMessage = this.oimError.OAMDefault
          }
        }
      }
    });

    this.href = this.router.url;
    this.cssUrl = './login.component.css';
    this.loginService.getIpAddress().subscribe(
      res => {
        this.ipAddress = res.ip;
      }
    );
    this.userdetailresult = userDetailsResult;
  }

  saveUserDomainID() {
    this.shared.userDomainId = this.userId;
    localStorage.setItem('shared', btoa(JSON.stringify(this.shared)));
  }

  loginUser() {
    this.loginService.ValidateUser(this.isVendor, this.userId, this.userPassword, this.loginSiteUrl, this.ipAddress, this.userRequestId).subscribe(
      res => {

        this.userdetailresult = res;
        if (this.userdetailresult.userCode != 0) {
          this.shared.userCode = this.userdetailresult.userCode;
          this.shared.siteCode = this.userdetailresult.siteDetails[0].siteCode;
          this.shared.userName = this.userdetailresult.username;
          this.shared.roleCode = this.userdetailresult.siteDetails[0].roleDetails[0].roleCode;
          this.shared.roleName = this.userdetailresult.siteDetails[0].roleDetails[0].roleName;
          this.shared.userDomainId = this.userId;
          this.shared.isVendor = this.isVendor.toString();
          this.shared.siteUrl = this.loginSiteUrl;
          this.shared.siteUiCode = this.userdetailresult.siteDetails[0].siteUICode;
          this.shared.siteName = this.userdetailresult.siteDetails[0].siteName;

          localStorage.setItem('shared', btoa(JSON.stringify(this.shared)));
          //this.router.navigateByUrl('dashboardhydrocarbon',{state:{userdetailresults:this.userdetailresult}});
          if (this.userdetailresult.siteDetails[0].siteUICode == 'RR') {
            this.router.navigateByUrl('dashboard');
          }
          else if (this.userdetailresult.siteDetails[0].siteUICode == 'HC') {
            this.router.navigateByUrl('dashboardhydrocarbon');
          }
          else {
            this.router.navigateByUrl('dashboardretail');
          }

          this.isValidCredential = true;
        }
        else {
          this.userPassword = '';
          this.errorMessage = this.userdetailresult.statusMessage;
          this.isValidCredential = true;
        }

      }
    ),
      err => {
        console.log('error');
      }
  }

  keyDownFunction(event) {
    if (event.keyCode == 13) {
      this.onLogin();
      // rest of your code
    }
  }
  onLogin(): void {
    this.loginUser();
  }

  toggle() {
    this.userPassword = '';
    this.textBoxDisabled = !this.textBoxDisabled;
  }

  checkVisibility(userType: string) {
    this.userPassword = '';
    this.errorMessage = "";
    this.visibility = false;
    if (userType == "Vendor") {
      this.isVisible = false;
      this.isVendor = 1;
    }
    else {
      this.isVisible = true;
      this.isVendor = 0;
    }
  }

  setradio(e: string): void {
    this.selectedLink = e;
  }

  isSelected(name: string): boolean {

    if (!this.selectedLink) { // if no radio button is selected, always return false so every nothing is shown
      return false;
    }
    if (name == "vendor") {
      return true;
    }
    else return false;
    // return (this.selectedLink === name); // if current radio button is selected, return true, else return false
  }

  ngOnDestroy(): void {
    //  localStorage.clear();
  }

  loginSiteConfiguration(inType: string, siteUrl: string, domainId: string) {
    this.loginService.loginSiteConfiguration(inType, siteUrl, domainId).subscribe(
      res => {
        this.siteConfigurationDetail = res;
        this.siteConfigurationDetail.siteLogo = 'data:image/png;base64,' + this.siteConfigurationDetail.siteLogo;
        this.siteConfigurationDetail.loginPageImage = 'data:image/jpeg;base64,' + this.siteConfigurationDetail.loginPageImage;

        this.siteHeaderLeftUpper = this.siteConfigurationDetail.siteHeader.split('~')[0];
        this.siteHeaderLeftLower = this.siteConfigurationDetail.siteHeader.split('~')[1];

        this.siteHeaderRightUpper = this.siteConfigurationDetail.welcomeText.split('~')[0];
        this.siteHeaderRightLower = this.siteConfigurationDetail.welcomeText.split('~')[1];

        this.siteRightPanelHeader = this.siteConfigurationDetail.loginText1.split('~')[0];
        this.siteRightPanelTextLabel = this.siteConfigurationDetail.loginText1.split('~')[1];

        this.siteLeftPanelHeader = this.siteConfigurationDetail.loginText2.split('~')[0];
        this.siteLeftPanelTextLabel = this.siteConfigurationDetail.loginText2.split('~')[1];

      }
    )
  }
}
