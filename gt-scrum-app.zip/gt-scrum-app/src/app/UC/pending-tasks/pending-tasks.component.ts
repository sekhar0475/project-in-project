import { Component, OnInit } from '@angular/core';
import { DashboardService } from 'src/app/Services/dashboard.service';
import { dashBoardResApprovals } from 'src/app/Model/UcModel/dashBoardResApprovals';

@Component({
  selector: 'app-pending-tasks',
  templateUrl: './pending-tasks.component.html',
  styleUrls: ['./pending-tasks.component.css']
})
export class PendingTasksComponent implements OnInit {
  dashBoardResApprovals : dashBoardResApprovals;
  constructor(private dashboardService : DashboardService) { }

  ngOnInit() {
  }

  dashBoardPendingDetail(){
    this.dashboardService.dashBoardPendingDetail().subscribe(
      res=>{
        this.dashBoardResApprovals= res;
      }
    )
  }

}
