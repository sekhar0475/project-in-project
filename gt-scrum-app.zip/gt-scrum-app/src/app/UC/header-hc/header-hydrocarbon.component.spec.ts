import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HeaderHydrocarbonComponent } from './header-hydrocarbon.component';

describe('HeaderHydrocarbonComponent', () => {
  let component: HeaderHydrocarbonComponent;
  let fixture: ComponentFixture<HeaderHydrocarbonComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HeaderHydrocarbonComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HeaderHydrocarbonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
