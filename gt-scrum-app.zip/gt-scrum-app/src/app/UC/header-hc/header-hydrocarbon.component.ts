import { Component, OnInit, Input, ChangeDetectionStrategy, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import { SharedState } from 'src/app/Model/Common/InterPage';

@Component({
  selector: 'app-header-hc',
  templateUrl: './header-hydrocarbon.component.html',
  styleUrls: ['./header-hydrocarbon.component.css']
})
export class HeaderHydrocarbonComponent implements OnInit {
  shared : SharedState = new SharedState();
  userName : string;

  constructor(private router: Router) {
    this.shared  = JSON.parse(atob(localStorage.getItem('shared')));
  }

  ngOnInit() {
    this.userName = this.shared.userName;
  }
logOut()
{
  localStorage.clear();
  this.router.navigateByUrl('oim');
}
}
