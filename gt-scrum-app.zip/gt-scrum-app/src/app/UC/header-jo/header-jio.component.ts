import { Component, OnInit , Input} from '@angular/core';
import { Router } from '@angular/router';
import { SharedState } from 'src/app/Model/Common/InterPage';

@Component({
  selector: 'app-header-jo',
  templateUrl: './header-jio.component.html',
  styleUrls: ['./header-jio.component.css']
})
export class HeaderJioComponent implements OnInit {
  shared : SharedState = new SharedState();
  userName : string;
  constructor(private router: Router) {
    this.shared  = JSON.parse(atob(localStorage.getItem('shared')));
   }

  ngOnInit() {
    this.userName = this.shared.userName;
  }
logOut()
{
  localStorage.clear();
  this.router.navigateByUrl('oim');
}
}
