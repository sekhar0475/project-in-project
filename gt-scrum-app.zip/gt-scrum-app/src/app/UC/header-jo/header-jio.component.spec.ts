import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HeaderJioComponent } from './header-jio.component';

describe('HeaderJioComponent', () => {
  let component: HeaderJioComponent;
  let fixture: ComponentFixture<HeaderJioComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HeaderJioComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HeaderJioComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
