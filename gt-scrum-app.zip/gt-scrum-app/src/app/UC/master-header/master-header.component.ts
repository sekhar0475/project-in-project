import { Component, OnInit, ViewEncapsulation, ViewChild, AfterViewInit, ContentChild, ChangeDetectorRef } from '@angular/core';
import { SharedState } from 'src/app/Model/Common/InterPage';
import { DahsboardComponent } from '../dahsboard/dahsboard.component';
import { SharedServiceService } from 'src/app/Services/shared-service.service';

@Component({
  selector: 'app-master-header',
  templateUrl: './master-header.component.html',
  styleUrls: ['./master-header.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class MasterHeaderComponent implements OnInit {

  testSelectedSite: string = '';
  shared: SharedState = new SharedState();
  // @ViewChild(DahsboardComponent, {static:false}) dashboardHC: DahsboardComponent;
  @ContentChild(DahsboardComponent, { static: false }) dashboardHCContentChild: DahsboardComponent;

  isHeaderVisible: boolean = false;
  isDashboardVisible : boolean = false;
  constructor(private changeDetectorRef: ChangeDetectorRef, private sharedServiceService: SharedServiceService) {

  }

  ngOnInit() {
    this.changeDetectorRef.detectChanges();
    this.sharedServiceService.currentMessage.subscribe(message => this.testSelectedSite = message);
    console.log(window.location.pathname);
    if (window.location.pathname == '/dashboardhydrocarbon') {
      this.isDashboardVisible = true;
    }
    if (window.location.pathname == '/login' || window.location.pathname == '/') {
      this.isHeaderVisible = false;
    }
    else {
      this.isHeaderVisible = true;
      this.shared = JSON.parse(atob(localStorage.getItem('shared')));
    }
    //console.log(this.dashboardHC.selectedSite);
  }


  // this.changeDetectorRef.detectChanges();
  // console.log('------------------inside master header afterViewINIT-------------------------------');
  // if(this.dashboardHC.selectedSite){
  //   console.log(this.dashboardHC.selectedSite);
  // }
  ngOnChanges(){
    // console.log('------------------inside master header doOnChanges-------------------------------');
    // this.sharedServiceService.currentMessage.subscribe(message => this.testSelectedSite = message);
    // if (this.dashboardHCContentChild.selectedSite) {
    //   console.log(this.dashboardHCContentChild);
    // }
  }

  ngAfterContentInit() {
    // this.changeDetectorRef.detectChanges();
    // this.sharedServiceService.currentMessage.subscribe(message => this.testSelectedSite = message);
    // console.log('------------------inside master header afterContentINIT-------------------------------');
    // if (this.dashboardHCContentChild.selectedSite) {
    //   console.log(this.dashboardHCContentChild);
    // }
  }
  // siteChangedUiUpdate(data : any){
  //   alert(data);
  // }
}
