import { Component, OnInit } from '@angular/core';
import { LoginService } from '../login.service';

@Component({
  selector: 'app-oim-login-internet',
  templateUrl: './oim-login-internet.component.html',
  styleUrls: ['./oim-login-internet.component.css']
})
export class OimLoginInternetComponent implements OnInit {

  redirectURL: string = '';

  constructor(private loginService: LoginService) { }

  ngOnInit() {
    window.location.href =  window.location.host + "/UserValidateInt/uservalidate.aspx";
  }

}
