import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OimLoginInternetComponent } from './oim-login-internet.component';

describe('OimLoginInternetComponent', () => {
  let component: OimLoginInternetComponent;
  let fixture: ComponentFixture<OimLoginInternetComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OimLoginInternetComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OimLoginInternetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
