import { BrowserModule } from '@angular/platform-browser';
import { NgModule  } from '@angular/core';
import { PortalModule } from '@angular/cdk/portal'
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
// import { LoginGenComponent } from './login-gen/login-gen.component';
import { LoginComponent } from './UC/login/login.component';
import { FormsModule } from '@angular/forms';
import { HttpClientModule,HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { HomeComponent } from './home/home.component';
import { DahsboardComponent } from './UC/dahsboard/dahsboard.component';
import { MenubarComponent } from './UC/menubar/menubar.component';
import { PendingTasksComponent } from './UC/pending-tasks/pending-tasks.component';
import { QueriesComponent } from './UC/queries/queries.component';
import { CardCreationComponent } from './CC/card-creation/card-creation.component';
import { PersonalInformationComponent } from './CC/personal-information/personal-information.component';
import { WorkDetailComponent } from './CC/work-detail/work-detail.component';
import { OtherDetailComponent } from './CC/other-detail/other-detail.component';
// import { ApprovalComponent } from './CC/approval/approval.component';
import {AppDialogComponent} from './CC/app-dialog/app-dialog.component';

import {
  MatInputModule, DateAdapter, MatNativeDateModule, MatButtonModule,
  MatCardModule, MatExpansionPanelTitle,
  MAT_DIALOG_DEFAULT_OPTIONS, MatFormFieldModule, MatCheckboxModule, MatDatepickerModule,
  MatRadioModule, MatSelectModule, MatTableModule, MatPaginatorModule,
  MatSortModule, MatExpansionModule,MatMenuModule, MatGridListModule
} from '@angular/material';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import { HeaderComponent } from './UC/header-rr/header.component';
import { NgxSpinnerModule } from 'ngx-spinner';
import { DomSanitizer, SafeResourceUrl, SafeUrl} from '@angular/platform-browser';
import { SafePipe } from './safe.pipe';
import{ FilterPipe } from './filter.pipe';
import { DashboardRetailComponent } from './UC/dashboard-retail/dashboard-retail.component';
import { HeaderJioComponent } from './UC/header-jo/header-jio.component';
import { BlockUIModule } from 'ng-block-ui';
import { DashboardHydrocarbonComponent } from './UC/dashboard-hydrocarbon/dashboard-hydrocarbon.component';
import { HeaderHydrocarbonComponent } from './UC/header-hc/header-hydrocarbon.component';
import { CardCreationCssComponent } from './card-creation-css/card-creation-css.component';
import { ObjectFilterPipe } from './object-filter.pipe';
import { MatAccordianangComponent } from './mat-accordianang/mat-accordianang.component';
import { NgSelectModule } from '@ng-select/ng-select';
import { ReactiveFormsValidationsComponent } from './reactive-forms-validations/reactive-forms-validations.component';
import { ReactiveFormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { MatTableExampleComponent } from './mat-table-example/mat-table-example.component';
// import { ServiceWorkerModule } from '@angular/service-worker';
import { environment } from '../environments/environment';
import { ReadExcelComponent } from './read-excel/read-excel.component';
import { ExportToExcelComponent } from './export-to-excel/export-to-excel.component';
import { ExportToPdfComponent } from './export-to-pdf/export-to-pdf.component';
// import { ExportCardCreationExcelComponentTest } from './cc/export-card-creation-excel/export-card-creation-excel.component';
import { ExportToExcelCardCreationFormatComponent } from './CC/export-to-excel-card-creation-format/export-to-excel-card-creation-format.component';
import { AuthGuard } from './Services/authGuard';
// import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown-angular7';
import { MultiselectDropDownScrumComponent } from './multiselect-drop-down-scrum/multiselect-drop-down-scrum.component';
// import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown';
import { CommonModule } from '@angular/common';
// import { NgOptionHighlightModule } from '@ng-select/ng-option-highlight';

import { UserCreationComponent } from './MDM/user-creation/user-creation.component';
import { SearchComponent } from './RPT/search/search.component';
import { UserRolesComponent } from './MDM/user-roles/user-roles.component';
import { SiteConfigComponent } from './MDM/site-config/site-config.component';
import { SearchListComponent } from './RPT/search-list/search-list.component';
import { CardCreationResourceListComponent } from './CC/card-creation-resource-list/card-creation-resource-list.component';
import { MstSiteComponent } from './RPT/mst-site/mst-site.component'
import {SiteFieldConfigComponent  } from './MDM/site-field-config/site-field-config.component';
import {FetchDataComponent} from '../app/fetch-data/fetch-data.component';
import {RolemenuMasterComponent} from './MDM/rolemenu-master/rolemenu-master.component';
import { RoleMasterComponent } from './MDM/role-master/role-master.component';
import { SearchGridComponent } from './RPT/search-grid/search-grid.component';
import { FormPostComponent } from './form-post/form-post.component';
import { NavMenuComponent } from './nav-menu/nav-menu.component';
import { SecureRequestComponent } from './secure-request/secure-request.component';
import { CounterComponent } from './counter/counter.component';
// import { MatMenuModule } from '@angular/material/menu';
import { MatScrumDropDownTestComponent } from './mat-scrum-drop-down-test/mat-scrum-drop-down-test.component';
// import { ServiceWorkerModule } from '@angular/service-worker';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatIconModule } from '@angular/material/icon';
import { MatListModule } from '@angular/material/list';

import {CdkTableModule} from '@angular/cdk/table';
import {CdkTreeModule} from '@angular/cdk/tree';
import { MenuMasterComponent } from './MDM/menu-master/menu-master.component';
import { ExportCardCreationExcelComponent } from './CC/export-card-creation-excel/export-card-creation-excel.component';
import { OimLoginComponent } from './oim-login/oim-login.component';
import { SiteFieldEditConfigComponent } from './MDM/site-field-edit-config/site-field-edit-config.component';
import { SiteApprovalConfigComponent } from './MDM/site-approval-config/site-approval-config.component';
import { RenderComponentComponent } from './render-component/render-component.component';
import { MasterHeaderComponent } from './UC/master-header/master-header.component';

import {MatDialogModule} from '@angular/material/dialog';
import { OimLoginInternetComponent } from './oim-login-internet/oim-login-internet.component';
// import { ScrumDialogComponent } from './CC/scrum-dialog/scrum-dialog.component'

@NgModule({

  declarations: [
    AppComponent,
    FetchDataComponent,
    RolemenuMasterComponent,
    SearchGridComponent,
    RenderComponentComponent,
    FormPostComponent,
    NavMenuComponent,
    SecureRequestComponent,
    CounterComponent,
    LoginComponent,
    HomeComponent,
    DahsboardComponent,
    MatAccordianangComponent,
    PendingTasksComponent,
    QueriesComponent,
    MenubarComponent,
    CardCreationComponent,
    PersonalInformationComponent,
    WorkDetailComponent,
    OtherDetailComponent,
    // ApprovalComponent,
    HeaderComponent,
    SafePipe,
    FilterPipe,
    DashboardRetailComponent,
    HeaderJioComponent,
    DashboardHydrocarbonComponent,
    HeaderHydrocarbonComponent,
    CardCreationCssComponent,
    ObjectFilterPipe,
    ReactiveFormsValidationsComponent,
    MatTableExampleComponent,
    ReadExcelComponent,
    ExportToExcelComponent,
    ExportToPdfComponent,
    ExportCardCreationExcelComponent,
    ExportToExcelCardCreationFormatComponent,
    MultiselectDropDownScrumComponent,
    UserCreationComponent,
    SearchComponent,
    UserRolesComponent,
    SiteConfigComponent,
    SearchListComponent,
    CardCreationResourceListComponent,
    MstSiteComponent,
    SiteFieldConfigComponent,
    MatScrumDropDownTestComponent,
     RoleMasterComponent,
    MenuMasterComponent,
    ExportCardCreationExcelComponent,
    SearchListComponent,
    RoleMasterComponent,
    RolemenuMasterComponent,
    MenuMasterComponent,
    OimLoginComponent,
    SiteFieldEditConfigComponent,
    SiteApprovalConfigComponent,
    MasterHeaderComponent,
    AppDialogComponent,
    OimLoginInternetComponent,
    // ScrumDialogComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    MatButtonModule, MatCardModule,MatNativeDateModule,PortalModule,
    MatFormFieldModule, MatCheckboxModule, MatDatepickerModule,
     MatRadioModule, MatSelectModule,MatMenuModule, MatGridListModule,
    MatInputModule,
    NgxSpinnerModule,
    MatProgressSpinnerModule,
    NgSelectModule,ReactiveFormsModule,
    NgbModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    CommonModule,
    MatExpansionModule,
    MatDialogModule,
    BlockUIModule.forRoot()
  ],
  exports:[

  ],
  // entryComponents: [ ScrumDialogComponent],
  providers: [AuthGuard, MatButtonModule,  MatCardModule,MatNativeDateModule,
    MatFormFieldModule, MatCheckboxModule, MatDatepickerModule, MatRadioModule, MatSelectModule,
    {provide: MAT_DIALOG_DEFAULT_OPTIONS, useValue: {hasBackdrop: false}},
  ],
  bootstrap: [AppComponent]
})

export class AppModule { }

