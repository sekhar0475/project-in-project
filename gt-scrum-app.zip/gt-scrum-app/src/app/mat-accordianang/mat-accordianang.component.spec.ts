import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MatAccordianangComponent } from './mat-accordianang.component';

describe('MatAccordianangComponent', () => {
  let component: MatAccordianangComponent;
  let fixture: ComponentFixture<MatAccordianangComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MatAccordianangComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MatAccordianangComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
