
export class oimError{
  OAM1 : string = 'Invalid credentials.';
  OAM3 : string = 'Invalid access. Please close the browser and re-login in new browser.';
  OAM5 : string = 'The user account is locked or disabled. Please contact the System Administrator.';
  OAM6 : string = 'Reached maximum allowed sessions.  Please close all existing browser sessions before trying to login again.';
  OAM10 : string = 'The password has expired. Please contact the System Administrator.';
  OAMDefault : string = 'Something went wrong. Please try again!'
}
