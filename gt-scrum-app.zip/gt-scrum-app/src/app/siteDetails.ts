export class siteDetails{
    SiteCode:number;
    SiteShortCode:string;
}