import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { dropDownField } from './dropDownField';
import { mockDropdownData } from './mockDropdownData'
import { HttpClientModule,HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { map, tap, catchError } from "rxjs/operators";
import { siteDetails } from './siteDetails';
import{userDetail} from './Model/UcModel/userDetail';
import{siteDetail} from './Model/UcModel/siteDetail';
import {httpOptions} from './Services/httpConstant';
import {loginServiceURL} from './Services/httpConstant';

//const httpOptions = {
  //headers: new HttpHeaders({
    //'Content-Type':  'application/json'
  //})
//};

@Injectable({
  providedIn: 'root'
})
export class LoginService {

dataStr:string[]=[];
Supplier:siteDetails[]=[];
messageService :string []=[];
userDetailData:userDetail;
userdetailtst:any;
siteDetails:siteDetail[];
  constructor(private httpClient: HttpClient  ) { }

  add(message: string) {
    this.dataStr.push(message);
  }
  private log(message: string) {
    this.messageService.push("a");
  }
  ValidateUser (isvendor:number, loginid:string, strpwd:string, loginsite:string, ipadd:string , requestID : string): Observable<any> {
    console.log('inside validate user service');
    console.log(loginServiceURL + 'uservalidate?isvendor='+isvendor+'&loginid='+loginid+'&strpwd='+strpwd+'&loginsite='+loginsite+'&ipadd=10.&requestId='+requestID);
    return this.httpClient.post<any>(loginServiceURL + 'uservalidate?isvendor='+isvendor+'&loginid='+loginid+'&strpwd='+strpwd+'&loginsite='+loginsite+'&ipadd=10.&requestId='+requestID, httpOptions).pipe(
      tap(_ => this.log('inside tap')),
      catchError(this.handleError<any>('login service', []))
    );
  }

  loginSiteConfiguration(  inType : string , siteUrl : string , domainId : string ) : Observable<siteDetail>{
    return this.httpClient.post(loginServiceURL + 'LoginSiteConfiguration?InType='+inType+'&siteurl='+siteUrl+'&DomainId='+domainId, JSON.stringify(''), httpOptions).pipe(
      tap(res => this.log('inside cc services')), catchError(this.handleError<any>('GetUserID', [])))
  }

  getUserDetailsFromSite (siteId:string, userId:string, ipadd:string , isVendor : string): Observable<any> {
    // console.log(product);
    return this.httpClient.post<any>(loginServiceURL + 'getUserDetailsFromSite?siteId='+siteId+'&UserId='+userId+'&IPAddress='+ipadd+'&IsVendor'+isVendor, httpOptions).pipe(
      tap(_ => this.log('inside tap')),
      catchError(this.handleError<any>('login service', []))
    );
  }

  getOimRedirectApiURL() : Observable<any> {
    console.log(loginServiceURL + 'getOimRedirectApiURL?type=1&instanceName=OIM-Submit&validID=');
    return this.httpClient.post<any>(loginServiceURL + 'getOimRedirectApiURL?type=1&instanceName=OIM-Submit&validID=', httpOptions).pipe(
      tap(_ => this.log('inside tap')),
      catchError(this.handleError<any>('login service', []))
    );
  }

  getHeaderConfigurationDetails (siteId:string, userId:string, ipadd:string , isVendor : string, siteUrl) : Observable<any> {
    return this.httpClient.post<any>(loginServiceURL + 'GetHeaderConfigurationDetails?siteId='+siteId+'&UserId='+userId+'&IPAddress='+ipadd+'&IsVendor='+isVendor+'&LoginSite='+siteUrl, httpOptions).pipe(
      tap(_ => this.log('inside tap')),
      catchError(this.handleError<any>('login service', []))
    );
  }

  getIpAddress() : Observable<any>  {
    return this.httpClient.get<{ip:string}>('https://jsonip.com');
  }

  getUserDetails(samlData: any):Observable<any>
  {
    return this.httpClient.post<any>(loginServiceURL , JSON.stringify(samlData) , httpOptions).pipe(
      tap(_ => this.log('inside tap')),
      catchError(this.handleError<any>('login service', []))
    );
  }
  extractData(res: Response) {
    let body = res.json();
    return body || {};
  }
  handleErrorObservable (error: Response | any) {
    console.error(error.message || error);
    return Observable.throw(error.message || error);
  }

  private handleError<T> (operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {

      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead

      // TODO: better job of transforming error for user consumption
      console.log(`${operation} failed: ${error.message}`);

      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }
  getHeroes(): Observable<dropDownField[]> {
    // TODO: send the message _after_ fetching the heroes
    this.add('HeroService: fetched heroes');
    return of(mockDropdownData);
  }
}
