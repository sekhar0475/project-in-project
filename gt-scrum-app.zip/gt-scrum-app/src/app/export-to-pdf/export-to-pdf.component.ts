import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-export-to-pdf',
  templateUrl: './export-to-pdf.component.html',
  styleUrls: ['./export-to-pdf.component.css']
})
export class ExportToPdfComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
