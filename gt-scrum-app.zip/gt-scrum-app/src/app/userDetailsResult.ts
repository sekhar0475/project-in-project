import { userDetail } from './Model/UcModel/userDetail';

export const userDetailsResult : any = 

    {  
      
        UserCode:1,
        UserName:'Rakesh Parab',
        Status:0,
        ContCode:0,
        StatusMessage:"Login Successfull !",
      siteDetails:[  
           {  
              SiteCode:1,
              SiteShortCode:'JMD',
              SiteName:'',
              SiteUrl:'',
              StatusMessage:'0',
              roleDetails:[
                  {
                    RoleCode:1,
                    RoleName:'Super Admin',
                    menuDetails:[
                        {
                            MenuCode:0,
                            MenuName:'',
                            MenuLink:'',
                            MenuImage:''
                        }
                    ]
                  }
              ]
           }
        ]
        
        
     }
