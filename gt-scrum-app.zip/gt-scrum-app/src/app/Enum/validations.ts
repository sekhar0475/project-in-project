export enum validations{
  REQUIRED,
  RANGE,
  EMAIL,
  PANCARDFOARMAT,
  PANCARDLENGTH,
  AADHAR,
  CountCheck
}
