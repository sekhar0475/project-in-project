import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-form-post',
  templateUrl: './form-post.component.html',
  styleUrls: ['./form-post.component.css']
})
export class FormPostComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
