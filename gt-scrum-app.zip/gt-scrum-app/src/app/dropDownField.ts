export class dropDownField {
    id: number;
    name: string;
  }