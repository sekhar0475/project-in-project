import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-reactive-forms-validations',
  templateUrl: './reactive-forms-validations.component.html',
  styleUrls: ['./reactive-forms-validations.component.css']
})
export class ReactiveFormsValidationsComponent implements OnInit {
  registerForm: FormGroup;
  submitted = false;
  firstname: string ;
  constructor(private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.registerForm = this.formBuilder.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]],
      confirmPassword: ['', Validators.required]
  });
}

get f() {
  return this.registerForm.controls;
}

onSubmit() {
  this.submitted = true;
this.firstname;
this.registerForm.controls.firstName.value;
  // stop here if form is invalid
  if (this.registerForm.invalid) {
      return;
  }

  alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.registerForm.value))
}

}
