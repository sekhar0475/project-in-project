import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-card-creation-css',
  templateUrl: './card-creation-css.component.html',
  styleUrls: ['./card-creation-css.component.css']
})
export class CardCreationCssComponent implements OnInit {
isFirstTabMediaVisible: boolean = true;
isSecondTabMediaVisible: boolean = true;
isThirdTabMediaVisible: boolean = true;
isFourthTabMediaVisible: boolean = true;

  constructor() { }

  ngOnInit() {
  }
onFirstTabh2Click()
{
this.isFirstTabMediaVisible = !this.isFirstTabMediaVisible;
}
onSecondTabh2Click()
{
this.isSecondTabMediaVisible = !this.isSecondTabMediaVisible;
}
onThirdTabh2Click()
{
this.isThirdTabMediaVisible = !this.isThirdTabMediaVisible;
}
onFourthTabh2Click()
{
this.isFourthTabMediaVisible = !this.isFourthTabMediaVisible;
}
}
