import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CardCreationCssComponent } from './card-creation-css.component';

describe('CardCreationCssComponent', () => {
  let component: CardCreationCssComponent;
  let fixture: ComponentFixture<CardCreationCssComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CardCreationCssComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CardCreationCssComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
