import { requestDetail } from '../CCModel/requestDetail';

export class SharedState
{
  userCode : string ="";
  userDomainId : string = "";
  windowsDomainId : string = '';
  siteCode : string ="";
  siteName : string = '';
  userName : string ="";
  roleCode : string ="";
  roleName : string = '';
  ipAddress : string = '';
  isVendor : string = '0';
  siteUrl : string = '';
  siteUiCode : string = '';
  errorMessage : string = '';
}


export class searchRequester
{
  pageHeader : string ="";
  navigateNext : string = "";
  stateElement : any;
  ucObj : any;
}
