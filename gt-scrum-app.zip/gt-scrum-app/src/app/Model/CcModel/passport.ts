import {fieldDetail} from './fieldDetail'

export class passport{
  countryIdOfOrigin : fieldDetail ;
   passportNumber : fieldDetail ;
   passportValidFrom : fieldDetail ;
   passportValidTo : fieldDetail ;
}
