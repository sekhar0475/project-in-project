import {fieldDetail} from './fieldDetail';

export class resReference{
  refDLink: fieldDetail = new fieldDetail();
  refName: fieldDetail = new fieldDetail();
  refAddress: fieldDetail = new fieldDetail();
  refContact: fieldDetail = new fieldDetail();
}
