import {tradeDetail} from './tradeDetail';
import {fieldDetail} from './fieldDetail';

export class trade {
  tradeDetail:tradeDetail[];
  tradeFieldDetail:fieldDetail;
}
