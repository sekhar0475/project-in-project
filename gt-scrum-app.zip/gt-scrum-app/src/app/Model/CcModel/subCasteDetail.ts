export class subCasteDetail{
    code:string;
    name:string;
}
