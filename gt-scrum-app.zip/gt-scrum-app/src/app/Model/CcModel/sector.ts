import {sectorDetail} from './sectorDetail';
import {fieldDetail} from './fieldDetail';

export class sector{
  sectorListDetails:sectorDetail[];
  sectorFieldDetail:fieldDetail;
}
