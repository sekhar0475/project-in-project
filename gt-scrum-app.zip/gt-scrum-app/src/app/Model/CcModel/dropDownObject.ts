import {dropDownDetail} from './dropDownDetail';
import {fieldDetail} from './fieldDetail';

export class dropDownObject
{
   dropdownListDetails: dropDownDetail[];
   dropdownFieldDetail : fieldDetail;
}
