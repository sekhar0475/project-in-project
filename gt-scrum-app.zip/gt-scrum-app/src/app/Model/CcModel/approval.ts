import { fieldDetail } from './fieldDetail';

export class ApprovalDetailsData{
   code : any;
   workerCode:  fieldDetail = new fieldDetail();
   resName:  fieldDetail = new fieldDetail();
   siteCode:  fieldDetail = new fieldDetail();
   isActive:  fieldDetail = new fieldDetail();
   activeStatus:  fieldDetail = new fieldDetail();
   activateDate:  fieldDetail = new fieldDetail();
   isApproved:  fieldDetail = new fieldDetail();
   approvedStatus:  fieldDetail = new fieldDetail();
   approvedDate:  fieldDetail = new fieldDetail();
   isPrinted:  fieldDetail = new fieldDetail();
   printStatus:  fieldDetail = new fieldDetail();
   isHibernated:  fieldDetail = new fieldDetail();
   hibernatedStatus:  fieldDetail = new fieldDetail();
   validityDate:  fieldDetail = new fieldDetail();
   lwd:  fieldDetail = new fieldDetail();
   contractEndDate:  fieldDetail = new fieldDetail();
   modifiedBy:  fieldDetail = new fieldDetail();
   modifiedDt:  fieldDetail = new fieldDetail();
   prmid :  fieldDetail = new fieldDetail();
   acplid :  fieldDetail = new fieldDetail();
   cardUpdateLink :  fieldDetail = new fieldDetail();
   candidateID:  fieldDetail = new fieldDetail();
   epName :  fieldDetail = new fieldDetail();
   cardNo : fieldDetail = new fieldDetail();
   cardIssuelevel: fieldDetail = new fieldDetail();
   cardFormat: fieldDetail = new fieldDetail();
}
