
import { dropDownDetail } from './DropDownDetail';

export class clscastmodel{
    code:string;
    name:string;
    subCasteListDetails: dropDownDetail[];
    constructor()
    {
      this.code = "";
      this.name = "";
    }
  }