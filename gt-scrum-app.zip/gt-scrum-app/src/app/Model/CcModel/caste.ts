import {fieldDetail} from './fieldDetail';
import{casteDetail} from './casteDetail';

export class caste{
  casteListDetails:casteDetail[] = new Array();
  casteFieldDetail:fieldDetail =  new fieldDetail();
  subCasteFieldDetail:fieldDetail = new fieldDetail();

}
