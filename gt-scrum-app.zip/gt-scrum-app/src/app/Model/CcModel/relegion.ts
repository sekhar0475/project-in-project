import {fieldDetail} from './fieldDetail';
import {dropDownDetail} from './DropDownDetail';
export class relegion{
    relegionListDetails:dropDownDetail[];
    relegionFieldDetail:fieldDetail;
}