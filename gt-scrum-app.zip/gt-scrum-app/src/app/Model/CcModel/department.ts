import {departmentDetail} from './departmentDetail';
import {fieldDetail} from './fieldDetail';

export class department{
  DepartmentListDetails: departmentDetail[];
  DepartmentFieldDetail: fieldDetail;
}
