export class dropDownDetail{
  mstcode:number;
  mstText:string;
  IsDirty : boolean = false;
  Visible: boolean = false;
  ddlDetails : dropDownDetail[];
  SelectedName : string = "";
}
