import { mstDetails } from './MstDetails';
import { fieldDetail } from './fieldDetail';
import{ FilterPipe } from './../../filter.pipe';

export class mstCollection{
   listDetails: mstDetails[] = new Array();
  fieldDetail: fieldDetail = new fieldDetail();

  constructor(){

  }
}
