import {fieldDetail} from './fieldDetail';
import {subCasteDetail} from './subCasteDetail';

export class subCaste{
subCasteFieldDetail:fieldDetail;
subCasteListDetail:subCasteDetail[];
}