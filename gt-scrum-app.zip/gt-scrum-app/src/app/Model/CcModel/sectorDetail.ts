import {plant} from './plant';

export class sectorDetail{
  code : number;
  name: string;
  plant:plant;
}
