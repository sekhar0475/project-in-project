import {fieldDetail} from './fieldDetail';
import {mstDetails} from './MstDetails';
export class bloodGroup{
  bloodGroupListDetails:mstDetails[];
  bloodGroupFieldDetail:fieldDetail;
}
