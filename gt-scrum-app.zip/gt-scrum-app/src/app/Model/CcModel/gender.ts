import {fieldDetail} from './fieldDetail';
import {mstDetails} from './MstDetails';
export class gender{
  genderListDetails:mstDetails[];
  genderGroupFieldDetail:fieldDetail;
}
