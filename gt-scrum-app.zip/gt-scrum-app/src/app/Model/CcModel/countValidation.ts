  export class countValidation{
    maxValidCount:number;
    validityDate:string;
    epCount : number;
    displayText:string;
    checkFlag: string;
  }
  