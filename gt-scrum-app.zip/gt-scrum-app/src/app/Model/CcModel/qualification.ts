import {dropDownDetail} from './DropDownDetail';
import{fieldDetail} from './fieldDetail';

export class qualification{
    fieldDetailVar:fieldDetail;
    qualificationListDetails:dropDownDetail[];
    qualificationFieldDetail: fieldDetail = this.fieldDetailVar;
}