
import {subCaste} from './subCaste';

export class casteDetail{
    code:string;
    name:string;
    subCaste:subCaste;
    subCasteListDetails : any[];
}
