import { fieldDetail } from './fieldDetail';
import {requestDetail} from './requestDetail';
import{ passport } from './passport'
import{ mstCollection } from './mstCollection'
import { resReference } from './resReference';

export class otherDetail
{
   requestDetails : requestDetail;
   isIndian: mstCollection = new mstCollection();
   isHCLocoMotive : mstCollection = new mstCollection();
   isHCHearing : mstCollection = new mstCollection();
   isHCVisual : mstCollection = new mstCollection();
   isHibenationException : mstCollection = new mstCollection();
   isMarried : mstCollection = new mstCollection();
   isHandicapped : mstCollection = new mstCollection();
   bankCode : mstCollection = new mstCollection();
   handicappedReason : fieldDetail = new fieldDetail();
   isRelative: mstCollection  = new mstCollection();
   relativeReason : fieldDetail = new fieldDetail() ;
   idProofTypeCode1 : mstCollection = new mstCollection();
   idProofNo1 : fieldDetail = new fieldDetail();
   idProofTypeCode2 : mstCollection = new mstCollection();
   idProofNo2 : fieldDetail = new fieldDetail();
   refName1 : fieldDetail = new fieldDetail();
   refAddress1 : fieldDetail = new fieldDetail();
   refName2 : fieldDetail  = new fieldDetail();
   refAddress2 : fieldDetail  = new fieldDetail();
   bankBranch: fieldDetail = new fieldDetail();
   bankAccountNo : fieldDetail = new fieldDetail() ;
   ifscCode : fieldDetail  = new fieldDetail();
   marriageDate : fieldDetail  = new fieldDetail();
   noOfMaleChild : fieldDetail  = new fieldDetail();
   noOfFemaleChild : fieldDetail  = new fieldDetail();
   ctc : fieldDetail  = new fieldDetail();
   grossSalary : fieldDetail  = new fieldDetail();
   linkAddresses : fieldDetail = new fieldDetail();
   changeBy :string;
   changeByRole: string;
   ccRemarks: mstCollection = new mstCollection();
   idProofLink : fieldDetail  = new fieldDetail();
   referenceLink : fieldDetail  = new fieldDetail();
   refDLink : resReference = new resReference();
   refDLink2 : resReference = new resReference();
   refDLink3 : resReference = new resReference();
   refDLink4 : resReference = new resReference();
   workerCode : fieldDetail = new fieldDetail();
}
