import { fieldDetail } from './fieldDetail';
import { mstCollection } from './mstCollection';

export class address{
   addType : fieldDetail = new fieldDetail();
   addLine1 : fieldDetail = new fieldDetail();
   addLine2 : fieldDetail = new fieldDetail();
   addLine3 : fieldDetail = new fieldDetail();
   stateCode : mstCollection = new mstCollection();
   districtCode : mstCollection = new mstCollection();
   talukaCode: mstCollection = new mstCollection();
   pinCode : fieldDetail = new fieldDetail();
   villegeCode: mstCollection = new mstCollection();
   policeStation : fieldDetail = new fieldDetail();

}
