import {dropDownDetail} from './dropDownDetail';
import {fieldDetail} from './fieldDetail';

export class workSkill{
  workSkillDetails: dropDownDetail[];
  workSkillFieldDetail:fieldDetail;
}
