export class requestDetail
{
  siteCode:string ="";
  roleCode:string ="";
  resCode:string ="";
  RequestID: string ="";
  requestIndex: number = 0;
}
