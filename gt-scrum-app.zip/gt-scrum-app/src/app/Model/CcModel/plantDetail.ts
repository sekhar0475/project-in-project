import {department} from './department';

export class plantDetail{
  code: number;
  name: string;
  departments: department;
}
