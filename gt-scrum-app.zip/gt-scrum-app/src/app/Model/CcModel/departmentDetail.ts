import { trade } from './trade';

export class departmentDetail{
  code: number;
  name: string;
  trade: trade;
}
