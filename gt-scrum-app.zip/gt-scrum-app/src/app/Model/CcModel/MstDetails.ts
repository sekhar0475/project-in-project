import { mstCollection } from './mstCollection';

export class mstDetails{
  mstcode:string;
  mstText:string;
  MstCollection : mstCollection = new mstCollection();

  constructor()
  {
    this.mstcode = "";
    this.mstText = "";
  }
  
}


