export class approvalGridDetails{
          code :string;
          resCode  :string;
          appRoleName  :string;
          appStatus  :string;
          appBy  :string;
          appByName  :string;
          appDate  :string;
          appRemarks  :string;
          recordStatus  :string;

}
