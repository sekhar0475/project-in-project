import { mstCollection } from './mstCollection';

export class jcMapping{
   levelName: mstCollection = new mstCollection();
   regionCode: mstCollection = new mstCollection();
   stateCode: mstCollection = new mstCollection();
   areaName: mstCollection = new mstCollection();
   mpName: mstCollection = new mstCollection();
   locType: mstCollection = new mstCollection();
   jioLocationCode: mstCollection = new mstCollection();
   mgrCode: mstCollection = new mstCollection();
   locTypeSearch: mstCollection = new mstCollection();
   locSearch: mstCollection = new mstCollection();
}
