import {plantDetail} from './plantDetail';
import { fieldDetail } from './fieldDetail';

export class plant{
  plantListDetails:plantDetail[];
  plantFieldDetail: fieldDetail;

}
