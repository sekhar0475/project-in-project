export class fieldDetail{
isDisplayed: boolean ;
isMandatory: boolean;
label: string ;
value: string;
editFlag : boolean;
fieldLength : string;

constructor()
{
  this.isDisplayed  = true;
  this.isMandatory  = false;
  this.label  = '';
  this.value  = '';
  this.editFlag   = false;
  this.fieldLength = "-1" ;
}
}

