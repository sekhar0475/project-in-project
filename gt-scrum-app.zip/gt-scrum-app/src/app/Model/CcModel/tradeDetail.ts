import {workSkill} from './workSkill';

export class tradeDetail{
  code: number;
  name: string;
  workskill: workSkill;
}
