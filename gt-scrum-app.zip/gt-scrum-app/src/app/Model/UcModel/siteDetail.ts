import { roleDetail } from './roleDetail';

export class siteDetail{
    siteCode: number;
    siteShortCode: string;
    siteName: string;
    siteUrl: string;
    siteUICode:string;
    statusMessage: string;
    roleDetails: roleDetail[];
    siteHeader : string;
    siteFooter : string;
    siteLogo : string;
    siteLogoAlign : string;
    loginPageImage : string ;
    homePageImage : string ;
    welcomeText : string ;
    loginText1 : string;
    loginText2 : string ;
}
