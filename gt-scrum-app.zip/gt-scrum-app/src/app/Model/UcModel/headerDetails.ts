import { siteDetail } from './siteDetail';

export class headerDetails{
  headerLogoImage : string;
  headerLogoText : string;
  siteDetail : siteDetail;
}
