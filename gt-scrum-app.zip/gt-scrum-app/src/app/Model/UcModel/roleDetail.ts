import { menuDetail } from './menuDetail';
import { requestDetail } from '../CCModel/requestDetail';

export class roleDetail
{
    roleCode?:number;
    roleName:string;
    menuDetails: menuDetail[] = new Array();
}

export class userRoledetails{

    constructor()
    {

    }
    // For Role Dropdown
    roleCode : number = 0;
    roleName : string ="";
    roleAbbre : string = "";
    roleAssigned : number =0;
    isVendor : boolean = false; 
    isApprover : boolean = false;
    isMapped : boolean = false;
    hasInternetAccess : boolean = false;
    isActive : any = 0;
    groupName : string ="";
    RequestDetails : requestDetail;
    createdBy:string ="";
    // Common Dropdowns
    mstCode : number;
    mstName : string;
    mappingType : string;
    isAssigned : number;
    RoleAssigned : number;
}

export class UserRoleList {
    listName : string;
    role :userRoledetails[]= new Array();
}

export class userRoleCreation {
    Code : number = 0;
    selectedRoles : userRoledetails[] = new Array();
    EICRoles : userRoledetails[] = new Array();
    EICDRoles : userRoledetails[]= new Array();
    GroupAdminRoles : userRoledetails[] = new Array();
    RHRRoles : userRoledetails[]=new Array();
    SHRRoles : userRoledetails[]= new Array();
    AHRRoles : userRoledetails[]= new Array();
    MGRRoles : userRoledetails[]= new Array();
    EICDFrom : string = "";
    EICDTo : string = "";
}

export class SaveRoles{
        
        Code : number = 0;
        GroupCode : number =0;
        requestDetail : requestDetail = new requestDetail();
        RolesCollection : UserRoleList[] = new Array();
    }


