import { mstCollection } from '../CcModel/mstCollection';
import { requestDetail } from '../CCModel/requestDetail';

export class menuDetail {
    isAssigned: number = 0;
    menuCode: String = "";
    menuName: string = "";
    parentMenuCode: string;
    SiteFieldCode: number;
    SiteFieldSuffix: string = "";
    menuLink: string = "";
    menuImage: string = "";
    pageHeader: string = "";
    pageCode: string = "";
    pageLink: string = "";
    IsActive: boolean;
    menuSeq: string = "";
    menuType: string = "";
    parentMenuName: string = "";
    requestedBy : string ="";
    parentMenuData : any;
    objRequest: requestDetail = new requestDetail();

    // menuLink:string ="";
    // menuImage:string ="";
}

export class groupMenuddl {
    name: string;
    submenuArray: menuDetail[];
}

// isAssigned: 0
// menuCode: 29
// menuName: "Trade"
// menuSeq: 4
// menuType: "MST"
// parentMenuCode: 15
// parentMenuMenuName: "SPDT Mappings"