export class dashBoardResApprovals{
  roleCode : number;
  roleAbbre : string;
  roleName : string;
  pendingCount : string;
}
