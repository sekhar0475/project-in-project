import { siteDetail } from './siteDetail';

export class userDetail{
    userCode : number;
    username : string;
    Status : number;
    ContCode : number;
    StatusMessage : string;
    siteDetails : siteDetail[];
}