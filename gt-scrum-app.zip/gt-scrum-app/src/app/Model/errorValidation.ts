export class errorValidation{
errorMessage: string ;
errorFlag: string
}
