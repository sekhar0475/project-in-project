import { requestDetail } from '../CcModel/requestDetail';
import { fieldDetail } from '../CcModel/fieldDetail';
import { mstCollection } from '../CcModel/mstCollection';
export class SiteFieldsEditConfig {
    requestDetails: requestDetail;
    code: number;
    siteFieldCode: mstCollection = new mstCollection();
    roleCode: mstCollection = new mstCollection();
    fieldgroup: mstCollection = new mstCollection();
    approvalFlag: string;
    editFlag: string;
    isActive: mstCollection = new mstCollection();
    updateddBy: number;
}
