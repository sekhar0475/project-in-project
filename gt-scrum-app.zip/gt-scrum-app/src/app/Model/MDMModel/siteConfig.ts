import{ requestDetail } from '../CcModel/requestDetail';
import {fieldDetail} from '../CcModel/fieldDetail';
import { mstCollection } from '../CcModel/mstCollection';
export class SiteConfig {
    RequestDetails : requestDetail;
    code        : number;
    groupCode   : mstCollection  = new mstCollection();
    shortCode   : string;
    configDesc  : string;
    s_Value     : string;
    d_Value     : string;
    isActive    : mstCollection  = new mstCollection();

}

