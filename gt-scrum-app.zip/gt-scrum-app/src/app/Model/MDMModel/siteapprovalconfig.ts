import{ requestDetail } from '../CcModel/requestDetail';
import {fieldDetail} from '../CcModel/fieldDetail';
import { mstCollection } from '../CcModel/mstCollection';
export class SiteApprovalConfig {

    requestDetails  : requestDetail;
    code            : number;
    roleCode        : mstCollection  = new mstCollection();
    appDisplaySeq   : number;
    isAutoApp       : string;
    appDuration     : number;
    deptRoleCode1   : mstCollection  = new mstCollection();
    deptRoleCode2   : mstCollection  = new mstCollection();
    deptRoleCode3   : mstCollection  = new mstCollection();
    deptRoleCode4   : mstCollection  = new mstCollection();
    isActive        : mstCollection  = new mstCollection();

}
