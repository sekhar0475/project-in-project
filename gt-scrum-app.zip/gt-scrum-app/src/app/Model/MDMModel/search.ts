import { mstCollection } from '../CcModel/mstCollection';

export class Search {

    searchText: string;
    statusCode: string;
    statusText: string = "1";
    statusVisible: boolean = false;
    dynamicVisible: boolean = false;
    dynamicCode: string;
    dynamicText: string;
    status: mstCollection = new mstCollection;
    dynamic: mstCollection = new mstCollection;
}
