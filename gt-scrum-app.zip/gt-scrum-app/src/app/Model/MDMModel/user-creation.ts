import {requestDetail} from '../../Model/CCModel/requestDetail';

export class UserCreation
{
    RequestDetails : requestDetail;
    Code:number= 0;
    loginID : string= "";
    userName :string= "";
    userID:string= "";
    pwd:string = "";
    mobileNo:string = "";
    eMailID:string = "";

    reportingID:string = "";
    reportingLoginID:string = "";
    reportingName:string = "";
    reportingEmailID:string = "";
    IsVendor:number = 0;
    IsABVS:number =0;
    ContractorCode:number = 0;
    IsActive:number = 0;
    CreatedBy:string ="0";
    status:number;
    UserStatus : string ="";
    IsLocked:number =0;

    //     'CreatedBy':'',

    //     }
}
