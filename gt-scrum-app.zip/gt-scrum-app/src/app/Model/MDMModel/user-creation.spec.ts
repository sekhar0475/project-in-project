import { UserCreation } from './user-creation';

describe('UserCreation', () => {
  it('should create an instance', () => {
    expect(new UserCreation()).toBeTruthy();
  });
});
