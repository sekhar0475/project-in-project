import { SiteApprovalConfig } from './siteapprovalconfig';

describe('SiteApprovalConfig', () => {
  it('should create an instance', () => {
    expect(new SiteApprovalConfig()).toBeTruthy();
  });
});
