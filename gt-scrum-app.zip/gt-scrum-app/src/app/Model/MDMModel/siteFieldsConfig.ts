import{ requestDetail } from '../CcModel/requestDetail';
import {fieldDetail} from '../CcModel/fieldDetail';
import { mstCollection } from '../CcModel/mstCollection';
export class siteFieldsConfig {

    requestDetails      : requestDetail;
    code                : number;
    fieldName           : string ;
    fieldID             : string;
    labelID             : string;
    labelText           : string;
    tableRef            : mstCollection  = new mstCollection();
    fieldType           : mstCollection  = new mstCollection();
    fieldLength         : string;
    fieldGroup          : mstCollection  = new mstCollection();
    fieldParentID       : mstCollection  = new mstCollection();
    fieldSeq            : number;
    displayFlagAdd      : string;
    displayFlagEdit     : string;
    isMandatory         : string;
    isActive            : mstCollection  = new mstCollection();
    UpdateddBy          : number;
}