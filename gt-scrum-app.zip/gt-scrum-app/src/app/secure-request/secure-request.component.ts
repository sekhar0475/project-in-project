import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-secure-request',
  templateUrl: './secure-request.component.html',
  styleUrls: ['./secure-request.component.css']
})
export class SecureRequestComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    document.location.href = 'https://stohs.jio.com:4443/oamfed/idp/initiatesso?providerid=SCRUMV2';
  }

}
