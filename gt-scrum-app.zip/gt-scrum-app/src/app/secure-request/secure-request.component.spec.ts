import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SecureRequestComponent } from './secure-request.component';

describe('SecureRequestComponent', () => {
  let component: SecureRequestComponent;
  let fixture: ComponentFixture<SecureRequestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SecureRequestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SecureRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
