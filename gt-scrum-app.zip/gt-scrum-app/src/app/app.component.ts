import { Component } from '@angular/core';
import { SharedState } from './Model/Common/InterPage';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app';

  constructor(){

  }
}
