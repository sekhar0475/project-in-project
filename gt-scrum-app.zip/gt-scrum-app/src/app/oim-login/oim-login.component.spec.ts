import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OimLoginComponent } from './oim-login.component';

describe('OimLoginComponent', () => {
  let component: OimLoginComponent;
  let fixture: ComponentFixture<OimLoginComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OimLoginComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OimLoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
