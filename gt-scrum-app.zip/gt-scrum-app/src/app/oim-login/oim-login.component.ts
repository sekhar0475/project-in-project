import { Component, OnInit } from '@angular/core';
import { LoginService } from '../login.service';

@Component({
  selector: 'app-oim-login',
  templateUrl: './oim-login.component.html',
  styleUrls: ['./oim-login.component.css']
})
export class OimLoginComponent implements OnInit {

  constructor(private loginService: LoginService) { }

  ngOnInit() {

    window.location.href =  "/UserValidateNet/uservalidate.aspx";

  }

}
