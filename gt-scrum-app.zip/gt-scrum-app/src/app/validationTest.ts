import { validations } from './Enum/validations';
import { isNullOrUndefined } from 'util';

export class validationTest {

  errorMessage: string;
  regexp: any;

  isRequired(fieldObject: any): string {
    if (fieldObject.isMandatory && (fieldObject.value == '' || fieldObject.value == null || fieldObject.value == '-1')  &&  fieldObject.isDisplayed == true  ) {
      return this.getErrorMessage(fieldObject.label, validations.REQUIRED);
    }
    else {
      return '';
    }
  }
  isRequiredFronRadioSelected( radioValue: any,fieldObject: any): string {

    if (radioValue != undefined && radioValue != null && radioValue.isMandatory && radioValue.value =='1') {

      if (fieldObject.isMandatory && (fieldObject.value == '' || fieldObject.value == null)) {
        return this.getErrorMessage(fieldObject.label, validations.REQUIRED);
      }
      else {
        return '';
      }
    }
    else {
      return '';
    }
  }
  requiredValidator(fieldObject: string): string {
    if ((fieldObject === "" || isNullOrUndefined(fieldObject) === true)) {
      return this.getErrorMessage(this.errorMessage, validations.REQUIRED);
    }
    else {
      return '';
    }
  }

  requiredValidatorByString(fieldObject: string): string {
    if (fieldObject == '' || fieldObject == null) {
      return this.getErrorMessage("Field", validations.REQUIRED);
    }
    else {
      return '';
    }
  }

  rangeValidator(fieldName: string, id: number): string {
    if (id < 9) {
      return this.getErrorMessage(fieldName, validations.RANGE);
    }
    else {
      return '';
    }

  }

  isEmail(fieldObject: any): string {
    var serchfind: boolean;
    this.regexp = new RegExp(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/);
    serchfind = this.regexp.test(fieldObject.value);
    if (!serchfind) {
      return this.getErrorMessage(fieldObject.label, validations.EMAIL);
    }
    else {
      return '';
    }

    // return serchfind
  }

  isPancard(fieldObject: any) {
    var serchfind: boolean;
    this.regexp = new RegExp(/^([a-zA-Z]){5}([0-9]){4}([a-zA-Z]){1}?$/);
    serchfind = this.regexp.test(fieldObject.value);
    if (!serchfind) {
      return this.getErrorMessage(fieldObject.label, validations.PANCARDFOARMAT);
    }
    else {
      return '';
    }
  }
  checkAaddharValidNumber(fieldObject: any, fieldObjectDdl: any) {

    try {
      if (fieldObject != undefined && fieldObject != null && fieldObjectDdl != undefined && fieldObjectDdl != null && fieldObject.isMandatory) {
        if ((fieldObjectDdl as string).indexOf('Aadhar') !== -1 && fieldObject.value.toString().length != 12) {
          return this.getErrorMessage(fieldObject.label, validations.AADHAR);
        }
        if ((fieldObjectDdl as string).indexOf('PAN') !== -1) {
          if (fieldObject.value.toString().length != 10) {
            return this.getErrorMessage(fieldObject.label, validations.PANCARDLENGTH);
          }
          else if (fieldObject.value.toString().length != 10) {
            this.isPancard(fieldObject);
          }
        }
        else {

          return '';
        }
      }
      else {

        return '';
      }
    } catch (error) {
      return '';

    }
  }
  checkWOCountvalidate(fieldName: string, MaxValidCount: any, EPCreatedCount: any, CheckFlag: any) {
    if (MaxValidCount != undefined && MaxValidCount != null && EPCreatedCount != undefined && EPCreatedCount != null && CheckFlag != undefined && CheckFlag != null  && CheckFlag != '1') 
    {
      if ((MaxValidCount as number) <= (EPCreatedCount as number)) {
        return this.getErrorMessage(fieldName, validations.CountCheck);
      }
      else {
        return '';
      }
    }
    else {
      return '';
    }
  }

  isFloatNumber(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57) && charCode != 46) {
      return false;
    }
    return true;

  }

  isIntNumber(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;

  }

  getErrorMessage(fieldName: string, validationName: validations): string {
    switch (validationName) {
      case validations.REQUIRED:
        {
          return fieldName + ' is Required.';
          break;
        }
      case validations.RANGE:
        {
          return fieldName + ' is Outside Range.';
          break;
        }
      case validations.EMAIL:
        {
          return fieldName + ' is not a valid Email.';
          break;
        }
      case validations.PANCARDFOARMAT:
        {
          return fieldName + ' is not a valid PAN Number.';
          break;
        }
      case validations.PANCARDLENGTH:
        {
          return ' PAN Number should be 10 char.';
          break;
        }
      case validations.AADHAR:
        {
          return 'Aadhar card number should be 12 digit.';
          break;
        }
      case validations.CountCheck:
        {
          return fieldName + ' max count over.';
          break;
        }
    }

  }

}
