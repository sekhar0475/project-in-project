import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl } from '@angular/forms';
import { requestDetail } from '../../Model/CCModel/requestDetail';
import { menuDetail, groupMenuddl } from '../../Model/UcModel/menuDetail';
import { Router } from '@angular/router';
import { SharedState, searchRequester } from '../../Model/Common/InterPage';
import { CommonService } from '../../Services/common.service';
import { validationTest } from 'src/app/validationTest';
import { MatSelect, MatOption } from '@angular/material';
@Component({
  selector: 'app-rolemenu-master',
  templateUrl: './rolemenu-master.component.html',
  styleUrls: ['./rolemenu-master.component.css']
})
export class RolemenuMasterComponent implements OnInit {

  //#region Temp & initial variables.
  searchRequester: searchRequester = new searchRequester();
  shared: SharedState = new SharedState();
  requestForMenu: requestDetail = new requestDetail();
  roleName: string = "";
  roleAbbr: string = "";
  userName: string = "test";
  isValidate: boolean = false;
  msgSave: string = "";
  validationTest: validationTest = new validationTest();
  //#endregion

  //#region Initial Level params for Dropdowns
  groupingddl: groupMenuddl[] = new Array;
  masterMenu: menuDetail[] = new Array();
  //#endregion

  //#region Save related Models
  masterMenuModel: menuDetail[] = [];
  reportMenuModel: menuDetail[] = new Array();
  childSelected: menuDetail[] = new Array();
  testing: any;
  pokemonControl = new FormControl();
  //#endregion

  // //#region  Visibility Control
  // menuReportsVisible: boolean = false;
  // menuMastersVisible: boolean = false;
  // //#endregion

  groupedDll: groupMenuddl[] = new Array;
  reportsDll: groupMenuddl[] = new Array;


  ngOnInit() {
    if (!window.history.state.hasOwnProperty('pageHeader')) {
      this.shared = null;
      this.router.navigateByUrl('searchlist', { state: this.searchRequester });
    }
    else {
      this.shared = JSON.parse(atob(localStorage.getItem('shared')));
      this.userName = this.shared.userName;
      this.searchRequester = window.history.state;

      this.roleName = this.searchRequester.stateElement.stateEle['role Name'];
      this.roleAbbr = this.searchRequester.stateElement.stateEle['role Abbrevation'];
      this.fetchRoles();
    }
  }

  returnDisabled(type): boolean {
    if(type=== "report")
    {
      return this.masterMenuModel.filter(f => f.menuName === "Reports").length > 0 ? false : true;
    }
    else if(type=== "master")
    {
      return this.masterMenuModel.filter(f => f.menuName === "Masters").length > 0 ? false : true;
    }
    else if(type === "masterErr")
    {
      return this.masterMenuModel.filter(f=> f.menuName === "Masters").length > 0 && this.childSelected.length === 0 ? true : false; 
    }
    //return true;
  }

  constructor(private commonService: CommonService, private router: Router) { }

  VisibilityControl() {
    this.isValidate = false;

    this.childSelected = this.masterMenuModel.filter(f => f.menuName === "Masters").length > 0 ?
      this.childSelected : new Array();


    // if (this.masterMenuModel.filter(f => f.menuName === "Masters").length > 0) {
    //   this.menuMastersVisible = true;
    // }
    // else {
    //   this.menuMastersVisible = false;
    //   this.childSelected = new Array();
    // }

    this.reportMenuModel = this.masterMenuModel.filter(f => f.menuName === "Reports").length > 0 ?
      this.reportMenuModel : new Array();

    // if (this.masterMenuModel.filter(f => f.menuName === "Reports").length > 0) {
    //   this.menuReportsVisible = true;
    // }
    // else {
    //   this.menuReportsVisible = false;
    //   this.reportMenuModel = new Array();
    // }
  }


  fetchRoles() {
    //#region Request Creation
    this.requestForMenu.siteCode = this.shared.siteCode;
    this.requestForMenu.resCode = "MENU" + JSON.parse(JSON.stringify(this.searchRequester.ucObj.resCode));
    this.requestForMenu.RequestID = "ASS|" + this.shared.userCode + "|" + this.searchRequester.stateElement.stateEle['roleCode_0'] + "|0";

    //#endregion

    this.commonService.DataSet(this.requestForMenu).subscribe(res => {
      //Set Main dropdown
      this.masterMenu = res.filter(f => f.menuType === "Main");

      //#region set Masters Dropdown 
      this.groupedDll = new Array();
      res.filter(f => f.menuType === "MST").map(x => x.parentMenuName).
        filter((parentMenuName, index, arr) => arr.indexOf(parentMenuName) == index).
        sort().forEach
        (
          element => {
            var a = new groupMenuddl();
            a.name = element; a.submenuArray = res.filter(f => f.parentMenuName === element);
            this.groupedDll.push(a);
          }
        );
      //#endregion

      //#region set Reports Dropdown       
      this.reportsDll = new Array();
      res.filter(f => f.menuType === "REP").map(x => x.parentMenuName).
        filter((parentMenuName, index, arr) => arr.indexOf(parentMenuName) == index).
        sort().forEach
        (
          element => {
            var a = new groupMenuddl();
            a.name = element;
            a.submenuArray = res.filter(f => f.parentMenuName === element);
            this.reportsDll.push(a);
          }
        );
      //#endregion

      //#region Existing Data [Edit scenario] binding for Main
      this.masterMenuModel = res.filter(f => f.menuType === "Main" && f.isAssigned === 1);
      //#endregion

      const checkRoleExistence = roleParam => this.masterMenuModel.some(({ menuName }) => menuName == roleParam)

      if (this.masterMenu.length > 0 && this.masterMenuModel.length > 0 && (checkRoleExistence("Masters") || checkRoleExistence("Reports"))) {
        this.VisibilityControl();

        this.childSelected = checkRoleExistence("Masters") ? res.filter(f => f.menuType === "MST" && f.isAssigned === 1) : this.childSelected;

        this.reportMenuModel = checkRoleExistence("Reports") ? res.filter(f => f.menuType === "REP" && f.isAssigned === 1) : this.reportMenuModel;
      }
    }, err => { });

  }

  // setmenus(value: any) {
  //   if (this.childSelected.filter(item => item.menuCode === value.menuCode).length === 0) {
  //     this.childSelected.push(value);
  //   }
  //   else {
  //     this.childSelected = this.childSelected.filter(item => item.menuCode !== value.menuCode);
  //   }
  // }

  // setrpts(value: any) {
  //   if (this.reportMenuModel.filter(item => item.menuCode === value.menuCode).length === 0) {
  //     this.reportMenuModel.push(value);
  //   }
  //   else {
  //     this.reportMenuModel = this.reportMenuModel.filter(item => item.menuCode !== value.menuCode);
  //   }
  // }

  Save() {
    //this.msgSave = this.masterMenu.toString() + ".............." + this.reportMenuModel.toString() + ".............." + this.childSelected.toString();

    
    var mainParams = this.masterMenuModel.map(x => x.menuCode);
    var masterparams = this.childSelected.map(x => x.menuCode).
    concat(this.childSelected.map(x => x.parentMenuCode).filter((parentMenuCode, index, arr) => arr.indexOf(parentMenuCode) == index));
    var reportSelected = this.reportMenuModel.map(x => x.menuCode).concat(this.reportMenuModel.map(x => x.parentMenuCode).filter((parentMenuCode, index, arr) => arr.indexOf(parentMenuCode) == index));

    if (mainParams.length > 0) {

      if (masterparams.length > 0) {
        mainParams = mainParams.concat(masterparams);
      }

      if (reportSelected.length > 0) {
        mainParams = mainParams.concat(reportSelected);
      }
    }



    //#region Validation Parameter set.
    this.isValidate = false;

    if (this.masterMenu.length > 0 && this.masterMenuModel.length === 0) {
      this.isValidate = true;
    }

    if (this.masterMenuModel.filter(f => f.menuName === "Masters").length > 0 && this.childSelected.length === 0) {
      this.isValidate = true;
    }

    if (this.reportMenuModel.length === 0) {
      this.isValidate = true;
    }

    //#endregion

    if (this.isValidate === false) {
      var request = this.searchRequester.stateElement.stateEle['roleCode_0'] + "|" + mainParams.toString() + "|" + this.shared.userCode;

      this.requestForMenu.siteCode = this.shared.siteCode;

      this.requestForMenu.resCode = "SAVEMENU" + JSON.parse(JSON.stringify(this.searchRequester.ucObj.resCode));

      this.requestForMenu.RequestID = request;
      this.commonService.DataTable(this.requestForMenu).subscribe
        (
          res => {
            this.msgSave = res.message;
          }, err => { }
        );
    }
    else {
      this.msgSave = "";
    }


    // var menuCodes = this.childSelected.map(x => x.menuCode).concat(this.childSelected.map(x => x.parentMenuCode).filter((parentMenuCode, index, arr) => arr.indexOf(parentMenuCode) == index)).sort();
    // var request = this.searchRequester.stateElement.stateEle['roleCode_0'] + "|" + menuCodes + "|" + this.shared.userCode;
    // this.requestForMenu.siteCode = this.shared.siteCode;
    // this.requestForMenu.resCode = "SAVEMENU" + JSON.parse(JSON.stringify(this.searchRequester.ucObj.resCode));
    // this.requestForMenu.RequestID = request;
    // this.commonService.DataTable(this.requestForMenu).subscribe(res => {
    //   this.msgSave = res.message;
    // }, err => { });
  }
  Back() {
    this.router.navigateByUrl('roleEdit', { state: this.searchRequester });
  }

  dashboard()
  {
    if (this.shared.siteUiCode == 'RR') {
      this.router.navigateByUrl('dashboard', { skipLocationChange: true });
    }
    else if (this.shared.siteUiCode == 'HC') {
      this.router.navigateByUrl('dashboardhydrocarbon', { skipLocationChange: true });
    }
    else {
      this.router.navigateByUrl('dashboardretail', { skipLocationChange: true });
    }
  }

  @ViewChild('mySelect', { static: true }) mySelect: MatSelect;
  @ViewChild('allSelected', { static: true }) private allSelected: MatOption;
  searchText: string;
  selectedList: string[];
  toppingSelectedValue: any;
  isSelectDisable: boolean = false;
  isreportDisable: boolean = false;
  ismasterDisable: boolean = false;
  selectedListCount: number = 0;
  noOfColumnInTable: number = 0;
  tdCount: number = 1;
  data: any[] = [
    {
      mstText: 'Extra cheese',
      mstCode: '1'
    },
    {
      mstText: 'Mushroom',
      mstCode: '2'
    },
    {
      mstText: 'Onion',
      mstCode: '3'
    },
    {
      mstText: 'Pepperoni',
      mstCode: '4'
    },
    {
      mstText: 'Sausage',
      mstCode: '5'
    },
    {
      mstText: 'Tomato',
      mstCode: '6'
    },
    {
      mstText: 'potato',
      mstCode: '7'
    },
    {
      mstText: 'Extra butter',
      mstCode: '8'
    },
    {
      mstText: 'pulses',
      mstCode: '9'
    },
    {
      mstText: 'Jalapeno',
      mstCode: '10'
    },
    {
      mstText: 'Pepper',
      mstCode: '11'
    },
    {
      mstText: 'Wedge',
      mstCode: '12'
    },
    {
      mstText: 'Pizza',
      mstCode: '13'
    },
    {
      mstText: 'Pav Bhaji',
      mstCode: '14'
    },
    {
      mstText: 'Burger',
      mstCode: '15'
    },
    {
      mstText: 'Burge1r',
      mstCode: '153'
    },
    {
      mstText: 'Bur2ger',
      mstCode: '154'
    }
  ]

  ngAfterViewInit() {
    this.mySelect.open();
  }
  toppings = new FormControl();

  toppingList: string[] = ['Extra cheese', 'Mushroom', 'Onion', 'Pepperoni', 'Sausage', 'Tomato',
    'potato', 'Extra butter', 'pulses'];

  changeTopping(toppingData) {
    this.selectedList = toppingData;

  }

  selectedCancelElement(data: { menuCode: String; }, target: string) {
    if (target === "menu") {
      this.mySelect.close();
      this.isSelectDisable = true;
      this.masterMenuModel = this.masterMenuModel.filter(f => f.menuCode !== data.menuCode);
      this.VisibilityControl();
    }
    else if (target === "report") {
      this.mySelect.close();
      this.isreportDisable = true;
      this.reportMenuModel = this.reportMenuModel.filter(f => f.menuCode !== data.menuCode);
    }
    else if (target === "master") {
      this.mySelect.close();
      this.ismasterDisable = true;
      this.childSelected = this.childSelected.filter(f => f.menuCode !== data.menuCode);
    }


  }

  // changeClient(data) {
  //   alert("selected --->" + data);
  //   this.mySelect.close();
  // }

  openedChange(data) {
    data = false;
  }
  disableSelectClick(target: string) {
    if (target === "menu") {
      this.isSelectDisable = false;
    }
    else if (target === "report") {
      this.isreportDisable = false;
    }
    else if (target === "master") {
      this.ismasterDisable = false;
    }
  }
  toggleAllSelection() {
    if (this.allSelected.selected) {

    } else {

    }
  }
}




