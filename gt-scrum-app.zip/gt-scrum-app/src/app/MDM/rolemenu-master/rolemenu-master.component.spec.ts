import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RolemenuMasterComponent } from './rolemenu-master.component';

describe('RolemenuMasterComponent', () => {
  let component: RolemenuMasterComponent;
  let fixture: ComponentFixture<RolemenuMasterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RolemenuMasterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RolemenuMasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
