import { Component, OnInit, NgModule } from '@angular/core';
import { SharedState, searchRequester } from 'src/app/Model/Common/InterPage';
import { userRoledetails } from 'src/app/Model/UcModel/roleDetail';
import { requestDetail } from 'src/app/Model/CCModel/requestDetail';
import { UserCreationService } from 'src/app/Services/user-creation.service';
import { Router } from '@angular/router';
import { dropDownDetail } from 'src/app/Model/CcModel/DropDownDetail';
import { FormControl, FormGroup, ReactiveFormsModule, FormsModule } from '@angular/forms';
import { validationTest } from 'src/app/validationTest';
import { MdmService } from 'src/app/Services/mdm.service';
import { isNullOrUndefined } from 'util';
import { mstCollection } from 'src/app/Model/CcModel/mstCollection';
import { mstDetails } from 'src/app/Model/CcModel/MstDetails';

@Component({
  selector: 'app-rolemenu-master',
  templateUrl: './role-master.component.html',
  styleUrls: ['./role-master.component.css']
})
export class RoleMasterComponent implements OnInit {

  //#region Load time Parameters
  breadcrumb: string = "";
  shared: SharedState = new SharedState();
  userName: string = "";
  roleFetchObj: requestDetail = new requestDetail();
  checked: boolean = false;
  //#endregion

  //#region Modification related paramaters
  searchRequester: searchRequester = new searchRequester();
  userRoleDtls: userRoledetails = new userRoledetails();

  //#endregion

  ddlStatus: mstDetails[] = new Array();
  searchStatusText: string = "";
  Status: string = "";
  isStatusDropDownVisible: boolean = false;
  StatusIsDirty: boolean = false;
  isValidate: boolean = false;
  msgSave: string = "";

  validationTest: validationTest = new validationTest();

  constructor(private commonServices: UserCreationService, private mdm: MdmService, private router: Router) { }

  dashboard() {
    if (this.shared.siteUiCode == 'RR') {
      this.router.navigateByUrl('dashboard', { skipLocationChange: true });
    }
    else if (this.shared.siteUiCode == 'HC') {
      this.router.navigateByUrl('dashboardhydrocarbon', { skipLocationChange: true });
    }
    else {
      this.router.navigateByUrl('dashboardretail', { skipLocationChange: true });
    }
  }

  ngOnInit() {

    //#region PreLoad Validate page for correct request

    if (!window.history.state.hasOwnProperty('stateElement')) {
      if (!window.history.state.hasOwnProperty('stateEle')) {
        this.router.navigateByUrl('searchlist', { state: null });
      }
    }
    //#endregion

    //#region get LocalStorage mandatory parameters, State parameters and Set

    this.shared = JSON.parse(atob(localStorage.getItem('shared')));
    this.userName = this.shared.userName;

    this.searchRequester = window.history.state;

    this.searchRequester.stateElement = this.searchRequester.stateElement.hasOwnProperty("stateEle") ?
      this.searchRequester.stateElement.stateEle : this.searchRequester.stateElement;
    // this.searchRequester = window.history.state.hasOwnProperty('stateElement') ? 
    // window.history.state.stateElement.hasOwnProperty('stateEle') ? 
    // window.history.state.stateElement.stateEle : window.history.state :
    // window.history.state;

    //var object = {"stateEle" : stateEle,"roledtls" :roledtls };
    this.breadcrumb = this.searchRequester.stateElement.pageHeader;
    this.userRoleDtls.roleCode = this.searchRequester.stateElement.hasOwnProperty('roleCode_0') ?
      this.searchRequester.stateElement.roleCode_0 : 0;

    this.getStatus(this.shared.siteCode, "2", "COMMON", "0");

    this.roleFetchObj = this.searchRequester.ucObj;

    this.roleFetchObj.RequestID = this.roleFetchObj.RequestID.replace("1|", "2|").
      replace("@STATUS", this.searchRequester.stateElement.status === true ? "1" : "0").
      replace("@SEARCHTEXT", "").replace("@USERCODE", this.shared.userCode).
      replace("@ROLECODE", this.userRoleDtls.roleCode.toString());

    //#endregion

    this.fetch(this.roleFetchObj);

    // //#region Fetch provision
    // if(this.userRoleDtls.roleCode > 0)
    // { 
    //   this.fetch(this.roleFetchObj);
    // }
    // else
    // {
    //   this.clear();
    // }
    // //#endregion
  }

  fetch(fetchRequest: requestDetail) {
    this.mdm.getRoleMasterModel(fetchRequest).subscribe(
      res => {
        if (!isNullOrUndefined(res)) {

          this.userRoleDtls.roleCode = res.code;
          this.userRoleDtls.roleName = res.roleName;
          this.userRoleDtls.roleAbbre = res.roleAbbre;
          this.userRoleDtls.isVendor = res.isVendor;
          this.userRoleDtls.isApprover = res.isApprover;
          this.userRoleDtls.isMapped = res.isMapped;
          this.userRoleDtls.hasInternetAccess = res.hasIntAccess;
          this.userRoleDtls.isActive = res.isActive === true ? 1 : 0;

          this.ddlStatus = res.status.listDetails.filter(f => f.mstcode !== "2");

          if (res.status.listDetails.length > 0) {
            if (res.status.listDetails.filter(f => f.mstcode === "1").length > 0) {
              this.Status = res.status.listDetails.filter(f => f.mstcode === "1")[0].mstText;
            }
          }
          this.setStatus(this.ddlStatus.filter(f => f.mstcode.toString() === this.userRoleDtls.isActive.toString())[0]);
        }
        else {
          this.clear();
        }
      }, err => { });

  }

  isChecked: any = false;

  onChange($event: Event) {
    console.log($event);
    console.log("value changed");

  }

  clear() {
    this.userRoleDtls.roleCode = 0;
    this.userRoleDtls.roleName = "";
    this.userRoleDtls.roleAbbre = "";
    this.userRoleDtls.isVendor = false;
    this.userRoleDtls.isApprover = false;
    this.userRoleDtls.isMapped = false;
    this.userRoleDtls.hasInternetAccess = false;
    this.userRoleDtls.isActive = 0;
  }

  setStatus(data: any) {
    this.userRoleDtls.isActive = data.mstcode;
    this.Status = data.mstText; this.isStatusDropDownVisible = false; this.StatusIsDirty = true;
  }

  StatusDropDownToggle() { this.isStatusDropDownVisible = !this.isStatusDropDownVisible; }

  getStatus(siteCode: string, resCode: string, Entity: string, RefID: string) {
    // this.commonServices.getEntityInfo(siteCode, resCode, Entity, RefID).subscribe
    //   (
    //     res => {
    //       this.ddlStatus = res.filter(f => f.mstcode !== "2");

    //       if (res.length > 0) {
    //         if (res.filter(f => f.mstcode === "1").length > 0) {
    //           this.Status = res.filter(f => f.mstcode === "1")[0].mstText;

    //           this.userRoleDtls.isActive = res.filter(f => f.mstcode === "1")[0].mstcode;
    //         }
    //       }

    //       //#region Fetch provision
    //       if (this.userRoleDtls.roleCode > 0) {
    //         this.fetch(this.roleFetchObj);
    //       }
    //       else {
    //         this.clear();
    //       }
    //       //#endregion
    //     }, err => { }
    //   );
  }

  Save() {
    this.isValidate = this.userRoleDtls.roleName.length > 0 && this.userRoleDtls.roleAbbre.length > 0 ? false : true;

    if (!this.isValidate) {
      let SaveObject = JSON.parse(JSON.stringify(this.roleFetchObj));

      this.userRoleDtls.RequestDetails = SaveObject;

      this.userRoleDtls.createdBy = this.shared.userCode;

      this.userRoleDtls.isActive = Number(this.userRoleDtls.isActive) === 1 ? true : false;

      this.mdm.saveRoleMasterModel(this.userRoleDtls).subscribe(
        res => {
          this.msgSave = res.message;
        }, err => { });
    }
  }

  Back() {
    this.searchRequester.ucObj.RequestID = "1|@SEARCHTEXT|@ROLECODE|@STATUS";
    this.router.navigateByUrl('MstUsers', { state: this.searchRequester });
  }

  ClickEdit(element: any) {
    let stateEle = JSON.parse(JSON.stringify(this.searchRequester.stateElement));
    let roledtls = JSON.parse(JSON.stringify(this.userRoleDtls));

    var object = { "stateEle": stateEle, "roledtls": roledtls };

    this.searchRequester.stateElement = object;
    this.router.navigateByUrl('rolemenuEdit', { state: this.searchRequester });
  }




  CheckboxClick(type: any, forControl: string) {

    this.userRoleDtls.isVendor = forControl === "vendor" ? this.userRoleDtls.isVendor : false;

    this.userRoleDtls.isApprover = forControl === "approver" ? this.userRoleDtls.isApprover : false;

    console.log("vendor :- " + this.userRoleDtls.isVendor.toString());
    console.log("Approver :- " + this.userRoleDtls.isApprover.toString());
    // , data: boolean
    // if(this.userRoleDtls.isVendor && type==="approver" && !data)
    // {
    //   this.userRoleDtls.isVendor = data;
    // }

    // if(this.userRoleDtls.isApprover && type==="vendor" && !data)
    // {
    //   this.userRoleDtls.isApprover = data;
    // }
  }
}
