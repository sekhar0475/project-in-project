import { Component, OnInit, NgModule, ViewChild } from '@angular/core';
import { CreateSiteConfigService } from '../../Services/createSiteConfig.service';
import { dropDownDetail } from '../../Model/CcModel/dropDownDetail';
import { requestDetail } from '../../Model/CCModel/requestDetail';
import { SiteConfig } from '../../Model/MDMModel/siteConfig';
import { when } from 'q';
import { SharedState, searchRequester } from 'src/app/Model/Common/InterPage';
import { FormControl } from '@angular/forms';
import { isNullOrUndefined } from 'util';
import { validationTest } from 'src/app/validationTest';
import { MatSelect, MatOption } from '@angular/material';
import { Router } from '@angular/router';
import { fieldDetail } from 'src/app/Model/CcModel/fieldDetail';
import { mstDetails } from 'src/app/Model/CcModel/MstDetails';
import { MdmService } from 'src/app/Services/mdm.service';
@Component({
  selector: 'app-site-config',
  templateUrl: './site-config.component.html',
  styleUrls: ['./site-config.component.css']
})
export class SiteConfigComponent implements OnInit {

  ddlGroup: mstDetails[];
  ddlStatus: mstDetails[];

  isGroupDropDownVisible: boolean = false;
  isStatusDropDownVisible: boolean = false;

  groupDetailIsDirty: boolean = false;
  statusIsDirty: boolean = false;


  validationTest: validationTest = new validationTest();


  searchStatusText: string;
  userName: string;
  searchGroupText: string;
  searchText: string = "";
  Status: IListDetail = {};
  Groups: IListDetail = {};

  EditDisable : boolean = false;

  statuDetailValue: string = "";
  GroupsDetailValue: string = "";

  msgSave: string = "";

  loading: boolean;
  isValidate: boolean = false;
  RoleRedirect: boolean = false;

  UCObj: requestDetail = new requestDetail();
  SiteConfigdetails: SiteConfig = new SiteConfig();
  shared: SharedState = new SharedState();
  searchRequester: searchRequester = new searchRequester();

  GroupDropDownToggle() {
    this.isGroupDropDownVisible = !this.isGroupDropDownVisible;
  }

  StatusDropDownToggle() {
    this.isStatusDropDownVisible = !this.isStatusDropDownVisible;
  }

  constructor(private _createSiteConfig: MdmService, private router: Router) {

    // this.Clear();
    this.shared = JSON.parse(atob(localStorage.getItem('shared')));
    this.UCObj.RequestID = "VENDORID"; this.UCObj.resCode = "2"; this.UCObj.siteCode = "1";
    // this.getStatus(this.shared.siteCode, this.UCObj.resCode, "COMMON", "0");
    
    //#region PreLoad Validate page for correct request
    if (!window.history.state.hasOwnProperty('stateElement')) {
      this.router.navigateByUrl('searchlist', { state: null });
    }
    //#endregion

    this.SiteConfigdetails = window.history.state;
    this.UCObj.siteCode = window.history.state.ucObj.siteCode;
    // this.Init();
  }

  ngOnInit() {

    

    this.userName = this.shared.userName;
    this.searchRequester = window.history.state;

    this.SiteConfigdetails.code = this.searchRequester.stateElement.hasOwnProperty('code_0') ? this.searchRequester.stateElement.code_0 : 0;
    this.getSiteConfiguration(this.shared.siteCode, "SCode", this.SiteConfigdetails.code.toString());
    this.EditDisable =this.SiteConfigdetails.code  > 0 ? true : false;
  }


  getSiteConfiguration(siteCode: string, type: string, Code: string) {
    this._createSiteConfig.getSiteConfiguration(siteCode, type, Code).subscribe(
      res => {

        this.SiteConfigdetails = res;
        this.Status = this.SiteConfigdetails.isActive;
        this.Groups = this.SiteConfigdetails.groupCode;

        this.SiteConfigdetails.isActive.listDetails = this.SiteConfigdetails.isActive.listDetails.filter(f => f.mstcode !== "2");


        if (this.SiteConfigdetails.isActive.fieldDetail.value != null) {
          try {

            this.statuDetailValue = this.SiteConfigdetails.isActive.listDetails.filter(f => f.mstcode == (this, this.SiteConfigdetails.code > 0 ? this.SiteConfigdetails.isActive.fieldDetail.value : "1"))[0].mstText;
            this.SiteConfigdetails.isActive.fieldDetail.value = this.SiteConfigdetails.isActive.fieldDetail.value;
            this.statusIsDirty = true;
          }
          catch
          {

          }
        }

        if (this.SiteConfigdetails.groupCode.fieldDetail.value != null) {
          try {
            this.GroupsDetailValue = this.SiteConfigdetails.groupCode.listDetails.filter(f => f.mstcode == this.SiteConfigdetails.groupCode.fieldDetail.value)[0].mstText;
            this.SiteConfigdetails.groupCode.fieldDetail.value = this.SiteConfigdetails.groupCode.fieldDetail.value;
            this.groupDetailIsDirty = true;
          }
          catch
          {

          }
        }


      }
    )
  }






  // getGroup(siteCode: string, resCode: string, entity: string, RefID: string) {

  //   this._createSiteConfig.getGroup(siteCode, resCode, entity, RefID).then((res) => {
  //     this.ddlGroup = res[0].listDetails;
  //   }, err => { }
  //   )
  // }


  // getStatus(siteCode: string, resCode: string, Entity: string, RefID: string) {
  //   this._createSiteConfig.getEntityInfo(siteCode, resCode, Entity, RefID).then((res) => {
  //     this.ddlStatus = res.filter(f => f.mstCode !== "2");
  //     if (res.length > 0) {
  //       if (res.filter(f => f.mstcode === "1").length > 0) {
  //         this.Status = res.filter(f => f.mstcode === "1")[0].mstText;
  //       }
  //     }

  //   }, err => { }
  //   )
  // }


  // Init() {
  //   this.loading = true;

  //   this._createSiteConfig.getGroup(this.UCObj.siteCode, this.UCObj.resCode, "SCGCV", "0").then((res) => {
  //     this.ddlGroup = res[0].listDetails;
  //     this.loading = false;
  //     return;
  //   }, err => {
  //   }
  //   )


  // }



  setGroup(data: any) {
    this.GroupsDetailValue = data.mstText;
    this.SiteConfigdetails.groupCode.fieldDetail.value = data.mstcode;
    this.isGroupDropDownVisible = false;
    this.groupDetailIsDirty = true;
  }


  setStatus(data: any) {
    this.statuDetailValue = data.mstText;
    this.SiteConfigdetails.isActive.fieldDetail.value = data.mstcode;
    this.isStatusDropDownVisible = false;
    this.statusIsDirty = true;
  }



  Save() {


    this.Validate();

    if (this.isValidate === false) {
      this.shared = JSON.parse(atob(localStorage.getItem('shared')));
      this.UCObj.resCode = "2"; this.UCObj.siteCode = this.shared.siteCode;
      this.SiteConfigdetails.RequestDetails = this.UCObj;
      this._createSiteConfig.saveSiteConfig(this.SiteConfigdetails).subscribe(
        res => {
          this.SiteConfigdetails.code = parseInt(res.status);
          this.msgSave = res.message;
          setTimeout(() => { this.msgSave = ""; }, 10000);
          if (res.code == 0) { this.RoleRedirect = true; } else { this.RoleRedirect = false; }
        },
        err => {

        }
      )
    }

  }
  Clear() {

    this.SiteConfigdetails.shortCode = "";
    this.SiteConfigdetails.configDesc = "";
    this.SiteConfigdetails.s_Value = "";
    this.SiteConfigdetails.d_Value = "";

  }

  Back() {
    this.Clear();
    this.searchRequester.stateElement = this.SiteConfigdetails;
    // this.searchRequester.ucObj.RequestID =  "1|@SEARCHTEXT|@USERCODE|@ROLECODE|@STATUS";
    this.router.navigateByUrl('MstSite', { state: this.searchRequester });
  }

  Validate() {
    this.isValidate = this.validationTest.requiredValidatorByString(this.SiteConfigdetails.d_Value).length > 0 ? true : this.isValidate;
    this.isValidate = this.validationTest.requiredValidatorByString(this.SiteConfigdetails.s_Value).length > 0 ? true : this.isValidate;
    this.isValidate = this.validationTest.requiredValidatorByString(this.SiteConfigdetails.configDesc).length > 0 ? true : this.isValidate;
    this.isValidate = this.validationTest.requiredValidatorByString(this.SiteConfigdetails.shortCode).length > 0 ? true : this.isValidate;



  }
}
interface IListDetail {
  listDetails?: any[];
  fieldDetail?: any;
}