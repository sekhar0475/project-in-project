import { Component, OnInit, NgModule, ViewChild } from '@angular/core';
import { FormControl } from '@angular/forms';
import { UserCreationService } from '../../Services/user-creation.service';
import { requestDetail } from '../../Model/CCModel/requestDetail';
import { userRoledetails, userRoleCreation, SaveRoles } from '../../Model/UcModel/roleDetail';
import { isNullOrUndefined } from 'util';
import { UserCreation } from 'src/app/Model/MDMModel/user-creation';
import { Router } from '@angular/router';
import { validationTest } from 'src/app/validationTest';
import { SharedState, searchRequester } from 'src/app/Model/Common/InterPage';
import { MatSelect, MatOption } from '@angular/material';
import { dropDownDetail } from '../../Model/CcModel/dropDownDetail';
import { BrowserModule } from '@angular/platform-browser';
import { Observable } from 'rxjs';
import { stringify } from 'querystring';
import { FormGroup, ReactiveFormsModule, FormsModule } from '@angular/forms';
import { NgSelectModule, NgOption } from '@ng-select/ng-select';
import { isDefined } from '@angular/compiler/src/util';
import { MdmService } from 'src/app/Services/mdm.service';
import { mstCollection } from 'src/app/Model/CcModel/mstCollection';
import { isNull } from '@angular/compiler/src/output/output_ast';


@Component({
  selector: 'app-user-roles',
  templateUrl: './user-roles.component.html',
  styleUrls: ['./user-roles.component.css']
})

export class UserRolesComponent implements OnInit {
  @ViewChild('mySelect', { static: true }) mySelect: MatSelect;
  @ViewChild('allSelected', { static: true }) private allSelected: MatOption;
  searchText: string;
  selectedList: string[];
  toppingSelectedValue: any;

  isSelectDisable: boolean = false;
  isSelectDisableeic: boolean = false;
  toppings = new FormControl();
  toppingstate = new FormControl();
  toppingarea = new FormControl();
  toppingseic = new FormControl();
  toppingseicd = new FormControl();
  isEIC: boolean = false;
  isEICD: boolean = false;
  isGROUP: boolean = false;
  isREGION: boolean = false;
  isSTATE: boolean = false;

  selectedListCount: number = 0;
  noOfColumnInTable: number = 0;
  tdCount: number = 1;
  data: any[] = [
    {
      mstText: 'Extra cheese',
      mstCode: '1'
    },
    {
      mstText: 'Mushroom',
      mstCode: '2'
    },
    {
      mstText: 'Onion',
      mstCode: '3'
    },
    {
      mstText: 'Pepperoni',
      mstCode: '4'
    },
    {
      mstText: 'Sausage',
      mstCode: '5'
    },
    {
      mstText: 'Tomato',
      mstCode: '6'
    },
    {
      mstText: 'potato',
      mstCode: '7'
    },
    {
      mstText: 'Extra butter',
      mstCode: '8'
    },
    {
      mstText: 'pulses',
      mstCode: '9'
    },
    {
      mstText: 'Jalapeno',
      mstCode: '10'
    },
    {
      mstText: 'Pepper',
      mstCode: '11'
    },
    {
      mstText: 'Wedge',
      mstCode: '12'
    },
    {
      mstText: 'Pizza',
      mstCode: '13'
    },
    {
      mstText: 'Pav Bhaji',
      mstCode: '14'
    },
    {
      mstText: 'Burger',
      mstCode: '15'
    },
    {
      mstText: 'Burge1r',
      mstCode: '153'
    },
    {
      mstText: 'Bur2ger',
      mstCode: '154'
    }
  ]

  //#region parameters
  UCObj: requestDetail = new requestDetail();
  UCObj1: requestDetail = new requestDetail();

  userRoleDetails: userRoleCreation = new userRoleCreation();

  DomainID: string = "";
  EditUserName: string = "";
  SaveRoleDetails: SaveRoles = new SaveRoles();

  lblEIC: string = "";
  lblEICD: string = "";
  lblGRP: string = "";
  lblMGR: string = "";
  lblRHR: string = "";
  lblSHR: string = "";
  EICDFrom: string = "";
  EICDTo: string = "";

  validationTest: validationTest = new validationTest();

  isValidate: boolean = false;

  UserRoles: userRoledetails[];
  EICRoles: userRoledetails[];
  EICDRoles: userRoledetails[];
  GRPRoles: userRoledetails[];
  GRPRolesddl: userRoledetails[];

  MGRRoles: userRoledetails[];
  RHRRoles: userRoledetails[];
  SHRRoles: userRoledetails[];
  AHRRoles: userRoledetails[];


  container: userRoledetails[];
  IsEICSelected: boolean = false;
  IsEICDSelected: boolean = false;
  IsGRPSelected: boolean = false;
  IsSHRSelected: boolean = false;
  IsAHRSelected: boolean = false;
  IsMGRSelected: boolean = false;
  IsRHRSelected: boolean = false;
  UserDetails: UserCreation = new UserCreation();
  msgSave: string = "";
  msgSave1: string = "";
  shared: SharedState = new SharedState();
  userName: string;
  showDates: boolean = false;
  delegateDates: string[] = ["SCRM", "EICD"]
  delegateCodeEICD: string = "0";
  delegateCodeSCRM: string = "0";

  currentDate: Date;
  dateFormControl = new FormControl(new Date())
  dateFormControl1 = new FormControl(new Date())
  searchRequester: searchRequester = new searchRequester();

  //#endregion

  JCCodes: mstCollection = new mstCollection();
  JC1Codes: mstCollection = new mstCollection();
  JC1Descriptions: any;

  constructor(private ucs: UserCreationService, private mdm: MdmService, private router: Router) {   //this.data.mstText="";
    this.selectedListCount = this.data.length;
    this.noOfColumnInTable = this.selectedListCount / 3;
  }

  ngOnInit() {

    //#region PreLoad Validate page for correct request
    if (!window.history.state.hasOwnProperty('stateElement')) {
      this.router.navigateByUrl('searchlist', { state: null });
    }
    //#endregion

    this.shared = JSON.parse(atob(localStorage.getItem('shared')));

    this.userName = this.shared.userName;

    //this.searchRequester = JSON.parse('{"pageHeader":"User Master","navigateNext":"userEdit","stateElement":{"Code":1,"loginID":"rakesh.parab","userName":"Rakesh Parab","userID":"P37100250","pwd":"","mobileNo":"9833499935","eMailID":"Rakesh.Parab@ril.com","reportingID":"P10035101","reportingLoginID":"Ashish.Jadhav","reportingName":"Ashish Jadhav","reportingEmailID":"Ashish.Jadhav@ril.com","IsVendor":0,"IsABVS":0,"ContractorCode":0,"IsActive":true,"CreatedBy":"0","UserStatus":true,"IsLocked":0},"ucObj":{"siteCode":1,"roleCode":"","resCode":"GRP9USERLIST","RequestID":"1|@SEARCHTEXT|@USERCODE|@ROLECODE|@STATUS","requestIndex":0},"navigationId":7}'); // window.history.state;
    this.searchRequester = window.history.state;

    this.UserDetails = this.searchRequester.stateElement; this.UCObj.siteCode = this.shared.siteCode;

    this.DomainID = this.UserDetails.loginID; this.EditUserName = this.UserDetails.userName;

    if (this.UserDetails.Code > 0) {
      this.UCObj.resCode = "1"; this.UCObj.RequestID = "1|" + this.UserDetails.Code + "|" + this.shared.roleCode + "|0";
      this.getAndSetRoles(this.UCObj);

    }
    else {
      this.msgSave1 = "User details not found!! Invalid routing..";
    }
  }

  childSelected: userRoledetails[] = new Array();
  childAreaSelected: userRoledetails[] = new Array();
  groupedDll: groupStateddl[] = new Array;
  groupAreaDll: groupAreaddl[] = new Array;
  //#region Dropdown Loads
  getAndSetRoles(request: requestDetail) {
    this.mdm.DataSet(request).subscribe(
      res => {
        this.UserRoles = res.table; this.EICRoles = res.table1; this.EICDRoles = res.table2;
        this.GRPRolesddl = res.table3; this.MGRRoles = res.table4; this.RHRRoles = res.table5;
        this.SHRRoles = res.table6; this.AHRRoles = res.table7;


        //#region Set Group Admin Dropdown for Edit. 
        var grpvalue = this.GRPRolesddl.find(f => f.isAssigned === 1);
        if (!isNullOrUndefined(grpvalue)) {
          this.groupCode = grpvalue.mstCode.toString();
          this.groupText = grpvalue.mstName;
          this.groupVisible = false;
          this.getGroupDetails(grpvalue.mstCode);
        }

        //#endregion

        //#region set Masters Dropdown 
        this.groupedDll = new Array();
        res.table6.map(x => x.groupName).
          filter((groupName, index, arr) => arr.indexOf(groupName) == index).
          sort().forEach
          (
            element => {
              var a = new groupStateddl();
              a.name = element; a.submenuArray = res.table6.filter(f => f.groupName === element);
              this.groupedDll.push(a);
            }
          );

        var res7 = res.table7.filter(f => res.table6.filter(f => f.isAssigned === 1).map(x => x.mstCode).includes(f.mstCode));
        this.groupAreaDll = new Array();
        res7.map(x => x.groupName).
          filter((groupName, index, arr) => arr.indexOf(groupName) == index).
          sort().forEach
          (
            element => {
              var a = new groupAreaddl();
              a.name = element; a.submenuArray = res7.filter(f => f.groupName === element);
              this.groupAreaDll.push(a);
            }
          );

        //#endregion

        this.userRoleDetails.selectedRoles = this.UserRoles.filter(f => f.roleAssigned === 1); //.map(function(a) {return a;});

        //checked
        this.userRoleDetails.EICRoles = this.EICRoles.filter(f => f.isAssigned === 1);

        this.userRoleDetails.EICDRoles = this.EICDRoles.filter(f => f.isAssigned === 1);
        //this.userRoleDetails.GroupAdminRoles = this.GRPRoles.filter(f => f.isAssigned === 1);
        this.userRoleDetails.RHRRoles = this.RHRRoles.filter(f => f.isAssigned === 1);
        this.userRoleDetails.SHRRoles = this.SHRRoles.filter(f => f.isAssigned === 1);
        this.userRoleDetails.AHRRoles = this.AHRRoles.filter(f => f.isAssigned === 1 && this.userRoleDetails.SHRRoles.map(x => x.mstName).includes(f.groupName));

        this.userRoleDetails.MGRRoles = this.MGRRoles.filter(f => f.isAssigned === 1);

        var request = JSON.parse(JSON.stringify(this.UCObj));
        request.RequestID = "LOCDET|1||||||0||1"; request.resCode = "JioLocations";
        this.mdm.DataTable(request).subscribe(
          res => {
            this.JC1Descriptions = res;
            this.userRoleDetails.MGRRoles.forEach(value => {
              var obj = this.JC1Descriptions.find(f => f.code.toString() === value.mstCode.toString());
              if (!isNullOrUndefined(obj)) {
                value.mstName = obj.stateName + "-" + obj.areaName + "-" + obj.mpName + "-" + obj.jcName + "-" +
                  obj.jcShortCode + "-" + obj.jcOfficeID;
              }
            });
          }, err => { });



        this.lblEIC = this.UserRoles.filter(f => f.roleAbbre === "EIC").map(function (a) { return a.roleName; }) + " to Department Mapping";
        this.lblEICD = this.UserRoles.filter(f => f.roleAbbre === "EICD").map(function (a) { return a.roleName; }) + " to Department Mapping";
        this.lblGRP = this.UserRoles.filter(f => f.roleAbbre === "GRP").map(function (a) { return a.roleName; }) + " to Trade/Role Mapping";
        this.lblRHR = this.UserRoles.filter(f => f.roleAbbre === "RHR").map(function (a) { return a.roleName; }) + " to Region (E/W/N/S) Mapping";
        this.lblSHR = this.UserRoles.filter(f => f.roleAbbre === "SHR").map(function (a) { return a.roleName; }) + " to State Mapping";
        this.lblMGR = this.UserRoles.filter(f => f.roleAbbre === "MGR").map(function (a) { return a.roleName; }) + " to JC Mapping";

        this.setRoles("ALL");

        if (this.UserDetails.Code > 0) {
          this.FetchDate("EICD");
          this.FetchDate("SCRM");
        }
        console.log(this.userRoleDetails.EICRoles);
      }, err => { });
  }

  StateSelected(data: any) {


    //var res7 = this.AHRRoles.filter(f => this.userRoleDetails.SHRRoles.map(x => x.mstCode).includes(f.mstCode));
    var res7 = this.AHRRoles.filter(f => this.userRoleDetails.SHRRoles.map(x => x.mstName).includes(f.groupName));
    this.groupAreaDll = new Array();
    res7.map(x => x.groupName).
      filter((groupName, index, arr) => arr.indexOf(groupName) == index).
      sort().forEach
      (
        element => {
          var a = new groupAreaddl();
          a.name = element; a.submenuArray = res7.filter(f => f.groupName === element);
          this.groupAreaDll.push(a);
        }
      );
  }
  searchText1: string = "";
  isJCDropDownVisible: boolean = false;
  StatusDropDownToggle() {
    this.isJCDropDownVisible = !this.isJCDropDownVisible;
  }

  isJC1DropDownVisible: boolean = false;
  StatusDropDownToggle1() {
    this.isJC1DropDownVisible = !this.isJC1DropDownVisible;
  }

  getJioLocations(LocationCode: string) {
    this.ucs.getEntityInfo(this.shared.siteCode, "2", "JioLocationSearch", LocationCode).subscribe(
      res => {
        var result = res[0];
        this.JC1Codes = res[0];
        console.log(result.listDetails);
      }, err => { });
  }
  setJC(data: any) {
    this.JCCodes.fieldDetail.value = data.mstText;
    this.isJCDropDownVisible = false;
    this.getJioLocations(data.mstcode);
  }

  setJC1(data: any) {
    //
    if (this.userRoleDetails.MGRRoles.filter(f => f.mstCode.toString() === data.mstcode).length === 0) {

      var obj = this.JC1Descriptions.find(f => f.code.toString() === data.mstcode);
      if (!isNullOrUndefined(obj)) {
        obj.mstCode = obj.code; obj.mstName = obj.stateName + "-" + obj.areaName + "-" + obj.mpName + "-" + obj.jcName + "-" +
          obj.jcShortCode + "-" + obj.jcOfficeID;
        this.userRoleDetails.MGRRoles.push(obj);
      }

      // var request = JSON.parse(JSON.stringify(this.UCObj));
      // request.RequestID = "LOCDET|1||||||" + data.mstcode + "||1"; request.resCode = "JioLocations";
      // this.mdm.DataTable(request).subscribe(
      //   res => {
      //     var pushData = new userRoledetails();

      //     pushData.mstCode = data.mstcode; pushData.mstName = data.mstText;
      //     this.userRoleDetails.MGRRoles.push(pushData);
      //   }, err => { });
    }

    this.JC1Codes.fieldDetail.value = data.mstText;
    this.isJC1DropDownVisible = !this.isJC1DropDownVisible;
    //this.getJioLocations(data.mstcode);
  }

  RemoveForJC1(data: any) {
    this.userRoleDetails.MGRRoles = this.userRoleDetails.MGRRoles.filter(f => f.mstCode !== data.mstCode);
  }


  setRoles(value: string) {

    this.IsEICSelected = isNullOrUndefined(this.userRoleDetails.selectedRoles.find(f => f.roleAbbre === "EIC")) === false ? true : false;
    this.IsEICDSelected = isNullOrUndefined(this.userRoleDetails.selectedRoles.find(f => f.roleAbbre === "EICD")) === false ? true : false;
    this.IsGRPSelected = this.userRoleDetails.selectedRoles.filter(f => f.roleAbbre === "GRP").length > 0 ? true : false;
    this.IsRHRSelected = isNullOrUndefined(this.userRoleDetails.selectedRoles.find(f => f.roleAbbre === "RHR")) === false ? true : false;
    this.IsSHRSelected = isNullOrUndefined(this.userRoleDetails.selectedRoles.find(f => f.roleAbbre === "SHR")) === false ? true : false;
    this.IsAHRSelected = isNullOrUndefined(this.userRoleDetails.selectedRoles.find(f => f.roleAbbre === "AHR")) === false ? true : false;

    this.IsMGRSelected = isNullOrUndefined(this.userRoleDetails.selectedRoles.find(f => f.roleAbbre === "MGR")) === false ? true : false;

    if (value === "ALL" && !this.IsEICSelected) { this.userRoleDetails.EICRoles = new Array; }
    if (value === "ALL" && !this.IsEICDSelected) { this.userRoleDetails.EICDRoles = new Array; }
    if (value === "ALL" && !this.IsGRPSelected) { this.userRoleDetails.GroupAdminRoles = new Array; }
    if (value === "ALL" && !this.IsGRPSelected) { this.userRoleDetails.RHRRoles = new Array; }
    if (value === "ALL" && !this.IsSHRSelected) { this.userRoleDetails.SHRRoles = new Array; }
    if (value === "ALL" && !this.IsAHRSelected) { this.userRoleDetails.AHRRoles = new Array; }

    if (this.userRoleDetails.selectedRoles.filter(f => f.roleAbbre === "SCRM" || f.roleAbbre === "EICD").length > 0) {
      this.showDates = true;
    } else { this.showDates = false; }


    if (this.IsMGRSelected === true) {
      this.ucs.getEntityInfo(this.shared.siteCode, "2", "LocType", "0").subscribe(
        res => {
          var result = res;
          this.JCCodes = result[0];
          this.JCCodes.fieldDetail.value = result[0].listDetails.find(f => f.mstcode === "0").mstText;
          this.getJioLocations("0");
        }, err => { });
    }


    // if (value === "EIC" || value === "ALL") {
    //   this.IsEICSelected = isNullOrUndefined(this.userRoleDetails.selectedRoles.find(f => f.roleAbbre === "EIC")) === false ? true : false;
    // }
    // if (value === "EICD" || value === "ALL") {
    //   this.IsEICDSelected = isNullOrUndefined(this.userRoleDetails.selectedRoles.find(f => f.roleAbbre === "EICD")) === false ? true : false;
    // }
    // if (this.userRoleDetails.selectedRoles.filter(f => f.roleAbbre === "SCRM" || f.roleAbbre === "EICD").length > 0) { this.showDates = true; }
    // else { this.showDates = false; }
    //if (value === "GRP" || value === "ALL") { this.IsGRPSelected = this.userRoleDetails.selectedRoles.filter(f => f.roleAbbre === "GRP").length > 0 ? true : false; }
    //if (value === "RHR" || value === "ALL") { this.IsRHRSelected = isNullOrUndefined(this.userRoleDetails.selectedRoles.find(f => f.roleAbbre === "RHR")) === false ? true : false; }
    // if (value === "SHR" || value === "ALL") { this.IsSHRSelected = isNullOrUndefined(this.userRoleDetails.selectedRoles.find(f => f.roleAbbre === "SHR")) === false ? true : false; }
    // if (value === "AHR" || value === "ALL") { this.IsAHRSelected = isNullOrUndefined(this.userRoleDetails.selectedRoles.find(f => f.roleAbbre === "AHR")) === false ? true : false; }
  }

  getUserRoles(request: requestDetail) {
    this.ucs.DataTable(request).subscribe(
      res => {
        var result = res.table.map(function (a) { return a.roleCode; });
        this.userRoleDetails.selectedRoles = this.UserRoles.filter(f => result.includes(f.roleCode));
        this.setRoles("ALL");
      }, err => { });
  }
  //#endregion

  setValidate(): boolean {
    this.isValidate = false;

    this.isValidate = this.validationTest.requiredValidatorByString(this.userRoleDetails.selectedRoles.length > 0 ? '1' : '').length > 0 ? true : false;

    if (this.isValidate === false && this.userRoleDetails.selectedRoles.filter(f => f.roleAbbre === "EIC").length > 0) {
      this.isValidate = this.validationTest.requiredValidatorByString(this.userRoleDetails.selectedRoles.length > 0 &&
        this.userRoleDetails.EICRoles.length > 0 ? '1' : '').length > 0 ? true : this.isValidate;
    }

    if (this.isValidate === false && this.userRoleDetails.selectedRoles.filter(f => f.roleAbbre === "EICD").length > 0) {
      this.isValidate = this.validationTest.requiredValidatorByString(this.userRoleDetails.selectedRoles.length > 0 &&
        this.userRoleDetails.EICDRoles.length > 0 ? '1' : '').length > 0 ? true :
        this.validationTest.requiredValidatorByString(this.userRoleDetails.EICDFrom).length > 0 ? true :
          this.validationTest.requiredValidatorByString(this.userRoleDetails.EICDTo).length > 0 ? true :
            this.isValidate;
    }

    if (this.isValidate === false && this.userRoleDetails.selectedRoles.filter(f => f.roleAbbre === "GRP").length > 0) {
      this.isValidate = this.validationTest.requiredValidatorByString(this.userRoleDetails.selectedRoles.length > 0 &&
        this.userRoleDetails.GroupAdminRoles.length > 0 ? '1' : '').length > 0 ? true : this.isValidate;
    }

    if (this.isValidate === false && this.userRoleDetails.selectedRoles.filter(f => f.roleAbbre === "RHR").length > 0) {
      this.isValidate = this.validationTest.requiredValidatorByString(this.userRoleDetails.selectedRoles.length > 0 &&
        this.userRoleDetails.RHRRoles.length > 0 ? '1' : '').length > 0 ? true : this.isValidate;
    }

    if (this.isValidate === false && this.userRoleDetails.selectedRoles.filter(f => f.roleAbbre === "SHR").length > 0) {
      this.isValidate = this.validationTest.requiredValidatorByString(this.userRoleDetails.selectedRoles.length > 0 &&
        this.userRoleDetails.SHRRoles.length > 0 ? '1' : '').length > 0 ? true : this.isValidate;
    }

    if (this.isValidate === false && this.userRoleDetails.selectedRoles.filter(f => f.roleAbbre === "AHR").length > 0) {
      this.isValidate = this.validationTest.requiredValidatorByString(this.userRoleDetails.selectedRoles.length > 0 &&
        this.userRoleDetails.AHRRoles.length > 0 ? '1' : '').length > 0 ? true : this.isValidate;
    }

    return this.isValidate;
  }

  retString(val: number): number {
    return this.userRoleDetails.selectedRoles.filter
      (
        f => f.roleAbbre ===
          (
            val === 0 ?
              "EIC" :
              val === 1 ?
                "GRP" :
                val === 2 ?
                  "RHR" :
                  val === 3 ?
                    "SHR" :
                    val === 4 ? "EICD" :
                      val === 5 ? "AHR" : "")
      ).length;
  }

  //#region Save
  Save() {
    this.msgSave = "";
    this.msgSave1 = "";
    console.log(this.userRoleDetails.selectedRoles.filter(f => this.delegateDates.includes(f.roleAbbre)).length > 0);

    if (this.setValidate() === false) {
      this.SaveRoleDetails = new SaveRoles();

      this.SaveRoleDetails.requestDetail = this.UCObj;

      this.SaveRoleDetails.Code = this.UserDetails.Code;

      this.SaveRoleDetails.requestDetail = this.UCObj;

      if (this.userRoleDetails.selectedRoles.length > 0) {
        this.SaveRoleDetails.RolesCollection.push({ listName: "USERROLE", role: this.userRoleDetails.selectedRoles });
      }

      if (this.userRoleDetails.EICRoles.length > 0) {
        this.SaveRoleDetails.RolesCollection.push({ listName: "EIC", role: this.userRoleDetails.EICRoles });
      }

      if (this.userRoleDetails.EICDRoles.length > 0) {
        this.SaveRoleDetails.RolesCollection.push({ listName: "EICD", role: this.userRoleDetails.EICDRoles });
      }

      if (this.IsGRPSelected) {
        this.SaveRoleDetails.GroupCode = parseInt(this.groupCode);
        this.SaveRoleDetails.RolesCollection.push({ listName: "GROUPADMIN", role: this.userRoleDetails.GroupAdminRoles });
      }
      else {
        this.SaveRoleDetails.GroupCode = 0;
      }

      if (this.userRoleDetails.SHRRoles.length > 0) {
        this.SaveRoleDetails.RolesCollection.push({ listName: "SHR", role: this.userRoleDetails.SHRRoles });
      }

      if (this.userRoleDetails.RHRRoles.length > 0) {
        this.SaveRoleDetails.RolesCollection.push({ listName: "RHR", role: this.userRoleDetails.RHRRoles });
      }

      if (this.userRoleDetails.AHRRoles.length > 0) {
        this.SaveRoleDetails.RolesCollection.push({ listName: "AHR", role: this.userRoleDetails.AHRRoles });
      }

      if (this.userRoleDetails.MGRRoles.length > 0) {
        this.SaveRoleDetails.RolesCollection.push({ listName: "MGR", role: this.userRoleDetails.MGRRoles });
      }

      this.SaveService(this.SaveRoleDetails);
    }

  }

  SaveService(saveRoles: SaveRoles) {
    this.mdm.SaveRoles(saveRoles).subscribe(
      res => {
        if (res.code === "0") {
          this.msgSave = res.message;
          let dfrom = new Date(this.userRoleDetails.EICDFrom); dfrom.setDate(dfrom.getDate() + 1);
          let dto = new Date(this.userRoleDetails.EICDTo); dto.setDate(dto.getDate() + 1);

          if (this.userRoleDetails.selectedRoles.filter(f => f.roleAbbre === "EICD").length > 0) {
            this.UCObj.siteCode = this.shared.siteCode;
            this.UCObj.resCode = "8";
            this.UCObj.RequestID = this.delegateCodeEICD + "|" + this.UserDetails.Code + "|" +
              this.userRoleDetails.selectedRoles.filter(f => f.roleAbbre === "EICD")[0].roleCode + "|" +
              dfrom.toISOString().slice(0, 10) + "|" + dto.toISOString().slice(0, 10) + "|1|" + this.shared.userCode;

            this.ucs.DataTable(this.UCObj).subscribe(
              res => {
                if (this.userRoleDetails.selectedRoles.filter(f => f.roleAbbre === "SCRM").length > 0) {
                  this.ucs.DataTable(this.UCObj1).subscribe
                    (
                      res => {
                      }, err => { }
                    );
                }
              }, err => { });
          }
          else {
            if (this.userRoleDetails.selectedRoles.filter(f => f.roleAbbre === "SCRM").length > 0) {
              this.UCObj1.siteCode = this.shared.siteCode;
              this.UCObj1.resCode = "8";
              this.UCObj1.RequestID = this.delegateCodeSCRM + "|" + this.UserDetails.Code + "|" +
                this.userRoleDetails.selectedRoles.filter(f => f.roleAbbre === "SCRM")[0].roleCode + "|" +
                dfrom.toISOString().slice(0, 10) + "|" + dto.toISOString().slice(0, 10) + "|1|" + this.shared.userCode;

              this.ucs.DataTable(this.UCObj1).subscribe(
                res => {
                }, err => { });
            }
          }
        }
        else {
          this.msgSave1 = res.message;
          this.validations = this.msgSave1.split("~",100);
          this.validations.pop();

        }

      },
      err => { });
  }

  validations: string[];

  FetchDate(val: string) {
    var data = this.UserRoles.filter(f => f.roleAbbre === val);

    if (data.length > 0) {
      this.UCObj.siteCode = this.shared.siteCode; this.UCObj.resCode = "9";
      this.UCObj.RequestID = this.UserDetails.Code + "|" + data[0].roleCode;

      this.ucs.DataTable(this.UCObj).subscribe(
        res => {
          if (val === "EICD" && res[0].hasOwnProperty('code')) {
            this.delegateCodeEICD = res[0].code;
          } else if (val === "SCRM" && res[0].hasOwnProperty('code')) {
            this.delegateCodeSCRM = res[0].code;
          }

          if (this.userRoleDetails.EICDFrom.length <= 0) {
            if (res[0].hasOwnProperty('delegateStartDt')) {

              this.userRoleDetails.EICDFrom = new Date(new Date(res[0].delegateStartDt)).toLocaleDateString();



              this.currentDate = new Date(new Date(res[0].delegateStartDt));

              this.dateFormControl.setValue(this.currentDate);
            }
          }

          if (this.userRoleDetails.EICDTo.length <= 0) {
            if (res[0].hasOwnProperty('delegateEndDt')) {
              this.userRoleDetails.EICDTo = new Date(new Date(res[0].delegateEndDt)).toLocaleDateString();

              this.currentDate = new Date(new Date(res[0].delegateEndDt));

              this.dateFormControl1.setValue(this.currentDate);
            }
          }
        }, err => { });;


    }
  }

  //#endregion

  Back() {
    this.router.navigateByUrl('userEdit', { state: this.searchRequester });
  }

  dashboard() {
    if (this.shared.siteUiCode == 'RR') {
      this.router.navigateByUrl('dashboard', { skipLocationChange: true });
    }
    else if (this.shared.siteUiCode == 'HC') {
      this.router.navigateByUrl('dashboardhydrocarbon', { skipLocationChange: true });
    }
    else {
      this.router.navigateByUrl('dashboardretail', { skipLocationChange: true });
    }
  }

  ngAfterViewInit() {
    this.mySelect.open();
  }

  changeTopping(toppingData) {
    this.userRoleDetails.selectedRoles = toppingData;
  }


  changeToppingeic(toppingData) {
    this.userRoleDetails.EICRoles = toppingData;
  }

  changeToppingeicd(toppingData) {
    this.userRoleDetails.EICDRoles = toppingData;
  }

  selectedCancelElement(data) {
    this.isSelectDisable = true;
    this.userRoleDetails.selectedRoles = this.userRoleDetails.selectedRoles.filter(f => f.roleCode !== data.roleCode);
    this.setRoles("ALL");
  }

  selectedCancelElementeic(data) {
    this.isEIC = true;
    //this.isSelectDisableeic = true;
    this.userRoleDetails.EICRoles = this.userRoleDetails.EICRoles.filter(f => f.mstCode !== data.mstCode);
  }

  selectedCancelElementeicd(data) {
    this.isEICD = true;
    //this.isSelectDisableeic = true;
    this.userRoleDetails.EICDRoles = this.userRoleDetails.EICDRoles.filter(f => f.mstCode !== data.mstCode);
  }

  openedChange(data) {
    data = false;
  }

  openedChangeeic(data) {
    data = false;
  }

  openedChangeeicd(data) {
    data = false;
  }

  disableSelectClick() {
    this.isSelectDisable = false;
  }

  disableSelectClickshr() {
    this.isStateDisable = false;
  }
  groupCode: string = "";
  groupText: string = "";
  groupVisible: boolean = false;
  setDropdownData(data: any) {
    this.groupCode = data.mstCode;
    this.groupText = data.mstName;
    this.groupVisible = false;
    this.getGroupDetails(parseInt(data.mstCode));
  }

  getGroupDetails(groupcode: number) {
    var request = JSON.parse(JSON.stringify(this.UCObj));
    request.resCode = "1";
    request.RequestID = "2|" + this.shared.userCode + "|" + groupcode.toString() + "|0";
    this.mdm.DataTable(request).subscribe(
      res => {
        this.GRPRoles = res;

        var grpArr = res.filter(f => f.isAssigned === 1)
        if (grpArr.length > 0) {
          this.userRoleDetails.GroupAdminRoles = grpArr;
        }
      }, err => { }
    );

  }

  isStateDisable: boolean = false;
  isAreaDisable: boolean = false;
  selectedstateCancelElement(data: { mstCode: number; }, target: string) {
    if (target === "state") {
      this.isStateDisable = true;
      this.userRoleDetails.SHRRoles = this.userRoleDetails.SHRRoles.filter(f => f.mstCode !== data.mstCode);
      this.StateSelected(data);
    }
    else if (target === "area") {
      this.mySelect.close();
      this.isAreaDisable = true;
      this.userRoleDetails.AHRRoles = this.userRoleDetails.AHRRoles.filter(f => f.mstCode !== data.mstCode);
    }
  }

  Toggle1() { this.groupVisible = !this.groupVisible; }

  disableSelectClickeic() {
    this.isEIC = false;
  }

  disableSelectClickeicd() {
    this.isEICD = false;
  }
}

export class groupAreaddl {
  name: string;
  submenuArray: userRoledetails[];
}

export class groupStateddl {
  name: string;
  submenuArray: userRoledetails[];
}