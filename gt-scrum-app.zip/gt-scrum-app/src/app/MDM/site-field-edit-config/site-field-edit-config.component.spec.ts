import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SiteFieldEditConfigComponent } from './site-field-edit-config.component';

describe('SiteFieldEditConfigComponent', () => {
  let component: SiteFieldEditConfigComponent;
  let fixture: ComponentFixture<SiteFieldEditConfigComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SiteFieldEditConfigComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SiteFieldEditConfigComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
