import { Component, OnInit, NgModule, ViewChild } from '@angular/core';
import { CreateSiteConfigService } from '../../Services/createSiteConfig.service';
import { dropDownDetail } from '../../Model/CcModel/dropDownDetail';
import { requestDetail } from '../../Model/CCModel/requestDetail';
import { SiteFieldsEditConfig } from '../../Model/MDMModel/sitefieldseditconfig';
import { when } from 'q';
import { FilterPipe } from '../../filter.pipe';
import { SharedState, searchRequester } from 'src/app/Model/Common/InterPage';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { validationTest } from 'src/app/validationTest';
import { fieldDetail } from 'src/app/Model/CcModel/fieldDetail';
import { mstDetails } from 'src/app/Model/CcModel/MstDetails';
import { MdmService } from 'src/app/Services/mdm.service';


@Component({
  selector: 'app-site-field-edit-config',
  templateUrl: './site-field-edit-config.component.html',
  styleUrls: ['./site-field-edit-config.component.css']
})
export class SiteFieldEditConfigComponent implements OnInit {
  //Dropdown User Defiend Property
  ddlSiteField: mstDetails[];
  ddlRole: mstDetails[];
  ddlStatus: mstDetails[];
  ddlFieldGroup: mstDetails[];
  //End Dropdown User Defiend Property
  //Property class object
  UCObj: requestDetail = new requestDetail();
  siteFieldsEditConfigdetails: SiteFieldsEditConfig = new SiteFieldsEditConfig();
  shared: SharedState = new SharedState();
  searchRequester: searchRequester = new searchRequester();
  validationTest: validationTest = new validationTest();
  //End Property class object

  // Dropdown Visiblity
  isRolesDropDownVisible: boolean = false;
  isStatusDropDownVisible: boolean = false;
  isSiteFieldsDropDownVisible: boolean = false;
  isFieldGroupDropDownVisible: boolean = false;
  navigationSubscription;
  isValidate: boolean = false;
  //End Dropdown Visiblity

  //Drop down Related Propery
  Status: IListDetail = {};
  roles: IListDetail = {};
  SiteFields: IListDetail = {};
  FieldGroup: IListDetail = {};
  msgSave: string = "";

  userName: string = "";

  siteFieldIsDirty: boolean = false;
  statusIsDirty: boolean = false;
  RoleIsDirty: boolean = false;
  FieldGroupIsDirty: boolean = false;

  siteFieldEditConfigRedirect: boolean = false;


  siteFieldDetailValue: string = "";
  statusDetailValue: string = "";
  TableReferencesDetailValue: string = "";
  RoledDetailValue: string = "";
  FieldGroupDetailValue: string = "";

  //End Drop down Related Propery


  //Dropdown Toggle
  RolesDropDownToggle() {
    this.isRolesDropDownVisible = !this.isRolesDropDownVisible;
  }
  StatusDropDownToggle() {
    this.isStatusDropDownVisible = !this.isStatusDropDownVisible;
  }
  SiteFieldsDropDownToggle() {
    this.isSiteFieldsDropDownVisible = !this.isSiteFieldsDropDownVisible;
  }
  FieldGroupDropDownToggle() {
    this.isFieldGroupDropDownVisible = !this.isFieldGroupDropDownVisible;
  }
  //End  Dropdown Toggle

  constructor(private mdm: MdmService, private _createSiteConfig: CreateSiteConfigService /*CreateSiteConfigService service Called*/, private router: Router) {
    this.Clear();
    this.shared = JSON.parse(atob(localStorage.getItem('shared')));

     //#region PreLoad Validate page for correct request
     if (!window.history.state.hasOwnProperty('stateElement')) {
      this.router.navigateByUrl('searchlist', { state: null });
    }
    //#endregion

    this.UCObj.RequestID = "VENDORID"; this.UCObj.resCode = "2"; this.UCObj.siteCode = "1";
  }

  ngOnInit() {
    this.siteFieldsEditConfigdetails = window.history.state; this.UCObj.siteCode = "1";
    this.userName = this.shared.userName;
    this.searchRequester = window.history.state;
    this.siteFieldsEditConfigdetails.code = this.searchRequester.stateElement.hasOwnProperty('code_0') ? this.searchRequester.stateElement.code_0 : 0;
    this.getSiteFieldEditConfiguration(this.shared.siteCode, "SFECode", this.siteFieldsEditConfigdetails.code.toString());

  }


  getSiteFieldEditConfiguration(siteCode: string, type: string, Code: string) {

    this.mdm.getSiteFieldEditConfiguration(siteCode, type, Code).subscribe(
      res => {

        this.siteFieldsEditConfigdetails = res;
        this.Status = this.siteFieldsEditConfigdetails.isActive;
        this.roles = this.siteFieldsEditConfigdetails.roleCode;
        this.SiteFields = this.siteFieldsEditConfigdetails.siteFieldCode;
        this.FieldGroup = this.siteFieldsEditConfigdetails.fieldgroup;

        if (this.siteFieldsEditConfigdetails.isActive.fieldDetail.value != null) {
          try {
            this.siteFieldsEditConfigdetails.isActive.listDetails = this.siteFieldsEditConfigdetails.isActive.listDetails.filter(f => f.mstcode !== "2");
            this.statusDetailValue = this.siteFieldsEditConfigdetails.isActive.listDetails.filter(f => f.mstcode == (this, this.siteFieldsEditConfigdetails.code > 0 ? this.siteFieldsEditConfigdetails.isActive.fieldDetail.value : "1"))[0].mstText;
            //this.statusDetailValue = this.siteFieldsEditConfigdetails.isActive.listDetails.filter(f => f.mstcode == this.siteFieldsEditConfigdetails.isActive.fieldDetail.value)[0].mstText;
            this.siteFieldsEditConfigdetails.isActive.fieldDetail.value = this.siteFieldsEditConfigdetails.isActive.fieldDetail.value;
            this.statusIsDirty = true;
          }
          catch
          {

          }
        }

        if (this.siteFieldsEditConfigdetails.roleCode.fieldDetail.value != null) {
          try {
            this.RoledDetailValue = this.siteFieldsEditConfigdetails.roleCode.listDetails.filter(f => f.mstcode == this.siteFieldsEditConfigdetails.roleCode.fieldDetail.value)[0].mstText;
            this.siteFieldsEditConfigdetails.roleCode.fieldDetail.value = this.siteFieldsEditConfigdetails.roleCode.fieldDetail.value;
            this.RoleIsDirty = true;
          }
          catch
          {

          }
        }

        if (this.siteFieldsEditConfigdetails.siteFieldCode.fieldDetail.value != null) {
          try {
            this.siteFieldDetailValue = this.siteFieldsEditConfigdetails.siteFieldCode.listDetails.filter(f => f.mstcode == this.siteFieldsEditConfigdetails.siteFieldCode.fieldDetail.value)[0].mstText;
            this.siteFieldsEditConfigdetails.siteFieldCode.fieldDetail.value = this.siteFieldsEditConfigdetails.siteFieldCode.fieldDetail.value;
            this.siteFieldIsDirty = true;
          }
          catch
          {

          }
        }

        if (this.siteFieldsEditConfigdetails.fieldgroup.fieldDetail.value != null) {
          try {
            this.FieldGroupDetailValue = this.siteFieldsEditConfigdetails.fieldgroup.listDetails.filter(f => f.mstcode == this.siteFieldsEditConfigdetails.fieldgroup.fieldDetail.value)[0].mstText;
            this.siteFieldsEditConfigdetails.fieldgroup.fieldDetail.value = this.siteFieldsEditConfigdetails.fieldgroup.fieldDetail.value;
            this.FieldGroupIsDirty = true;
          }
          catch
          {

          }
        }

        if (this.siteFieldsEditConfigdetails.approvalFlag != null) {
          this.siteFieldsEditConfigdetails.approvalFlag = this.siteFieldsEditConfigdetails.approvalFlag.toString();
        }

        if (this.siteFieldsEditConfigdetails.editFlag != null) {
          this.siteFieldsEditConfigdetails.editFlag = this.siteFieldsEditConfigdetails.editFlag.toString();
        }


      }

    )
  }



  setSiteFields(data: any) {
    this.siteFieldDetailValue = data.mstText;
    this.siteFieldsEditConfigdetails.siteFieldCode.fieldDetail.value = data.mstcode;
    this.isSiteFieldsDropDownVisible = false;
    this.siteFieldIsDirty = true;
  }


  setStatus(data: any) {
    this.statusDetailValue = data.mstText;
    this.siteFieldsEditConfigdetails.isActive.fieldDetail.value = data.mstcode;
    this.isStatusDropDownVisible = false;
    this.statusIsDirty = true;
  }

  setRole(data: any) {
    this.RoledDetailValue = data.mstText;
    this.siteFieldsEditConfigdetails.roleCode.fieldDetail.value = data.mstcode;
    this.isRolesDropDownVisible = false;
    this.RoleIsDirty = true;
  }

  setFieldGroup(data: any) {
    this.FieldGroupDetailValue = data.mstText;
    this.siteFieldsEditConfigdetails.fieldgroup.fieldDetail.value = data.mstcode;
    this.isFieldGroupDropDownVisible = false;
    this.FieldGroupIsDirty = true;
    if (data.mstcode != "0") {
      this.getSiteFields(this.UCObj.siteCode, this.UCObj.resCode, "SFG", data.mstcode);
    }
    else {
      // this.SiteFields="";
    }

  }

  Back() {
    this.Clear();
    this.searchRequester.stateElement = this.siteFieldsEditConfigdetails;
    this.router.navigateByUrl('MstSite', { state: this.searchRequester });
  }
  Save() {

    this.Validate();
    if (this.isValidate === false) {
      this.UCObj.resCode = "2"; this.UCObj.siteCode = "1";
      this.siteFieldsEditConfigdetails.requestDetails = this.UCObj;
      this.mdm.saveSiteFieldEditConfig(this.siteFieldsEditConfigdetails).subscribe(
        res => {
          this.siteFieldsEditConfigdetails.code = parseInt(res.status);
          this.msgSave = res.message;

          if (res.code == 0) {
            this.siteFieldEditConfigRedirect = true;
          }
          else {
            this.siteFieldEditConfigRedirect = false;
          }
        }, err => { });
    }
  }

  getSiteFields(siteCode: string, resCode: string, Entity: string, RefID: string) {
    this._createSiteConfig.getEntityInfo(siteCode, resCode, Entity, RefID).then((res) => {
      if (res.length > 0) {
        this.SiteFields = res[0];
        this.siteFieldsEditConfigdetails.siteFieldCode = res[0];
        // this.ddlSiteField = res[0].listDetails;
      }

    }, err => { });
  }





  Clear() {
    // this.siteFieldsEditConfigdetails.siteFieldCode=0;
    // this.siteFieldsEditConfigdetails.roleCode=0;
    // this.siteFieldsEditConfigdetails.IsActive=0;
    // this.siteFieldsEditConfigdetails.EditFlag="";
    // this.siteFieldsEditConfigdetails.ApprovalFlag="";

  }

  Validate() {

    // this.isValidate = this.validationTest.requiredValidatorByString(this.FieldGroup).length > 0 ? true : this.isValidate;
    // this.isValidate = this.validationTest.requiredValidatorByString(this.SiteFields).length > 0 ? true : this.isValidate;
    // this.isValidate = this.validationTest.requiredValidatorByString(this.roles).length > 0 ? true : this.isValidate;
    // this.isValidate = this.validationTest.requiredValidatorByString(this.siteFieldsEditConfigdetails.ApprovalFlag).length > 0 ? true : this.isValidate;
    // this.isValidate = this.validationTest.requiredValidatorByString(this.siteFieldsEditConfigdetails.EditFlag).length > 0 ? true : this.isValidate;
  }

  ngOnDestroy() {
    this.Clear();
    if (this.navigationSubscription) {
      this.navigationSubscription.unsubscribe();
    }
  }

}
interface IListDetail {
  listDetails?: any[];
  fieldDetail?: any;
}
