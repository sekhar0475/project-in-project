import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SiteApprovalConfigComponent } from './site-approval-config.component';

describe('SiteApprovalConfigComponent', () => {
  let component: SiteApprovalConfigComponent;
  let fixture: ComponentFixture<SiteApprovalConfigComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SiteApprovalConfigComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SiteApprovalConfigComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
