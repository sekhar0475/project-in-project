import { Component, OnInit, NgModule, ViewChild } from '@angular/core';
import { CreateSiteConfigService } from '../../Services/createSiteConfig.service';
import { dropDownDetail } from '../../Model/CcModel/dropDownDetail';
import { requestDetail } from '../../Model/CCModel/requestDetail';
import { SiteApprovalConfig } from '../../Model/MDMModel/siteapprovalconfig';
import { when } from 'q';
import { FilterPipe } from '../../filter.pipe';
import { SharedState, searchRequester } from 'src/app/Model/Common/InterPage';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { validationTest } from '../../validationTest';
import { fieldDetail } from 'src/app/Model/CcModel/fieldDetail';
import { mstDetails } from 'src/app/Model/CcModel/MstDetails';
import { MdmService } from 'src/app/Services/mdm.service';

@Component({
  selector: 'app-site-approval-config',
  templateUrl: './site-approval-config.component.html',
  styleUrls: ['./site-approval-config.component.css']
})
export class SiteApprovalConfigComponent implements OnInit {

  //Dropdown User Defiend Property 
  ddlRole: mstDetails;
  ddldeptRole1: mstDetails;
  ddldeptRole2: mstDetails;
  ddldeptRole3: mstDetails;
  ddldeptRole4: mstDetails;
  ddlStatus: mstDetails;
  searchText: string = "";
  //End Dropdown User Defiend Property 


  //Property class object 
  UCObj: requestDetail = new requestDetail();
  SiteApprovalConfig: SiteApprovalConfig = new SiteApprovalConfig();
  shared: SharedState = new SharedState();
  searchRequester: searchRequester = new searchRequester();
  validationTest: validationTest = new validationTest();
  //End Property class object 


  // Dropdown Visiblity
  isRolesDropDownVisible: boolean = false;
  isdeptRole1DropDownVisible: boolean = false;
  isdeptRole2DropDownVisible: boolean = false;
  isdeptRole3DropDownVisible: boolean = false;
  isdeptRole4DropDownVisible: boolean = false;
  isStatusDropDownVisible: boolean = false;
  isValidate: boolean = false;
  navigationSubscription;
  //End Dropdown Visiblity

  //Drop down Related Propery 
  Status: IListDetail = {};
  roles: IListDetail = {};
  deptRoles1: IListDetail = {};
  deptRoles2: IListDetail = {};
  deptRoles3: IListDetail = {};
  deptRoles4: IListDetail = {};
  userName: string = "";
  msgSave: string = "";

  roleDetailValue: string = "";
  deptRole1DetailValue: string = "";
  deptRole2DetailValue: string = "";
  deptRole3DetailValue: string = "";
  deptRole4DetailValue: string = "";
  statuDetailValue: string = "";



  deptRole1IsDirty: boolean = false;
  deptRole2IsDirty: boolean = false;
  deptRole3IsDirty: boolean = false;
  deptRole4IsDirty: boolean = false;
  statusIsDirty: boolean = false;
  RoleIsDirty: boolean = false;
  FieldGroupIsDirty: boolean = false;

  siteFieldEditConfigRedirect: boolean = false;
  //End Drop down Related Propery 

  //Dropdown Toggle 
  RolesDropDownToggle() {
    this.isRolesDropDownVisible = this.roles.listDetails.length > 0 ? !this.isRolesDropDownVisible : this.isRolesDropDownVisible;
  }

  DeptRole1DropDownToggle() {
    this.isdeptRole1DropDownVisible = this.deptRoles1.listDetails.length > 0 ? !this.isdeptRole1DropDownVisible : this.isdeptRole1DropDownVisible;
  }
  DeptRole2DropDownToggle() {
    this.isdeptRole2DropDownVisible = this.deptRoles2.listDetails.length > 0 ? !this.isdeptRole2DropDownVisible : this.isdeptRole2DropDownVisible;
  }

  DeptRole3DropDownToggle() {
    this.isdeptRole3DropDownVisible = this.deptRoles3.listDetails.length > 0 ? !this.isdeptRole3DropDownVisible : this.isdeptRole3DropDownVisible;
  }

  DeptRole4DropDownToggle() {
    this.isdeptRole4DropDownVisible = this.deptRoles4.listDetails.length > 0 ? !this.isdeptRole4DropDownVisible : this.isdeptRole4DropDownVisible;
  }

  StatusDropDownToggle() {
    this.isStatusDropDownVisible = this.Status.listDetails.length > 0 ? !this.isStatusDropDownVisible : this.isStatusDropDownVisible;
  }


  //End  Dropdown Toggle 


  constructor(private _createSiteConfig: MdmService /*CreateSiteConfigService service Called*/, private router: Router) {

    this.shared = JSON.parse(atob(localStorage.getItem('shared')));
    this.UCObj.RequestID = "VENDORID"; this.UCObj.resCode = "2"; this.UCObj.siteCode = "1";
    // this.getStatus(this.shared.siteCode,this.UCObj.resCode,"COMMON","0");      // Status
    var request = JSON.parse(JSON.stringify(this.UCObj));
    request.RequestID = '5||30|0';
    request.resCode = "6";



  }

  ngOnInit() {


    this.SiteApprovalConfig = window.history.state; this.UCObj.siteCode = "1";
    this.userName = this.shared.userName;
    this.searchRequester = window.history.state;
    this.SiteApprovalConfig.code = this.searchRequester.stateElement.hasOwnProperty('code_0') ? this.searchRequester.stateElement.code_0 : 0;

    this.getSiteApprovalConfiguration(this.shared.siteCode, "SFACode", this.SiteApprovalConfig.code.toString());

  }

  getSiteApprovalConfiguration(siteCode: string, type: string, Code: string) {
    this._createSiteConfig.getSiteApprovalConfiguration(siteCode, type, Code).subscribe(
      res => {
        this.SiteApprovalConfig = res;
        this.Status = this.SiteApprovalConfig.isActive;
        this.deptRoles1 = this.SiteApprovalConfig.deptRoleCode1;
        this.roles = this.SiteApprovalConfig.roleCode;
        this.deptRoles2 = this.SiteApprovalConfig.deptRoleCode2;
        this.deptRoles3 = this.SiteApprovalConfig.deptRoleCode3;
        this.deptRoles4 = this.SiteApprovalConfig.deptRoleCode4;

        this.SiteApprovalConfig.isActive.listDetails = this.SiteApprovalConfig.isActive.listDetails.filter(f => f.mstcode !== "2");

        if (this.SiteApprovalConfig.roleCode.fieldDetail.value != null) {
          try {
            this.roleDetailValue = this.SiteApprovalConfig.roleCode.listDetails.filter(f => f.mstcode == this.SiteApprovalConfig.roleCode.fieldDetail.value)[0].mstText;
            this.SiteApprovalConfig.roleCode.fieldDetail.value = this.SiteApprovalConfig.roleCode.fieldDetail.value;
            this.RoleIsDirty = true;
          }
          catch
          {

          }

        }

        if (this.SiteApprovalConfig.deptRoleCode1.fieldDetail.value != null) {
          try {
            this.deptRole1DetailValue = this.SiteApprovalConfig.deptRoleCode1.listDetails.filter(f => f.mstcode == this.SiteApprovalConfig.deptRoleCode1.fieldDetail.value)[0].mstText;
            this.SiteApprovalConfig.deptRoleCode1.fieldDetail.value = this.SiteApprovalConfig.deptRoleCode1.fieldDetail.value;
            this.deptRole1IsDirty = true;
          }
          catch
          {

          }

        }

        if (this.SiteApprovalConfig.deptRoleCode2.fieldDetail.value != null) {
          try {
            this.deptRole2DetailValue = this.SiteApprovalConfig.deptRoleCode2.listDetails.filter(f => f.mstcode == this.SiteApprovalConfig.deptRoleCode2.fieldDetail.value)[0].mstText;
            this.SiteApprovalConfig.deptRoleCode2.fieldDetail.value = this.SiteApprovalConfig.deptRoleCode2.fieldDetail.value;
            this.deptRole2IsDirty = true;
          }
          catch
          {

          }
        }

        if (this.SiteApprovalConfig.deptRoleCode3.fieldDetail.value != null) {

          try {

            this.deptRole3DetailValue = this.SiteApprovalConfig.deptRoleCode3.listDetails.filter(f => f.mstcode == this.SiteApprovalConfig.deptRoleCode3.fieldDetail.value)[0].mstText;
            this.SiteApprovalConfig.deptRoleCode3.fieldDetail.value = this.SiteApprovalConfig.deptRoleCode3.fieldDetail.value;
            this.deptRole3IsDirty = true;
          }
          catch
          {

          }
        }

        if (this.SiteApprovalConfig.deptRoleCode4.fieldDetail.value != null) {
          try {
            this.deptRole4DetailValue = this.SiteApprovalConfig.deptRoleCode4.listDetails.filter(f => f.mstcode == this.SiteApprovalConfig.deptRoleCode4.fieldDetail.value)[0].mstText;
            this.SiteApprovalConfig.deptRoleCode4.fieldDetail.value = this.SiteApprovalConfig.deptRoleCode4.fieldDetail.value;
            this.deptRole4IsDirty = true;
          }
          catch
          {

          }
        }

        if (this.SiteApprovalConfig.isActive.fieldDetail.value != null) {
          try {

            this.statuDetailValue = this.SiteApprovalConfig.isActive.listDetails.filter(f =>
              f.mstcode.toString() == (this.SiteApprovalConfig.code > 0 ? this.SiteApprovalConfig.isActive.fieldDetail.value : "1"))[0].mstText;
            //this.statuDetailValue = this.SiteApprovalConfig.isActive.listDetails.filter(f => f.mstcode.toString() == this.SiteApprovalConfig.isActive.fieldDetail.value)[0].mstText;
            this.SiteApprovalConfig.isActive.fieldDetail.value = this.SiteApprovalConfig.isActive.fieldDetail.value;
            this.statusIsDirty = true;
          }
          catch
          {

          }
        }
        if (this.SiteApprovalConfig.isAutoApp != null) {
          this.SiteApprovalConfig.isAutoApp = this.SiteApprovalConfig.isAutoApp ? "1" : "0";
        }

      }
    )
  }

  setRole(data: any) {

    if (data.mstcode != 0) {
      this.roleDetailValue = data.mstText;
      this.SiteApprovalConfig.roleCode.fieldDetail.value = data.mstcode;

    }

    this.isRolesDropDownVisible = false;
    this.RoleIsDirty = true;
  }

  setDeptRole1(data: any) {
    this.deptRole1DetailValue = data.mstText;
    this.SiteApprovalConfig.deptRoleCode1.fieldDetail.value = data.mstcode;
    if (data.mstcode != 0) {
      this.SiteApprovalConfig.deptRoleCode2.listDetails = this.SiteApprovalConfig.deptRoleCode1.listDetails.filter(f => f.mstcode != this.SiteApprovalConfig.deptRoleCode1.fieldDetail.value);
      this.SiteApprovalConfig.deptRoleCode3.listDetails = this.SiteApprovalConfig.deptRoleCode1.listDetails.filter(f => f.mstcode != this.SiteApprovalConfig.deptRoleCode1.fieldDetail.value);
      this.SiteApprovalConfig.deptRoleCode4.listDetails = this.SiteApprovalConfig.deptRoleCode1.listDetails.filter(f => f.mstcode != this.SiteApprovalConfig.deptRoleCode1.fieldDetail.value);
    }


    this.isdeptRole1DropDownVisible = false;
    this.deptRole1IsDirty = true;
  }

  setDeptRole2(data: any) {
    this.deptRole2DetailValue = data.mstText;
    this.SiteApprovalConfig.deptRoleCode2.fieldDetail.value = data.mstcode;

    if (data.mstcode != 0) {
      this.SiteApprovalConfig.deptRoleCode1.listDetails = this.SiteApprovalConfig.deptRoleCode2.listDetails.filter(f => f.mstcode != this.SiteApprovalConfig.deptRoleCode2.fieldDetail.value);
      this.SiteApprovalConfig.deptRoleCode3.listDetails = this.SiteApprovalConfig.deptRoleCode2.listDetails.filter(f => f.mstcode != this.SiteApprovalConfig.deptRoleCode2.fieldDetail.value);
      this.SiteApprovalConfig.deptRoleCode4.listDetails = this.SiteApprovalConfig.deptRoleCode2.listDetails.filter(f => f.mstcode != this.SiteApprovalConfig.deptRoleCode2.fieldDetail.value);
    }
    this.isdeptRole2DropDownVisible = false;
    this.deptRole2IsDirty = true;
  }

  setDeptRole3(data: any) {
    this.deptRole3DetailValue = data.mstText;
    this.SiteApprovalConfig.deptRoleCode3.fieldDetail.value = data.mstcode;
    if (data.mstcode != 0) {
      this.SiteApprovalConfig.deptRoleCode1.listDetails = this.SiteApprovalConfig.deptRoleCode3.listDetails.filter(f => f.mstcode != this.SiteApprovalConfig.deptRoleCode3.fieldDetail.value);
      this.SiteApprovalConfig.deptRoleCode2.listDetails = this.SiteApprovalConfig.deptRoleCode3.listDetails.filter(f => f.mstcode != this.SiteApprovalConfig.deptRoleCode3.fieldDetail.value);
      this.SiteApprovalConfig.deptRoleCode4.listDetails = this.SiteApprovalConfig.deptRoleCode3.listDetails.filter(f => f.mstcode != this.SiteApprovalConfig.deptRoleCode3.fieldDetail.value);
    }

    this.isdeptRole3DropDownVisible = false;
    this.deptRole3IsDirty = true;
  }

  setDeptRole4(data: any) {
    this.deptRole4DetailValue = data.mstText;
    this.SiteApprovalConfig.deptRoleCode4.fieldDetail.value = data.mstcode;
    if (data.mstcode != 0) {
      this.SiteApprovalConfig.deptRoleCode1.listDetails = this.SiteApprovalConfig.deptRoleCode4.listDetails.filter(f => f.mstcode != this.SiteApprovalConfig.deptRoleCode4.fieldDetail.value);
      this.SiteApprovalConfig.deptRoleCode2.listDetails = this.SiteApprovalConfig.deptRoleCode4.listDetails.filter(f => f.mstcode != this.SiteApprovalConfig.deptRoleCode4.fieldDetail.value);
      this.SiteApprovalConfig.deptRoleCode3.listDetails = this.SiteApprovalConfig.deptRoleCode4.listDetails.filter(f => f.mstcode != this.SiteApprovalConfig.deptRoleCode4.fieldDetail.value);
    }

    this.isdeptRole4DropDownVisible = false;
    this.deptRole4IsDirty = true;
  }

  setStatus(data: any) {
    this.statuDetailValue = data.mstText;
    this.SiteApprovalConfig.isActive.fieldDetail.value = data.mstcode;
    this.isStatusDropDownVisible = false;
    this.statusIsDirty = true;

  }

  Save() {
    this.Validate();

    if (this.isValidate === false) {
      this.UCObj.resCode = "2"; this.UCObj.siteCode = "1";
      this.SiteApprovalConfig.requestDetails = this.UCObj;
      this._createSiteConfig.saveSiteApprovalConfig(this.SiteApprovalConfig).subscribe((res) => {
        this.msgSave = res.message;
        if (res.code == 0) {
          this.siteFieldEditConfigRedirect = true;
        }
        else {
          this.siteFieldEditConfigRedirect = false;
        }
      }, err => { });

    }
  }

  Back() {
    this.Clear();
    this.searchRequester.stateElement = this.SiteApprovalConfig;
    this.router.navigateByUrl('MstSite', { state: this.searchRequester });

  }

  Validate() {
    this.isValidate = this.validationTest.requiredValidatorByString(this.roleDetailValue).length > 0 ? true : this.isValidate;
    this.isValidate = this.validationTest.requiredValidatorByString(this.SiteApprovalConfig.roleCode.fieldDetail.value).length > 0 ? true : this.isValidate;
    // this.isValidate = this.validationTest.requiredValidatorByString(this.SiteApprovalConfig.deptRoleCode1.fieldDetail.value).length > 0 ? true : this.isValidate;
    // this.isValidate = this.validationTest.requiredValidatorByString(this.SiteApprovalConfig.deptRoleCode2.fieldDetail.value).length > 0 ? true : this.isValidate;
    // this.isValidate = this.validationTest.requiredValidatorByString(this.SiteApprovalConfig.deptRoleCode3.fieldDetail.value).length > 0 ? true : this.isValidate;
    // this.isValidate = this.validationTest.requiredValidatorByString(this.SiteApprovalConfig.deptRoleCode4.fieldDetail.value).length > 0 ? true : this.isValidate;
    this.isValidate = this.validationTest.requiredValidatorByString(this.SiteApprovalConfig.appDisplaySeq.toString()).length > 0 ? true : this.isValidate;
    this.isValidate = this.validationTest.requiredValidatorByString((this.SiteApprovalConfig.appDuration === null ? "" : this.SiteApprovalConfig.appDuration).toString()).length > 0 ? true : this.isValidate;

  }

  Clear() {
    this.getSiteApprovalConfiguration(this.shared.siteCode, "SFACode", "0");
    this.roleDetailValue ="";
    this.deptRole1DetailValue ="";
    this.deptRole2DetailValue ="";
    this.deptRole3DetailValue ="";
    this.deptRole4DetailValue ="";
  }

}
interface IListDetail {
  listDetails?: any[];
  fieldDetail?: any;
}
