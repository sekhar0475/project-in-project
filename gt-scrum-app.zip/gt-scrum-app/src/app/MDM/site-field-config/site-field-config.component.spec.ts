import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SiteFieldConfigComponent } from './site-field-config.component';

describe('SiteFieldConfigComponent', () => {
  let component: SiteFieldConfigComponent;
  let fixture: ComponentFixture<SiteFieldConfigComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SiteFieldConfigComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SiteFieldConfigComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
