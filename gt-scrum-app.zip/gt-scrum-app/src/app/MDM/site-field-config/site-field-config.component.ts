import { Component, OnInit, NgModule, ViewChild } from '@angular/core';
import { CreateSiteConfigService } from '../../Services/createSiteConfig.service';
import { dropDownDetail } from '../../Model/CcModel/dropDownDetail';
import { requestDetail } from '../../Model/CCModel/requestDetail';
import { siteFieldsConfig } from '../../Model/MDMModel/siteFieldsConfig';
import { when } from 'q';
import { FilterPipe } from '../../filter.pipe';
import { SharedState, searchRequester } from 'src/app/Model/Common/InterPage';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { validationTest } from '../../validationTest';
import { fieldDetail } from 'src/app/Model/CcModel/fieldDetail';
import { mstDetails } from 'src/app/Model/CcModel/MstDetails';
import { MdmService } from 'src/app/Services/mdm.service';
@Component({
  selector: 'app-site-field-config',
  templateUrl: './site-field-config.component.html',
  styleUrls: ['./site-field-config.component.css']
})
export class SiteFieldConfigComponent implements OnInit {

  validationTest: validationTest = new validationTest();

  //Dropdown User Defiend Property 
  ddlFieldGroup: mstDetails[];
  ddlTableRef: mstDetails[];
  ddlStatus: mstDetails[];
  ddlFieldType: mstDetails[];
  ddlParentField: mstDetails[];

  //End Dropdown User Defiend Property 

  //Property class object 
  UCObj: requestDetail = new requestDetail();
  siteFieldsConfigdetails: siteFieldsConfig = new siteFieldsConfig;
  shared: SharedState = new SharedState();
  searchRequester: searchRequester = new searchRequester();
  searchText: string = "";
  //End Property class object 

  // Dropdown Visiblity
  isFieldGroupDropDownVisible: boolean = false;
  isStatusDropDownVisible: boolean = false;
  isTableRefDropDownVisible: boolean = false;
  isFieldTypeDropDownVisible: boolean = false;
  isParentFieldDropDownVisible: boolean = false;
  isValidate: boolean = false;
  //End Dropdown Visiblity

  //Drop down Related Propery 
  groupDetailIsDirty: boolean = false;
  searchGroupText: string;

  Status: IListDetail = {};
  Groups: IListDetail = {};
  FieldTypes: IListDetail = {};
  TableReferences: IListDetail = {};
  ParentField: IListDetail = {};

  msgSave: string = "";

  statusIsDirty: boolean = false;
  fieldGroupIsDirty: boolean = false;
  fieldTypeIsDirty: boolean = false;
  tableReferenceDirty: boolean = false;
  siteFieldConfigRedirect: boolean = false;
  siteFieldParentIsDirty: boolean = false;

  GroupsDetailValue: string = "";
  FieldTypesDetailValue: string = "";
  TableReferencesDetailValue: string = "";
  ParentFieldDetailValue: string = "";
  statuDetailValue: string = "";
  EditMode: boolean = false;

  userName: string;
  searchStatusText: string;
  Mandatory: any;
  subscription: Subscription;
  navigationSubscription;
  isPersonalInfoProceed: boolean = false;
  //End Drop down Related Propery 

  //Dropdown Toggle 
  FieldGroupDropDownToggle() {
    if (this.EditMode === false) {
      this.isFieldGroupDropDownVisible = !this.isFieldGroupDropDownVisible;
    }
  }
  StatusDropDownToggle() {
    this.isStatusDropDownVisible = !this.isStatusDropDownVisible;
  }
  TableRefDropDownToggle() {
    if (this.EditMode === false) {
      this.isTableRefDropDownVisible = !this.isTableRefDropDownVisible;
    }
  }
  FieldTypeDropDownToggle() {
    this.isFieldTypeDropDownVisible = !this.isFieldTypeDropDownVisible;
  }
  FieldParentTypeIdDropDownToggle() {
    this.isParentFieldDropDownVisible = !this.isParentFieldDropDownVisible;
  }
  //End  Dropdown Toggle 

  constructor(private _createSiteConfig: MdmService /*CreateSiteConfigService service Called*/, private router: Router) {
    this.Clear();

     //#region PreLoad Validate page for correct request
     if (!window.history.state.hasOwnProperty('stateElement')) {
      this.router.navigateByUrl('searchlist', { state: null });
    }
    //#endregion
    
    this.shared = JSON.parse(atob(localStorage.getItem('shared')));
    this.UCObj.RequestID = "VENDORID"; this.UCObj.resCode = "2"; this.UCObj.siteCode = "1";
    var request = JSON.parse(JSON.stringify(this.UCObj));
  }

  ngOnInit() {

    this.siteFieldsConfigdetails = window.history.state; this.UCObj.siteCode = "1";
    this.userName = this.shared.userName;
    this.searchRequester = window.history.state;
    this.siteFieldsConfigdetails.code = this.searchRequester.stateElement.hasOwnProperty('code_0') ? this.searchRequester.stateElement.code_0 : 0;
    this.EditMode = (this.siteFieldsConfigdetails.code > 0 ? true : false);
    this.getSiteFieldConfiguration(this.shared.siteCode, "SFCode", this.siteFieldsConfigdetails.code.toString());

  }

  getSiteFieldConfiguration(siteCode: string, type: string, Code: string) {

    this._createSiteConfig.getSiteFieldConfiguration(siteCode, type, Code).subscribe(
      res => {
        this.siteFieldsConfigdetails = res;
        this.Status = this.siteFieldsConfigdetails.isActive;
        this.TableReferences = this.siteFieldsConfigdetails.tableRef;
        this.FieldTypes = this.siteFieldsConfigdetails.fieldType;
        this.ParentField = this.siteFieldsConfigdetails.fieldParentID;
        this.Groups = this.siteFieldsConfigdetails.fieldGroup;

        this.siteFieldsConfigdetails.isActive.listDetails = this.siteFieldsConfigdetails.isActive.listDetails.filter(f => f.mstcode !== "2");

        if (this.siteFieldsConfigdetails.isActive.fieldDetail.value != null) {
          try {
            //f.mstcode == (this, this.SiteConfigdetails.code > 0 ? this.SiteConfigdetails.isActive.fieldDetail.value : "1"
            this.statuDetailValue = this.siteFieldsConfigdetails.isActive.listDetails.filter(f => 
              f.mstcode == (this.siteFieldsConfigdetails.code > 0 ? this.siteFieldsConfigdetails.isActive.fieldDetail.value : "1")
              )[0].mstText;
            //this.statuDetailValue = this.siteFieldsConfigdetails.isActive.listDetails.filter(f => f.mstcode == this.siteFieldsConfigdetails.isActive.fieldDetail.value)[0].mstText;
            this.siteFieldsConfigdetails.isActive.fieldDetail.value = this.siteFieldsConfigdetails.isActive.fieldDetail.value;
            this.statusIsDirty = true;
          }
          catch
          {

          }
        }

        if (this.siteFieldsConfigdetails.tableRef.fieldDetail.value != null) {
          try {
            this.TableReferencesDetailValue = this.siteFieldsConfigdetails.tableRef.listDetails.filter(f => f.mstcode == this.siteFieldsConfigdetails.tableRef.fieldDetail.value)[0].mstText;
            this.siteFieldsConfigdetails.tableRef.fieldDetail.value = this.siteFieldsConfigdetails.tableRef.fieldDetail.value;
            this.tableReferenceDirty = true;
          }
          catch
          {

          }
        }

        if (this.siteFieldsConfigdetails.fieldGroup.fieldDetail.value != null) {
          try {
            this.GroupsDetailValue = this.siteFieldsConfigdetails.fieldGroup.listDetails.filter(f => f.mstcode == this.siteFieldsConfigdetails.fieldGroup.fieldDetail.value)[0].mstText;
            this.siteFieldsConfigdetails.fieldGroup.fieldDetail.value = this.siteFieldsConfigdetails.fieldGroup.fieldDetail.value;
            this.groupDetailIsDirty = true;
          }
          catch
          {

          }
        }

        if (this.siteFieldsConfigdetails.fieldType.fieldDetail.value != null) {
          try {
            this.FieldTypesDetailValue = this.siteFieldsConfigdetails.fieldType.listDetails.filter(f => f.mstcode == this.siteFieldsConfigdetails.fieldType.fieldDetail.value)[0].mstText;
            this.siteFieldsConfigdetails.fieldType.fieldDetail.value = this.siteFieldsConfigdetails.fieldType.fieldDetail.value;
            this.fieldTypeIsDirty = true;
          }
          catch
          {

          }
        }

        if (this.siteFieldsConfigdetails.fieldParentID.fieldDetail.value != null) {
          try {
            this.ParentFieldDetailValue = this.siteFieldsConfigdetails.fieldParentID.listDetails.filter(f => f.mstcode == this.siteFieldsConfigdetails.fieldParentID.fieldDetail.value)[0].mstText;
            this.siteFieldsConfigdetails.fieldParentID.fieldDetail.value = this.siteFieldsConfigdetails.fieldParentID.fieldDetail.value;
            this.siteFieldParentIsDirty = true;
          }
          catch
          {

          }
        }

        if (this.siteFieldsConfigdetails.isMandatory != null) {
          this.siteFieldsConfigdetails.isMandatory = this.siteFieldsConfigdetails.isMandatory.toString();
        }

        if (this.siteFieldsConfigdetails.displayFlagAdd != null) {
          this.siteFieldsConfigdetails.displayFlagAdd = this.siteFieldsConfigdetails.displayFlagAdd.toString();
        }


        if (this.siteFieldsConfigdetails.displayFlagEdit != null) {
          this.siteFieldsConfigdetails.displayFlagEdit = this.siteFieldsConfigdetails.displayFlagEdit.toString();
        }



      }
    )
  }

  setGroup(data: any) {
    this.GroupsDetailValue = data.mstText;
    this.siteFieldsConfigdetails.fieldGroup.fieldDetail.value = data.mstcode;
    this.isFieldGroupDropDownVisible = false;
    this.fieldGroupIsDirty = true;
  }

  setStatus(data: any) {
    this.statuDetailValue = data.mstText;
    this.siteFieldsConfigdetails.isActive.fieldDetail.value = data.mstcode;
    this.isStatusDropDownVisible = false;
    this.statusIsDirty = true;
  }

  setFieldType(data: any) {
    this.FieldTypesDetailValue = data.mstText;
    this.siteFieldsConfigdetails.fieldType.fieldDetail.value = data.mstcode;
    this.isFieldTypeDropDownVisible = false;
    this.fieldTypeIsDirty = true;
  }

  setTableRef(data: any) {
    this.TableReferencesDetailValue = data.mstText;
    this.siteFieldsConfigdetails.tableRef.fieldDetail.value = data.mstcode;
    this.isTableRefDropDownVisible = false;
    this.tableReferenceDirty = true;
  }

  setParentFieldId(data: any) {
    this.ParentFieldDetailValue = data.mstText;
    this.siteFieldsConfigdetails.fieldParentID.fieldDetail.value = data.mstcode;
    this.isParentFieldDropDownVisible = false;
    this.siteFieldParentIsDirty = true;
  }

  Save() {
    this.Validate();

    if (this.isValidate === false) {
      this.isPersonalInfoProceed = true;
      this.UCObj.resCode = "2"; this.UCObj.siteCode = "1";
      this.siteFieldsConfigdetails.requestDetails = this.UCObj;

      this._createSiteConfig.saveSiteFieldConfig(this.siteFieldsConfigdetails).subscribe(
        res => {
          this.siteFieldsConfigdetails.code = parseInt(res.status);
          this.msgSave = res.message;
          setTimeout(() => { this.msgSave = ""; }, 10000);
          if (res.code == 0) {
            this.siteFieldConfigRedirect = true;
          }
          else {
            this.siteFieldConfigRedirect = false;
          }
        },
        err => {

        });
    }
  }


  Back() {
    this.Clear();
    this.searchRequester.stateElement = this.siteFieldsConfigdetails;
    this.router.navigateByUrl('MstSite', { state: this.searchRequester });
  }
  Clear() {
    this.siteFieldsConfigdetails.fieldName = "";
    this.siteFieldsConfigdetails.fieldID = "";
    this.siteFieldsConfigdetails.labelID = "";
    this.siteFieldsConfigdetails.labelText = "";
    this.siteFieldsConfigdetails.fieldLength = "";
    this.siteFieldsConfigdetails.fieldSeq = 0;
    // this.Groups="";
    // this.Status ="";
    // this.TableReferences="";
    // this.FieldTypes="";
    // this.ParentField="";
  }
  Validate() {
    
    this.isValidate = this.validationTest.requiredValidatorByString(this.GroupsDetailValue).length > 0 ? true : this.isValidate;
    this.isValidate = this.validationTest.requiredValidatorByString(this.siteFieldsConfigdetails.fieldGroup.fieldDetail.value) > "0" ? true : this.isValidate;
    this.isValidate = this.validationTest.requiredValidatorByString(this.siteFieldsConfigdetails.isActive.fieldDetail.value) > "0" ? true : this.isValidate;
    this.isValidate = this.validationTest.requiredValidatorByString(this.siteFieldsConfigdetails.tableRef.fieldDetail.value).length > 0 ? true : this.isValidate;
    this.isValidate = this.validationTest.requiredValidatorByString(this.siteFieldsConfigdetails.fieldType.fieldDetail.value).length > 0 ? true : this.isValidate;
    this.isValidate = this.validationTest.requiredValidatorByString(this.siteFieldsConfigdetails.fieldLength).length > 0 ? true : this.isValidate;
    this.isValidate = this.validationTest.requiredValidatorByString(this.siteFieldsConfigdetails.fieldName).length > 0 ? true : this.isValidate;
    this.isValidate = this.validationTest.requiredValidatorByString(this.siteFieldsConfigdetails.labelID).length > 0 ? true : this.isValidate;
    this.isValidate = this.validationTest.requiredValidatorByString(this.siteFieldsConfigdetails.labelText).length > 0 ? true : this.isValidate;
    this.isValidate = this.validationTest.requiredValidatorByString(this.siteFieldsConfigdetails.fieldSeq.toString()).length > 0 ? true : this.isValidate;
    this.isValidate = this.validationTest.requiredValidatorByString(this.siteFieldsConfigdetails.isMandatory.toString()).length > 0 ? true : this.isValidate;
    this.isValidate = this.validationTest.requiredValidatorByString(this.siteFieldsConfigdetails.displayFlagAdd.toString()).length > 0 ? true : this.isValidate;
    this.isValidate = this.validationTest.requiredValidatorByString(this.siteFieldsConfigdetails.displayFlagEdit.toString()).length > 0 ? true : this.isValidate;

  }
  ngOnDestroy() {
    this.Clear();
    if (this.navigationSubscription) {
      this.navigationSubscription.unsubscribe();
    }
  }

}
interface IListDetail {
  listDetails?: any[];
  fieldDetail?: any;
}
