import { Component, OnInit, ViewChild, Pipe } from '@angular/core';
import { CommonService } from 'src/app/Services/common.service';
import { Router } from '@angular/router';
import { searchRequester, SharedState } from 'src/app/Model/Common/InterPage';
import { requestDetail } from 'src/app/Model/CCModel/requestDetail';
import { menuDetail, groupMenuddl } from 'src/app/Model/UcModel/menuDetail';
import { dropDownDetail } from 'src/app/Model/CcModel/DropDownDetail';
import { isNullOrUndefined } from 'util';
import { promise } from 'protractor';
import { MenuMasterService } from 'src/app/Services/menu-master.service';
import { validationTest } from 'src/app/validationTest';
import { Observable, of } from 'rxjs';
import { HttpClientModule, HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { map, tap, catchError } from "rxjs/operators";
import { httpOptions } from '../../Services/httpConstant';
import { mstCollection } from 'src/app/Model/CcModel/mstCollection';
import { mstDetails } from 'src/app/Model/CcModel/MstDetails';
import { MatSelect } from '@angular/material';
import { FormControl } from '@angular/forms';
import { Pokemon } from 'src/app/mat-scrum-drop-down-test/mat-scrum-drop-down-test.component';
import { MdmService } from 'src/app/Services/mdm.service';

@Component({
  selector: 'app-menu-master',
  templateUrl: './menu-master.component.html',
  styleUrls: ['./menu-master.component.css']
})
export class MenuMasterComponent implements OnInit {

  parentMenuText: string = "";

  constructor(private menuService: MdmService, private router: Router) {
    this.menuDetails.parentMenuCode = "2";
    this.groupedDll = new Array;
  }

  //#region Load time Parameters
  breadcrumb: string = "";
  shared: SharedState = new SharedState();
  userName: string = "";
  roleFetchObj: requestDetail = new requestDetail();
  checked: boolean = false;
  //#endregion

  //#region Temp & initial variables.
  searchRequester: searchRequester = new searchRequester();
  requestForMenu: requestDetail = new requestDetail();
  menuDetails: menuDetail = new menuDetail;

  searchStatusText: string = "";
  Status: string = "";
  isStatusDropDownVisible: boolean = false;
  StatusIsDirty: boolean = false;
  isValidate: boolean = false;
  msgSave: string = "";
  pokemonControl = new FormControl();
  validationTest: validationTest = new validationTest();

  // isValidate: boolean = false;

  //#endregion

  length: number = 5;// = isNullOrUndefined( this.menuDetails.parentMenuCode) || this.menuDetails.parentMenuCode.length === 0 ? 0 : this.menuDetails.parentMenuCode.length;


  ngOnInit() {

    //#region PreLoad Validate page for correct request

    if (!window.history.state.hasOwnProperty('pageHeader')) {
      this.shared = null;
      this.router.navigateByUrl('searchlist', { state: this.searchRequester });
    }
    else {
      this.shared = JSON.parse(atob(localStorage.getItem('shared')));
      this.userName = this.shared.userName;
      this.searchRequester = window.history.state;
    }

    //#endregion

    //#region get LocalStorage mandatory parameters, State parameters and Set

    this.shared = JSON.parse(atob(localStorage.getItem('shared')));

    this.searchRequester = window.history.state;

    this.searchRequester.stateElement = this.searchRequester.hasOwnProperty("stateElement") ?
      this.searchRequester.stateElement : null;

    this.breadcrumb = this.searchRequester.pageHeader;
    this.menuDetails.menuCode = this.searchRequester.stateElement === null ? 0 :
      this.searchRequester.stateElement.hasOwnProperty('menuCode_0') ? this.searchRequester.stateElement.menuCode_0 : 0;

    //this.LoadParentMenus();

    var request = JSON.parse(JSON.stringify(this.searchRequester.ucObj));
    request.RequestID = request.RequestID.replace("1|", "2|").replace("@SEARCHTEXT", "").
      replace("@MENUCODE", this.menuDetails.menuCode).replace("@STATUS", "0");

    this.fetch(request);

    this.roleFetchObj = this.searchRequester.ucObj;

    //#endregion

    //#region Load Group Parent Menu
    this.requestForMenu.siteCode = this.shared.siteCode;
    this.requestForMenu.resCode = "MENU" + JSON.parse(JSON.stringify(this.searchRequester.ucObj.resCode));
    this.requestForMenu.RequestID = "ASS|" + this.shared.userCode + "|0|0";
    //#endregion    
  }

  groupedDll: groupMenuddl[];

  ismasterDisable: boolean = false;
  @ViewChild('mySelect', { static: true }) mySelect: MatSelect;

  fetch(fetchRequest: requestDetail) {
    this.menuService.getMenuMasterModel(fetchRequest).subscribe(
      res => {
        
        this.menuDetails = res;

        this.menuDetails.parentMenuName = res.menuCode === "" || res.menuCode === "0" ? "" :
          res.ddlParentMenu.listDetails.filter((f: { mstcode: any; }) => f.mstcode === res.parentMenuCode.toString()).length > 0 ?
            res.ddlParentMenu.listDetails.filter((f: { mstcode: any; }) => f.mstcode === res.parentMenuCode.toString())[0].mstText : "";

        this.menuDetails.parentMenuCode = res.menuCode === "" || res.menuCode === "0" ? "" :
          res.ddlParentMenu.listDetails.filter((f: { mstcode: any; }) => f.mstcode === res.parentMenuCode.toString()).length > 0 ?
            res.ddlParentMenu.listDetails.filter((f: { mstcode: any; }) => f.mstcode === res.parentMenuCode.toString())[0].mstcode : "";

        this.ddlparent = res.ddlParentMenu.listDetails.filter((f: { mstcode: string; }) => f.mstcode !== "2");

        this.statusText = res.menuCode === "" || res.menuCode === "0" ?
          res.ddlStatus.listDetails.filter((f: { mstcode: string; }) => f.mstcode === "1")[0].mstText :
          res.ddlStatus.listDetails.filter((f: { mstcode: any; }) =>
            f.mstcode === (res.isActive === true ? "1" : "0"))[0].mstText;

        this.ddlStatus = res.ddlStatus.listDetails.filter((f: { mstcode: string; }) => f.mstcode !== "2");

        this.groupedDll = res.parentMenuData.map(x => x.parentMenuName).filter((parentMenuName, index, arr) =>
          arr.indexOf(parentMenuName) == index).sort();

        // this.ddlparent = res.parentMenuData.map(x => x.parentMenuName).filter((parentMenuName, index, arr) =>
        //   arr.indexOf(parentMenuName) == index).sort();

        var data: groupMenuddl[] = new Array;
        this.groupedDll.forEach((element: any) => {
          var a = new groupMenuddl();
          a.name = (element === null ? "Parent Menu" : element);
          a.submenuArray = res.parentMenuData.filter(f => f.parentMenuName === element);
          try {
            data.push(a);
          }
          catch (catchError) {
          }

        });

        this.groupedDll = data;

        //this.parentMenuText = res.ddlParentMenu.listDetails.filter(f => f.mstcode === res.parentMenuCode)
      },
      err => { return false; });

  }

  Save() {


    // this.groupedDll = JSON.parse('[{"name":"Attendance Related","submenuArray":[{"menuType":"MST","parentMenuCode":23,"parentMenuName":"Attendance Related","menuCode":61,"menuName":"Shift Groups","menuSeq":1,"isAssigned":0},{"menuType":"MST","parentMenuCode":23,"parentMenuName":"Attendance Related","menuCode":62,"menuName":"Shift Details","menuSeq":2,"isAssigned":0},{"menuType":"MST","parentMenuCode":23,"parentMenuName":"Attendance Related","menuCode":63,"menuName":"Leave Types","menuSeq":3,"isAssigned":0},{"menuType":"MST","parentMenuCode":23,"parentMenuName":"Attendance Related","menuCode":64,"menuName":"Calender Year","menuSeq":4,"isAssigned":0},{"menuType":"MST","parentMenuCode":23,"parentMenuName":"Attendance Related","menuCode":65,"menuName":"Holiday List","menuSeq":5,"isAssigned":0}]},{"name":"Card Type Details","submenuArray":[{"menuType":"MST","parentMenuCode":16,"parentMenuName":"Card Type Details","menuCode":31,"menuName":"Card Type","menuSeq":1,"isAssigned":0},{"menuType":"MST","parentMenuCode":16,"parentMenuName":"Card Type Details","menuCode":32,"menuName":"Area of Movement","menuSeq":2,"isAssigned":0},{"menuType":"MST","parentMenuCode":16,"parentMenuName":"Card Type Details","menuCode":33,"menuName":"Gates","menuSeq":3,"isAssigned":0},{"menuType":"MST","parentMenuCode":16,"parentMenuName":"Card Type Details","menuCode":34,"menuName":"Card Category","menuSeq":4,"isAssigned":0},{"menuType":"MST","parentMenuCode":16,"parentMenuName":"Card Type Details","menuCode":35,"menuName":"Activities","menuSeq":5,"isAssigned":0}]},{"name":"Contractor Details","submenuArray":[{"menuType":"MST","parentMenuCode":18,"parentMenuName":"Contractor Details","menuCode":36,"menuName":"Vendor","menuSeq":1,"isAssigned":0},{"menuType":"MST","parentMenuCode":18,"parentMenuName":"Contractor Details","menuCode":37,"menuName":"Vendor Licences","menuSeq":2,"isAssigned":0},{"menuType":"MST","parentMenuCode":18,"parentMenuName":"Contractor Details","menuCode":38,"menuName":"WC Policy","menuSeq":3,"isAssigned":0},{"menuType":"MST","parentMenuCode":18,"parentMenuName":"Contractor Details","menuCode":39,"menuName":"Work Orders","menuSeq":4,"isAssigned":0},{"menuType":"MST","parentMenuCode":18,"parentMenuName":"Contractor Details","menuCode":40,"menuName":"WO Types","menuSeq":5,"isAssigned":0}]},{"name":"Location Details","submenuArray":[{"menuType":"MST","parentMenuCode":20,"parentMenuName":"Location Details","menuCode":46,"menuName":"Jio Locations","menuSeq":1,"isAssigned":0},{"menuType":"MST","parentMenuCode":20,"parentMenuName":"Location Details","menuCode":47,"menuName":"Location Type","menuSeq":2,"isAssigned":0},{"menuType":"MST","parentMenuCode":20,"parentMenuName":"Location Details","menuCode":48,"menuName":"Region","menuSeq":3,"isAssigned":0},{"menuType":"MST","parentMenuCode":20,"parentMenuName":"Location Details","menuCode":49,"menuName":"State","menuSeq":4,"isAssigned":0},{"menuType":"MST","parentMenuCode":20,"parentMenuName":"Location Details","menuCode":50,"menuName":"Geo. Locations","menuSeq":5,"isAssigned":0}]},{"name":"Logs","submenuArray":[{"menuType":"MST","parentMenuCode":24,"parentMenuName":"Logs","menuCode":66,"menuName":"Integration Logs","menuSeq":1,"isAssigned":0},{"menuType":"MST","parentMenuCode":24,"parentMenuName":"Logs","menuCode":67,"menuName":"Data History Logs","menuSeq":2,"isAssigned":0},{"menuType":"MST","parentMenuCode":24,"parentMenuName":"Logs","menuCode":68,"menuName":"Central Schedulled Tasks Logs","menuSeq":4,"isAssigned":0},{"menuType":"MST","parentMenuCode":24,"parentMenuName":"Logs","menuCode":69,"menuName":"User Login Logs","menuSeq":5,"isAssigned":0},{"menuType":"MST","parentMenuCode":24,"parentMenuName":"Logs","menuCode":70,"menuName":"Central User Login Logs","menuSeq":6,"isAssigned":0}]},{"name":"Others","submenuArray":[{"menuType":"REP","parentMenuCode":25,"parentMenuName":"Others","menuCode":51,"menuName":"Bank List","menuSeq":1,"isAssigned":0},{"menuType":"REP","parentMenuCode":25,"parentMenuName":"Others","menuCode":52,"menuName":"Remarks List","menuSeq":2,"isAssigned":0}]},{"name":"Refrence Masters","submenuArray":[{"menuType":"MST","parentMenuCode":19,"parentMenuName":"Refrence Masters","menuCode":41,"menuName":"Qualification","menuSeq":1,"isAssigned":0},{"menuType":"MST","parentMenuCode":19,"parentMenuName":"Refrence Masters","menuCode":42,"menuName":"ID Proof Type","menuSeq":2,"isAssigned":0},{"menuType":"MST","parentMenuCode":19,"parentMenuName":"Refrence Masters","menuCode":43,"menuName":"Religion","menuSeq":3,"isAssigned":0},{"menuType":"MST","parentMenuCode":19,"parentMenuName":"Refrence Masters","menuCode":44,"menuName":"Caste","menuSeq":4,"isAssigned":0},{"menuType":"MST","parentMenuCode":19,"parentMenuName":"Refrence Masters","menuCode":45,"menuName":"Sub Caste","menuSeq":5,"isAssigned":0}]},{"name":"SPDT Mappings","submenuArray":[{"menuType":"MST","parentMenuCode":15,"parentMenuName":"SPDT Mappings","menuCode":26,"menuName":"Sector","menuSeq":1,"isAssigned":0},{"menuType":"MST","parentMenuCode":15,"parentMenuName":"SPDT Mappings","menuCode":27,"menuName":"Plant","menuSeq":2,"isAssigned":0},{"menuType":"MST","parentMenuCode":15,"parentMenuName":"SPDT Mappings","menuCode":28,"menuName":"Department","menuSeq":3,"isAssigned":0},{"menuType":"MST","parentMenuCode":15,"parentMenuName":"SPDT Mappings","menuCode":29,"menuName":"Trade","menuSeq":4,"isAssigned":0},{"menuType":"MST","parentMenuCode":15,"parentMenuName":"SPDT Mappings","menuCode":30,"menuName":"Work Skill ","menuSeq":5,"isAssigned":0}]}]');
    console.log(this.groupedDll);
    if (this.setValidate() === false) {
      var request = JSON.parse(JSON.stringify(this.searchRequester.ucObj));

      this.menuDetails.requestedBy = this.shared.userCode;
      this.menuDetails.objRequest = request;

      this.menuService.saveMenuMasterModel(this.menuDetails).subscribe(
        res => {
          this.msgSave = res.message;
        },
        err => {

        }
      );
    }

  }

  selectedCars: any;


  SetParents(data: any) {
    if (data === 0) {
      data = data.toString();
    }
    else {
      data = data.menuCode;
    }

    this.menuDetails.parentMenuName = this.ddlparent.filter((f: { mstcode: any; }) => f.mstcode === data.toString())[0].mstText;

    this.menuDetails.parentMenuCode = this.ddlparent.filter((f: { mstcode: any; }) => f.mstcode === data.toString())[0].mstcode.toString();

    this.selectedCars = JSON.stringify(data);
  }

  Back() {
    this.searchRequester.stateElement = null;
    this.router.navigateByUrl('MstUsers', { state: this.searchRequester });
  }


  //#region 

  ddlparent: dropDownDetail[] = new Array;
  ddlStatus: mstDetails[] = new Array;
  parentddlVisible: boolean = false;
  ParentMenuName: string = "";
  ParentMenuDropDownToggle() {
    this.parentddlVisible = !this.parentddlVisible;
  }

  setParent(data: any) {
    // this.menuDetails.parentMenuCode = data.mstcode;
    // this.ParentMenuName = data.mstText;
    this.menuDetails.parentMenuName = data.mstText;
    this.menuDetails.parentMenuCode = data.mstcode;
    this.parentddlVisible = false;
  }

  //#endregion

  statusDropDownVisible: boolean = false;
  statusIsDirty: boolean = false;
  statusText: string = "";
  statusDropDownToggle() {
    this.statusDropDownVisible = !this.statusDropDownVisible;
  }

  Statusset(data: any) {
    this.statusText = data.mstText;
    this.menuDetails.IsActive = data.mstcode === "1" ? true : false;
    this.statusDropDownVisible = false;
    this.statusIsDirty = true;
  }

  Clear() {
    this.menuDetails.parentMenuName = "";
    this.statusText = this.ddlStatus.filter((f: { mstcode: string; }) => f.mstcode === "1")[0].mstText;

    this.menuDetails.menuCode = "";
    this.menuDetails.menuName = "";
    this.menuDetails.parentMenuCode = "";
    this.menuDetails.menuLink = "";
    this.menuDetails.menuImage = "";
    this.menuDetails.menuSeq = "";
    this.menuDetails.pageHeader = "";
    this.menuDetails.pageCode = "";
    this.menuDetails.pageLink = "";
    this.menuDetails.IsActive = true;
    this.isValidate = false;

  }

  setValidate(): boolean {
    this.isValidate = false;

    this.isValidate = this.validationTest.requiredValidatorByString(this.menuDetails.menuName.length > 0 ? '1' : '').length > 0 ? true : this.isValidate;
    this.isValidate = this.validationTest.requiredValidatorByString(this.menuDetails.parentMenuCode.length > 0 ? '1' : '').length > 0 ? true : this.isValidate;
    this.isValidate = this.validationTest.requiredValidatorByString(this.menuDetails.menuLink.length > 0 ? '1' : '').length > 0 ? true : this.isValidate;
    this.isValidate = this.validationTest.requiredValidatorByString(this.menuDetails.menuSeq.length > 0 ? '1' : '').length > 0 ? true : this.isValidate;
    this.isValidate = this.validationTest.requiredValidatorByString(this.menuDetails.pageHeader.length > 0 ? '1' : '').length > 0 ? true : this.isValidate;
    this.isValidate = this.validationTest.requiredValidatorByString(this.menuDetails.pageCode.length > 0 ? '1' : '').length > 0 ? true : this.isValidate;
    this.isValidate = this.validationTest.requiredValidatorByString(this.menuDetails.pageLink.length > 0 ? '1' : '').length > 0 ? true : this.isValidate;
    return this.isValidate;
  }




}

