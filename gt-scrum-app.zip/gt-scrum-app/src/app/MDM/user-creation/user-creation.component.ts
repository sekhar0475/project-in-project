import { Component, OnInit, NgModule, ViewChild } from '@angular/core';
import { UserCreationService } from '../../Services/user-creation.service';
import { dropDownDetail } from '../../Model/CcModel/dropDownDetail';
import { BrowserModule } from '@angular/platform-browser';
import { UserCreation } from '../../Model/MDMModel/user-creation';
import { requestDetail } from '../../Model/CCModel/requestDetail';
import { Observable } from 'rxjs';
import { stringify } from 'querystring';
import { FormControl, FormGroup, ReactiveFormsModule, FormsModule } from '@angular/forms';
import { NgSelectModule, NgOption } from '@ng-select/ng-select';
import { isNullOrUndefined } from 'util';
import { Router } from '@angular/router';
import { userRoledetails } from 'src/app/Model/UcModel/roleDetail';
import { validationTest } from 'src/app/validationTest';
import { SharedState, searchRequester } from 'src/app/Model/Common/InterPage';
import { MdmService } from 'src/app/Services/mdm.service';
import { mstCollection } from 'src/app/Model/CcModel/mstCollection';

@Component({
  selector: 'app-user-creation',
  templateUrl: './user-creation.component.html',
  styleUrls: ['./user-creation.component.css']
})
export class UserCreationComponent implements OnInit {

  //#region Parameters
  shared: SharedState = new SharedState();
  msgVisible: false;
  msgSave: string = "";
  UCObj: requestDetail = new requestDetail();
  UserDetails: UserCreation = new UserCreation();
  btnGenerate: boolean = true;
  RoleRedirect: boolean = false;
  searchText: string;
  searchStatusText: string;
  isVisible: boolean = true;
  isVendor: number = 0;
  visibility: boolean = true;
  isValidate: boolean = false;
  userName: string;
  isSMS: boolean = false;
  searchRequester: searchRequester = new searchRequester();
  //#endregion

  //#region Dropdown Complete Set

  workDetailIsDirty: boolean = false;
  StatusIsDirty: boolean = false;

  isWordDetailsDropDownVisible: boolean = false;
  isStatusDropDownVisible: boolean = false;

  ddlContractor: mstCollection["listDetails"] = new Array;
  UserRoles: userRoledetails[];
  ddlStatus: mstCollection["listDetails"] = new Array;
  EICRoles: userRoledetails[];
  FetchedFromADServer: boolean = true;
  disableAfterCheck: boolean = false;
  ContractorName: string = "";
  Status: string = "";
  validationTest: validationTest = new validationTest();

  workDetailsDropDownToggle() { this.isWordDetailsDropDownVisible = !this.isWordDetailsDropDownVisible; }

  StatusDropDownToggle() { this.isStatusDropDownVisible = !this.isStatusDropDownVisible; }

  setWorkDetail(data: any) {
    this.UserDetails.ContractorCode = data.mstcode; this.ContractorName = data.mstText;
    this.isWordDetailsDropDownVisible = false; this.workDetailIsDirty = true;
  }

  setStatus(data: any) {
    this.UserDetails.IsActive = Number(data.mstcode); this.UserDetails.UserStatus = data.mstcode; this.Status = data.mstText; this.isStatusDropDownVisible = false; this.StatusIsDirty = true;
  }

  //#region Commented
  // getContractor(siteCode: string, resCode: string, Entity: string, RefID: string) {
  //   // this.ucs.getEntityInfo(siteCode, resCode, Entity, RefID).subscribe(
  //   //   res => { this.ddlContractor = res[0].listDetails; }, err => { });
  // }

  // getStatus(siteCode: string, resCode: string, Entity: string, RefID: string) {
  //   // this.ucs.getEntityInfo(siteCode, resCode, Entity, RefID).subscribe
  //   //   (
  //   //     res => {
  //   //       this.ddlStatus = res;

  //   //       if (res.length > 0) {
  //   //         if (res.filter(f => f.mstcode === "1").length > 0) {
  //   //           this.Status = res.filter(f => f.mstcode === "1")[0].mstText;
  //   //         }
  //   //       }
  //   //     }, err => { }
  //   //   );
  // }

  //#endregion

  getAndSetRoles(request: requestDetail) {
    // this.mdm.getData(request,"DataSet").subscribe(
    //   res => {
    //     this.UserRoles = res;
    //     this.EICRoles = res.filter(f => f.roleAssigned === 1)
    //   }, err => { });
  }

  //#endregion

  //#region ABVS DropDown

  get isActiveBool() { return this.UserDetails.IsABVS == 1 }

  set isActiveBool(newValue: boolean) { this.UserDetails.IsABVS = newValue ? 1 : 0 }

  get isVendorBool() { return this.UserDetails.IsVendor == 1 }

  set isVendorBool(newValue: boolean) { this.UserDetails.IsVendor = newValue ? 1 : 0 }

  get isLockBool() { return this.UserDetails.IsLocked == 1 }

  set isLockBool(newValue: boolean) { this.UserDetails.IsLocked = newValue ? 1 : 0 }

  //#endregion

  constructor(private ucs: UserCreationService, private mdm: MdmService, private router: Router) {

  }

  ClickEdit(element: any) {
    this.searchRequester.stateElement = this.UserDetails;
    this.router.navigateByUrl('userroles', { state: this.searchRequester });
  }

  ngOnInit() {

    //#region PreLoad Validate page for correct request
    if (!window.history.state.hasOwnProperty('stateElement')) {
      this.router.navigateByUrl('searchlist', { state: null });
    }
    //#endregion

    this.searchRequester = window.history.state;

    if (this.searchRequester.stateElement.hasOwnProperty('userCode_0')) {
      this.UserDetails.Code = this.searchRequester.stateElement.userCode_0;
    }
    else if (this.searchRequester.stateElement.hasOwnProperty('Code')) {
      this.UserDetails.Code = this.searchRequester.stateElement.Code;
    }

    this.shared = JSON.parse(atob(localStorage.getItem('shared')));

    this.userName = this.shared.userName;

    this.UCObj.RequestID = ""; this.UCObj.resCode = "2"; this.UCObj.siteCode = this.shared.siteCode;

    this.UCObj.resCode = "1"; this.UCObj.RequestID = "1|" + this.UserDetails.Code + "|" + this.shared.roleCode + "|1";
    //this.getAndSetRoles(this.UCObj);

    if (this.UserDetails.Code > 0) {
      this.Fetch(this.UserDetails.Code);
    } else {
      this.Fetch(0); this.checkVisibility("User");
    }
  }

  generateFlag: boolean = false;

  getUseridPassword() {
    this.generateFlag = true;
    this.UCObj.siteCode = this.shared.siteCode;
    this.UCObj.resCode = "10";
    this.UCObj.RequestID = "STRING|" + this.shared.userCode + "|" + this.UCObj.siteCode + "|" + this.UserDetails.ContractorCode;

    this.mdm.getAutoGenerateDetails(this.UCObj).subscribe
      (
        res => {
          this.UserDetails.userID = res.code; this.UserDetails.loginID = res.code;
          this.UserDetails.pwd = res.message; this.UserDetails.status = res.status;
          this.UserDetails.Code = 0;
          this.generateFlag = false;
        },
        err => {
          this.generateFlag = false;
        }
      );
    this.btnGenerate = false;
    this.isValidate = this.validationTest.requiredValidatorByString(this.UserDetails.userID).length > 0 ? true : this.isValidate;
  }

  eicRoles: string = "";
  validate() {
    this.eicRoles = this.EICRoles.length > 0 ? "1" : "";

  }

  Fetch(param: number) {
    this.msgSave = "";

    var request = JSON.parse(JSON.stringify(this.searchRequester.ucObj));
    request.roleCode = this.shared.roleCode;

    //#region Request Object generate
    if (param > 0) { request.RequestID = " |" + param; }
    else { request.RequestID = this.UserDetails.loginID + "|0"; }
    //#endregion

    this.mdm.getUserModel(request).subscribe
      (
        res => {

          this.UserRoles = res.roles.filter(f => f.roleCode !== 2);
          //     this.EICRoles = res.filter(f => f.roleAssigned === 1)
          this.EICRoles = res.roles.filter(f => f.roleAssigned === 1);

          if (!isNullOrUndefined(res)) {
            this.UserDetails.ContractorCode = res.contractorCode === null ? 0 : res.contractorCode;
            this.Status = res.status.listDetails.find(item => item.mstcode === (res.isActive === true ? "1" : "0")).mstText;

            this.ddlStatus = res.status.listDetails.filter(f => f.mstcode !== "2");

            this.ddlContractor = res.contractorcode.listDetails;
          }

          if (isNullOrUndefined(res) === false && res.code > 0) {
            //#region Edit Data Load.
            this.UserDetails.Code = parseInt(res.code);
            this.UserDetails.loginID = res.loginID;
            this.UserDetails.userName = res.userName;
            this.UserDetails.userID = res.userID;
            this.UserDetails.pwd = res.pwd;
            this.UserDetails.mobileNo = res.mobileNo;
            this.UserDetails.eMailID = res.eMailID;
            this.UserDetails.reportingID = res.reportingID;
            this.UserDetails.reportingLoginID = res.reportingLoginID;
            this.UserDetails.reportingName = res.reportingName;
            this.UserDetails.reportingEmailID = res.reportingEmailID;
            this.UserDetails.IsVendor = res.isVendor === true ? 1 : 0; // parseInt(res.isVendor);
            this.UserDetails.IsABVS = parseInt(res.isABVS);
            this.UserDetails.IsActive = res.isActive; this.UserDetails.UserStatus = res.isActive;
            this.UserDetails.IsLocked = res.isLocked; this.isLockBool = res.isLocked;

            //this.FetchedFromADServer = false;
            if (this.UserDetails.IsVendor == 1) {
              this.isVisible = false; this.isVendor = 1; this.ContractorName = res.contractorName;
            }
            else { this.isVisible = true; this.isVendor = 0; }

            if (this.UserDetails.IsVendor == 1 || this.UserDetails.IsABVS == 1) { this.UserDetails.pwd = res.pwd; }
            else { this.UserDetails.pwd = ""; }

            if (this.UserDetails.Code > 0 && isNullOrUndefined(this.UserDetails.userID) === false) { this.RoleRedirect = true; } else { this.RoleRedirect = false; }

            //#endregion
          }
          else {
            //#region Insert Data Set

            //#region Reset Data before Fetch By Domain
            this.UserDetails.Code = 0;
            this.UserDetails.userName = "";
            this.UserDetails.userID = "";
            this.UserDetails.pwd = "";
            this.UserDetails.mobileNo = "";
            this.UserDetails.eMailID = "";
            this.UserDetails.reportingID = "";
            this.UserDetails.reportingLoginID = "";
            this.UserDetails.reportingName = "";
            this.UserDetails.reportingEmailID = "";
            this.UserDetails.IsVendor = 0;
            this.UserDetails.IsABVS = 0;
            this.UserDetails.ContractorCode = 0;
            this.UserDetails.IsActive = 0;
            this.UserDetails.CreatedBy = "0";
            this.UserDetails.status = 0;
            this.UserDetails.UserStatus = "";
            this.UCObj.RequestID = this.UserDetails.loginID;
            //this.FetchedFromADServer = false;
            //#endregion

            if (param === 0 && !isNullOrUndefined(this.UserDetails.loginID) && this.UserDetails.loginID !== "") {
              this.msgSave = "No data found.";
              // this.mdm.FetchByDomain(this.UCObj).subscribe
              //   (
              //     res1 => {
              //       if (!isNullOrUndefined(res1) && !isNullOrUndefined(res1.userID) && res1.userID !== "") {
              //         //#region Assign res1 Data
              //         this.UserDetails.mobileNo = res1.mobileNo;
              //         this.UserDetails.userName = res1.userName;
              //         this.UserDetails.userID = res1.userID;
              //         this.UserDetails.eMailID = res1.eMailID;
              //         this.UserDetails.reportingID = res1.reportingID;
              //         this.UserDetails.reportingLoginID = res1.reportingLoginID;
              //         this.UserDetails.reportingName = res1.reportingName;
              //         this.UserDetails.reportingEmailID = res1.reportingEmailID;
              //         //this.FetchedFromADServer = true;
              //         //#endregion
              //       }
              //       else { this.msgSave = "Invalid domain ID."; }
              //     },
              //     err1 => { }
              //   );
            }

            //#endregion
          }
        },
        err => { }
      );
  }

  fetchbyDomain() {

    //this.Fetch(0);

    var request = JSON.parse(JSON.stringify(this.searchRequester.ucObj));
    request.roleCode = this.shared.roleCode;

    request.RequestID = this.UserDetails.loginID;

    this.mdm.FetchByDomain(request).subscribe
      (
        res1 => {
          if (!isNullOrUndefined(res1) && !isNullOrUndefined(res1.userID)) {
            // this.disableAfterCheck = true;
            //#region Assign res1 Data
            // this.UserDetails.mobileNo = res1.mobileNo;
            // this.UserDetails.userName = res1.userName;
            // this.UserDetails.userID = res1.userID;
            // this.UserDetails.eMailID = res1.eMailID;
            // this.UserDetails.reportingID = res1.reportingID;
            // this.UserDetails.reportingLoginID = res1.reportingLoginID;
            // this.UserDetails.reportingName = res1.reportingName;
            // this.UserDetails.reportingEmailID = res1.reportingEmailID;
            // this.FetchedFromADServer = true;
            // this.disableAfterCheck = true;

            this.UserDetails.Code = parseInt(res1.code);
            this.UserDetails.loginID = res1.loginID;
            this.UserDetails.userName = res1.userName;
            this.UserDetails.userID = res1.userID;
            this.UserDetails.pwd = res1.pwd;
            this.UserDetails.mobileNo = res1.mobileNo;
            this.UserDetails.eMailID = res1.eMailID;
            this.UserDetails.reportingID = res1.reportingID;
            this.UserDetails.reportingLoginID = res1.reportingLoginID;
            this.UserDetails.reportingName = res1.reportingName;
            this.UserDetails.reportingEmailID = res1.reportingEmailID;
            this.UserDetails.IsVendor = res1.isVendor === true ? 1 : 0; // parseInt(res.isVendor);
            this.UserDetails.IsABVS = parseInt(res1.isABVS);
            this.UserDetails.IsActive = res1.isActive; this.UserDetails.UserStatus = res1.isActive;
            this.UserDetails.IsLocked = res1.isLocked; this.isLockBool = res1.isLocked;

            if (this.UserDetails.Code > 0 && isNullOrUndefined(this.UserDetails.userID) === false) { this.RoleRedirect = true; } else { this.RoleRedirect = false; }
            //#endregion
          }
          else { this.msgSave = "Invalid domain ID."; }
        },
        err1 => { }
      );
  }

  ClearForPostEdit() {
    var user = this.UserDetails.loginID;
    //if (this.FetchedFromADServer) {
    this.msgSave = "";
    this.UserDetails.Code = 0;
    this.UserDetails.userName = "";
    this.UserDetails.userID = "";
    this.UserDetails.pwd = "";
    this.UserDetails.mobileNo = "";
    this.UserDetails.eMailID = "";
    this.isValidate = false;
    this.UserDetails.reportingID = "";
    this.UserDetails.reportingLoginID = "";
    this.UserDetails.reportingName = "";
    this.UserDetails.reportingEmailID = "";
    this.UserDetails.IsVendor = 0;
    this.UserDetails.IsABVS = 0;
    this.UserDetails.ContractorCode = 0;
    this.UserDetails.IsActive = 0;
    this.UserDetails.CreatedBy = "0";
    this.UserDetails.status = 0;
    this.UserDetails.UserStatus = "";
    // this.FetchedFromADServer = false;

    if (this.UserDetails.Code > 0) {
      this.RoleRedirect = true;
    }
    else {
      this.RoleRedirect = false;
    }
    this.UserDetails.loginID = user;
    //}
  }

  ngAfterViewInit() {
    if (this.UserDetails.IsVendor === 1 || this.UserDetails.IsVendor === 1) {
      this.isVisible = false; this.isVendor = 1;
    }
    else {
      this.isVisible = true; this.isVendor = 0;
    }
  }

  Clear() {
    this.msgSave = "";
    this.FetchedFromADServer = false;
    this.disableAfterCheck = false;
    this.UserDetails.Code = 0;
    this.UserDetails.userName = "";
    this.UserDetails.userID = "";
    this.UserDetails.pwd = "";
    this.UserDetails.mobileNo = "";
    this.UserDetails.eMailID = "";
    this.UserDetails.loginID = "";
    this.isValidate = false;
    this.UserDetails.reportingID = "";
    this.UserDetails.reportingLoginID = "";
    this.UserDetails.reportingName = "";
    this.UserDetails.reportingEmailID = "";
    this.UserDetails.IsVendor = 0;
    this.UserDetails.IsABVS = 0;
    this.UserDetails.ContractorCode = 0;
    this.UserDetails.IsActive = 0;
    this.UserDetails.CreatedBy = "0";
    this.UserDetails.status = 0;
    this.UserDetails.UserStatus = "";
    //this.FetchedFromADServer = false;

    if (this.UserDetails.Code > 0) {
      this.RoleRedirect = true;
    }
    else {
      this.RoleRedirect = false;
    }
  }

  RILValidate() {
    this.isValidate = this.validationTest.requiredValidatorByString(this.UserDetails.loginID).length > 0 ? true : this.isValidate;

    if (this.isValidate === false) {
      this.isValidate = this.validationTest.requiredValidatorByString(this.UserDetails.userID).length > 0 ? true : this.isValidate;
    }

    if (this.isValidate === false) {
      this.isValidate = this.validationTest.requiredValidatorByString(this.UserDetails.userName).length > 0 ? true : this.isValidate;
    }

    if (this.isValidate === false) {
      this.isValidate = this.validationTest.requiredValidatorByString(this.UserDetails.mobileNo).length > 0 ? true : this.isValidate;
    }

    if (this.isValidate === false) {
      this.isValidate = this.validationTest.requiredValidatorByString(this.UserDetails.eMailID).length > 0 ? true : this.isValidate;
    }

    if (this.isValidate === false) {
      this.isValidate = this.validationTest.requiredValidatorByString(this.UserDetails.reportingName).length > 0 ? true : this.isValidate;
    }

    if (this.isValidate === false) {
      this.isValidate = this.validationTest.requiredValidatorByString(this.UserDetails.reportingID).length > 0 ? true : this.isValidate;
    }

    if (this.isValidate === false) {
      this.isValidate = this.validationTest.requiredValidatorByString(this.UserDetails.reportingEmailID).length > 0 ? true : this.isValidate;
    }
  }

  VendorValidate() {
    this.isValidate = this.validationTest.requiredValidatorByString(this.ContractorName).length > 0 ? true : this.isValidate;

    if (this.isValidate === false) {
      this.isValidate = this.EICRoles.length === 0 ? true : this.isValidate;
    }

    if (this.isValidate === false) {
      this.isValidate = this.validationTest.requiredValidatorByString(this.UserDetails.userID).length > 0 ? true : this.isValidate;
    }

    if (this.isValidate === false) {
      this.isValidate = this.validationTest.requiredValidatorByString(this.UserDetails.pwd).length > 0 ? true : this.isValidate;
    }

    if (this.isValidate === false) {
      this.isValidate = this.validationTest.requiredValidatorByString(this.UserDetails.eMailID).length > 0 ? true : this.isValidate;
    }
  }

  Save() {
    this.msgSave = "";
    this.isValidate = false;

    if (!isNullOrUndefined(this.EICRoles)) {
      this.UserDetails.IsABVS = this.EICRoles.filter(f => f.roleAbbre === "ABVS").length > 0 ? 1 : 0;
      this.UserDetails.IsVendor = this.EICRoles.filter(f => f.roleAbbre === "VEN").length > 0 ? 1 : 0;
    }
    else {
      this.UserDetails.IsABVS = 0; this.UserDetails.IsVendor = 0;
    }

    if (this.isVisible === true) {
      this.RILValidate();
    }
    else {
      this.VendorValidate();
    }

    if (this.isValidate === false) {
      this.UserDetails.userID;
      this.UCObj.resCode = "2";
      this.UCObj.siteCode = this.shared.siteCode;
      this.UCObj.RequestID = this.UserDetails.loginID;
      this.UserDetails.RequestDetails = this.UCObj;

      this.UserDetails.IsActive = this.isVisible === true ? 1 : this.UserDetails.IsActive;
      var Data = JSON.parse(JSON.stringify(this.UserDetails));
      Data.contractorcode = null;
      Data.status = null;
      var userModel = JSON.parse(JSON.stringify(this.UserDetails)); userModel.status = null;
      this.mdm.saveUserModel(userModel).subscribe
        (
          res => {
            this.UserDetails.Code = parseInt(res.status);
            this.msgSave = res.message;
            if (res.code == 0) {
              this.RoleRedirect = true;
            }
            else {
              this.RoleRedirect = false;
            }
          },
          err => { }
        );
    }
  }

  checkVisibility(userType: string) {
    this.Clear();

    if (userType == "Vendor") {
      this.isVisible = false;
      this.isVendor = 1;
    }
    else {
      this.isVisible = true;
      this.isVendor = 0;
    }
  }

  UnlockUser() {
    this.msgSave = "";
    this.UCObj.resCode = "0";
    this.UCObj.siteCode = this.shared.siteCode;
    this.UCObj.RequestID = this.UserDetails.Code + "|" + this.UserDetails.loginID + "|0|1";
    this.mdm.getData(this.UCObj, "userEditSearch").subscribe(
      res => {
        if (res.code === "0") { this.msgSave = res.message; this.isLockBool = false; }
        else { this.msgSave = "Failed to unlock User!!!"; }

      }, err => { });
  }

  Back() {
    this.Clear();
    this.searchRequester.stateElement = this.UserDetails;
    this.searchRequester.ucObj.RequestID = "1|@SEARCHTEXT|@USERCODE|@ROLECODE|@STATUS";
    this.router.navigateByUrl('MstUsers', { state: this.searchRequester });
  }

  dashboard() {
    if (this.shared.siteUiCode == 'RR') {
      this.router.navigateByUrl('dashboard', { skipLocationChange: true });
    }
    else if (this.shared.siteUiCode == 'HC') {
      this.router.navigateByUrl('dashboardhydrocarbon', { skipLocationChange: true });
    }
    else {
      this.router.navigateByUrl('dashboardretail', { skipLocationChange: true });
    }
  }
}
