import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'objectFilter'
})
export class ObjectFilterPipe implements PipeTransform {

  transform(items: Array<any>, objectFilter: {[key:string]:any}): Array<any> {
    return items.filter(item => {
      let notMatchingField = Object.keys(objectFilter).find(
        k=> item[k]!==objectFilter[k]
      );
      return !notMatchingField;
    });
    return null;
  }

}
