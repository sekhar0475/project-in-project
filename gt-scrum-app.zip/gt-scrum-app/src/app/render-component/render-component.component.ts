import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-render-component',
  templateUrl: './render-component.component.html',
  styleUrls: ['./render-component.component.css']
})
export class RenderComponentComponent implements OnInit {

  constructor(private router : Router) { }

  ngOnInit() {
    // this.router.navigateByUrl("/cardcreation");
  }

}
