import { Injectable } from '@angular/core';
import { Observable, of, observable } from 'rxjs';
import { HttpClientModule, HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { apiURL, httpOptions } from './httpConstant';
import { siteDetail } from '../Model/UcModel/siteDetail';
import { tap, catchError } from 'rxjs/operators';

@Injectable({
  providedIn:'root'
})

export class loginDetailService {

  messageService: string[] = [];

  constructor(private httpClient: HttpClient){}

  loginSiteConfiguration() : Observable<siteDetail>{
    return this.httpClient.post(apiURL + '/UC/LoginSiteConfiguration', JSON.stringify(''), httpOptions).pipe(
      tap(res => this.log('inside cc services')), catchError(this.handleError<any>('GetUserID', [])))
  }

  private log(message: string) {
    this.messageService.push("a");
  }

  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {

      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead

      // TODO: better job of transforming error for user consumption
      console.log(`${operation} failed: ${error.message}`);

      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }

}
