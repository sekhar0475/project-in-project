import { TestBed } from '@angular/core/testing';

import { CardcreationService } from './cardcreation.service';

describe('CardcreationService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CardcreationService = TestBed.get(CardcreationService);
    expect(service).toBeTruthy();
  });
});
