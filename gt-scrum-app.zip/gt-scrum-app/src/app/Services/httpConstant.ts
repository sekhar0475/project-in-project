import { HttpClientModule, HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';

export const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json'
  })
};

// For Production Environment
export const apiURL = 'http://scrumdvapp.ril.com';
export const mdmURL = 'http://scrumdvapp.ril.com';
export const apiMenuURL = 'http://scrumdvapp.ril.com';
export const loginServiceURL = 'http://scrumdvapp.ril.com/UC/';

// For Local Debugging
// export const apiURL = 'http://localhost:5423';
// export const mdmURL = 'http://localhost:5423';
// export const apiMenuURL = 'http://localhost:5423';
// export const loginServiceURL = 'http://localhost:5423/values/';

export enum ControllerInfo {
  // userEdit = "1|@SEARCHTEXT|@USERCODE|@ROLECODE|@STATUS",
  userEdit = "getSearchModel",
  userEditSearch = "DataTable",
  GRP9USERLISTAdd = "getUserModel",
  // GRP9USERLISTSave = "saveUserModel",
  DataSet = "DataSet",
  roleEdit = "getSearchModel",
  roleEditSearch = "DataTable",
  menuEdit = "getSearchModel",
  menuEditSearch = "DataTable",
  siteconfig = "SC||1",
  sitefield = "SFC|0|@STATUS",
  SitefieldEdit = "SFEC|0|@STATUS",
  SiteAppConfig = "SFAC|0|@STATUS"

}
