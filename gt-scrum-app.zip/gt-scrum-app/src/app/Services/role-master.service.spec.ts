import { TestBed } from '@angular/core/testing';

import { RoleMasterService } from './role-master.service';

describe('RoleMasterService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: RoleMasterService = TestBed.get(RoleMasterService);
    expect(service).toBeTruthy();
  });
});
