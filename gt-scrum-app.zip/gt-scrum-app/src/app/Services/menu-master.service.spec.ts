import { TestBed } from '@angular/core/testing';

import { MenuMasterService } from './menu-master.service';

describe('MenuMasterService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: MenuMasterService = TestBed.get(MenuMasterService);
    expect(service).toBeTruthy();
  });
});
