import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SharedServiceService {

  selectedSiteUICode : string;

  public siteUICode = new BehaviorSubject<string>('');
  public selectedRoleCode = new BehaviorSubject<string>('');
  currentMessage = this.siteUICode.asObservable();

  constructor() { }
  changeSiteUICode(siteUICode: string) {
    this.siteUICode.next(siteUICode)
  }

  changeSiteRoleCode(siteRoleCode: string) {
    this.selectedRoleCode.next(siteRoleCode)
  }

  getsiteUICode() : string {
    this.currentMessage.subscribe(message => this.selectedSiteUICode = message);
    return this.selectedSiteUICode;
  }

}
