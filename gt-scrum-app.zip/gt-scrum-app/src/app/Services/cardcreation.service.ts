import { Injectable } from '@angular/core';
import { Observable, of, observable } from 'rxjs';
import { HttpClientModule,HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { analyzeAndValidateNgModules } from '@angular/compiler';
import { map, tap, catchError } from "rxjs/operators";
import {httpOptions} from '../Services/httpConstant';
import {otherDetail} from '../Model/CcModel/otherDetail';
import {personalInfo} from '../Model/CcModel/personalInfo';
import {apiURL} from '../Services/httpConstant';
import { address } from '../Model/CcModel/address';
import { HostListener } from '@angular/core';
import { workDetail } from '../Model/CcModel/workDetail';

@Injectable({
  providedIn: 'root'
})
export class CardcreationService {
  //apiURL: string = 'http://scrumdvapp.ril.com/CC/';
  //apiURLLocal: string = 'http://localhost:5423/CC/';
  apiURL = apiURL+'/CC/';
  messageService :string []=[];
  Sitecode : string ;
  udetails : any;

  constructor(private httpClient:HttpClient) {
    window.onbeforeunload = function() { console.log('back button browser clicked'); }
    //this.Sitecode = localStorage.getItem('shared');
    this.udetails=  JSON.parse(atob(localStorage.getItem('shared')));
   }
  private log(message: string) {
    this.messageService.push("a");
  }
  getPersonalInformationConfiguration(resCode : string) : Observable<any>
  {
    return this.httpClient.post(this.apiURL+'GetPersonalInfo?strSiteCode='+  this.udetails.siteCode +'&rescode='+resCode+'&roleCode='+  this.udetails.siteCode +'',JSON.stringify(''),httpOptions).pipe(
      tap(
        res=>this.log('inside cc services')
      ),
      catchError(
        this.handleError<any>('cardCreation', []))
      )

  }

  // getCardCreationResourceDetails(search : string,status : string) : Observable<any>
  getCardCreationResourceDetails(selectedStatus : number) : Observable<any>
  {
    return this.httpClient.post(this.apiURL+'GetCardCreationResourceDetails?strSiteCode='+  this.udetails.siteCode +'&UserCode='+  this.udetails.userCode+'&UserRole='+  1 +'&search='+''+'&status='+ selectedStatus+'' ,JSON.stringify(''),httpOptions).pipe(
      tap(
        res=>this.log('inside cc services')
      ),
      catchError(
        this.handleError<any>('cardCreation', []))
      )

  }

  @HostListener('window:popstate', ['$event'])
  onPopState(event) {
    console.log('Back button pressed');
  }

  SavePersonalInformation(personalInfo:personalInfo) : Observable<any>
  {
    return this.httpClient.post(this.apiURL+'ResPersonalInfoUpdate',JSON.stringify(personalInfo),httpOptions).pipe(
      tap(
        res=>this.log('inside cc services')
      ),
      catchError(
        this.handleError<any>('cardCreation', []))
      )
  }

  getApprovalDataTable(resCode : string)
  {
return this.httpClient.post(this.apiURL+'ResApprovalsSelect?strSiteCode='+  this.udetails.siteCode +'&rescode='+ resCode + '',httpOptions).pipe(
  tap(
    res => this.log('inside get approval data table')
  ),
  catchError(
    this.handleError<any>('card creation',[])
  )
)
  }

  saveOtherDetail(otherDetail:otherDetail): Observable<any>
  {
    otherDetail.requestDetails.siteCode = this.udetails.siteCode ;
    return this.httpClient.post(this.apiURL+'SaveOtherDetails',JSON.stringify(otherDetail),httpOptions).pipe(
    tap(
      res=>this.log('')
    ),
    catchError(
      this.handleError<any>('save Other Detail',[])
    )
  )
  }

  getWorkDetailConfiguration(resCode : string) : Observable<any>
  {
    return this.httpClient.post(this.apiURL+'GetWorkInfo?strSiteCode='+  this.udetails.siteCode +'&rescode='+resCode+'&roleCode='+  this.udetails.siteCode +'',JSON.stringify(''),httpOptions).pipe(
      tap(
        res=>this.log('inside cc services')
      ),
      catchError(
        this.handleError<any>('cardCreation', []))
      )

  }
  SaveWorkDetails(workDetails: workDetail): Observable<any> {
    return this.httpClient.post(this.apiURL + 'ResWorkDetailsUpdate', JSON.stringify(workDetails), httpOptions).pipe(
      tap(
        res => this.log('inside cc services')
      ),
      catchError(
        this.handleError<any>('cardCreation', []))
    )
  }
  getAddressMapping(strSiteCode : string , Type : string ,address : address ) : Observable<any>
  {
    return this.httpClient.post(this.apiURL+'GetAddressMappingDetails?strSiteCode='+  this.udetails.siteCode +'&Type='+Type+'',JSON.stringify(address),httpOptions).pipe(
      tap(
        res=>this.log('inside cc services')
      ),
      catchError(
        this.handleError<any>('cardCreation', []))
      )
  }

  getEntityInfo(entity:string, refID : number) : Observable<any>
  {
    return this.httpClient.post(this.apiURL+'GetEntityInfo?strSiteCode='+  this.udetails.siteCode +'&rescode=2&Entity='+entity+'&RefID='+refID+'&TypeOff=LstMstObject',JSON.stringify(''),httpOptions).pipe(
      tap(
        res=>this.log('inside cc services')
      ),
      catchError(
        this.handleError<any>('cardCreation', []))
      )

  }

  getJIOLocationDetails(type:string, jcMapping : any) : Observable<any>
  {
    return this.httpClient.post(this.apiURL+'GetJIOLocationDetails?strSiteCode='+  this.udetails.siteCode +'&Type='+type,JSON.stringify(jcMapping),httpOptions).pipe(
      tap(
        res=>this.log('inside cc services')
      ),
      catchError(
        this.handleError<any>('cardCreation', []))
      )

  }
  GetJIOLocationDetailsByJCCode(type:string, jcMapping : any) : Observable<any>
  {
    return this.httpClient.post(this.apiURL+'GetJIOLocationDetailsByJCCode?strSiteCode='+  this.udetails.siteCode +'&jccode='+type,JSON.stringify(jcMapping),httpOptions).pipe(
      tap(
        res=>this.log('inside cc services')
      ),
      catchError(
        this.handleError<any>('cardCreation', []))
      )
  }  
  countValidation(type:string, code : string) : Observable<any>
  {
    return this.httpClient.post(this.apiURL+'countValidation?strSiteCode='+  this.udetails.siteCode +'&type='+type + "&code="+code ,httpOptions).pipe(
      tap(
        res=>this.log('inside cc services')
      ),
      catchError(
        this.handleError<any>('cardCreation', []))
      )
  }  
  getOtherDetailConfiguration(resCode : string) : Observable<any>
  {
    return this.httpClient.post(this.apiURL+'GetOtherDetails?strSiteCode='+  this.udetails.siteCode +'&rescode='+resCode+'&roleCode='+  this.udetails.siteCode +'',JSON.stringify(''),httpOptions).pipe(
      tap(
        res=>this.log('inside cc services')
      ),
      catchError(
        this.handleError<any>('cardCreation', []))
      )
  }

  GetApprovalDetailsData(resCode : string) : Observable<any>
  {
    return this.httpClient.post(this.apiURL+'GetApprovalDetailsData?strSiteCode='+  this.udetails.siteCode +'&rescode='+resCode+'&roleCode='+  this.udetails.siteCode +'',JSON.stringify(''),httpOptions).pipe(
      tap(
        res=>this.log('inside cc services')
      ),
      catchError(
        this.handleError<any>('cardCreation', []))
      )
  }
  SaveApproval(resCode : string, photo: string) : Observable<any>
  {
    return this.httpClient.post(this.apiURL+'SaveApproval?strSiteCode='+  this.udetails.siteCode +'&rescode='+resCode+'&ChangedBy='+  this.udetails.userCode +'&ChangedByRole='+  this.udetails.roleCode+'',JSON.stringify(''),httpOptions).pipe(
      tap(
        res=>this.log('inside cc services')
      ),
      catchError(
        this.handleError<any>('cardCreation', []))
      )
  }

  GetExcelForCardCreationRequest() : Observable<any>
  {
    return this.httpClient.post('http://localhost:5423/CC/GetExcelForCardCreationRequest?strSiteCode ='+  this.udetails.siteCode + '' ,JSON.stringify(''),httpOptions).pipe(
      tap(
        res=>this.log('inside cc services')
      ),
      catchError(
        this.handleError<any>('cardCreation', []))
      )
  }

  private handleError<T> (operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {

      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead

      // TODO: better job of transforming error for user consumption
      console.log(`${operation} failed: ${error.message}`);

      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }
}
