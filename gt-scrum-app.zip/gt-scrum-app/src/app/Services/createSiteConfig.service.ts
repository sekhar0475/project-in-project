import { Injectable } from '@angular/core';
import { observable, Observable, of } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { SiteConfig } from '../Model/MDMModel/siteConfig';
import { requestDetail } from '../Model/CcModel/requestDetail';
import { httpOptions } from './httpConstant';
import { tap, catchError } from 'rxjs/operators';
import { promise } from 'protractor';
import { siteFieldsConfig } from '../Model/MDMModel/siteFieldsConfig';
import { SiteFieldsEditConfig } from '../Model/MDMModel/sitefieldseditconfig';
import { apiURL } from './httpConstant';
import { SiteApprovalConfig } from '../Model/MDMModel/siteapprovalconfig';

@Injectable({
  providedIn: 'root'
})
export class CreateSiteConfigService {


  siteConfigOBJ: SiteConfig; //create object for siteconfig Model

  messageService: string[] = [];

  apiURL: string = apiURL + "/"; //api URL CC/

  constructor(private _httpClient: HttpClient) { }

  getGroup(siteCode: string, resCode: string, entity: string, refID: string): Promise<any> {
    const promise = this._httpClient.post(this.apiURL + "CC/" + 'GetEntityInfo?strSiteCode=1&rescode=2&Entity=' + entity + '&RefID=' + refID + '&TypeOff=LstMstObject', JSON.stringify(''), httpOptions)
      .toPromise();
    // .then((response)
    // return this._httpClient.post(this.apiURL+"CC/"+'GetEntityInfo?strSiteCode=1&rescode=2&Entity='+entity+'&RefID='+refID+'&TypeOff=LstMstObject',JSON.stringify(''),httpOptions).pipe(
    //   tap(
    //     res=>this.log('inside siteConfig services')
    //   )

    // )
    return promise;
  }

  getEntityInfo(siteCode: string, resCode: string, entity: string, refID: string): Promise<any> {
    const promise = this._httpClient.post(this.apiURL + "CC/" + 'GetEntityInfo?strSiteCode=' + siteCode + '&rescode=' + resCode + '&Entity=' + entity + '&RefID=' + refID + '&TypeOff=LstMstObject', JSON.stringify(''), httpOptions)
      .toPromise();
    return promise;
  }

  getParentTableRef(siteCode: string, resCode: string, entity: string, refID: string): Observable<any> {
    return this._httpClient.post(this.apiURL + "CC/" + 'GetEntityInfo?strSiteCode=' + siteCode + '&rescode=2&Entity=' + entity + '&RefID=' + refID + '&TypeOff=LstMstObject', JSON.stringify(''), httpOptions).pipe(
      tap(
        res => this.log('inside cc services')
      ),
      catchError(
        this.handleError<any>('cardCreation', []))
    )
  }

  getEditRecord(code: number, siteCode: string, resCode: string, entity: string, refID: string): Observable<any> {
    return this._httpClient.post(this.apiURL + 'getRecordsiteconfigForEdit?Code=' + code + '&siteCode=' + siteCode + '&Type=' + entity + '&status=0', JSON.stringify(''), httpOptions).pipe(
      tap(
        res => this.log('inside SC services')
      ),
      catchError(
        this.handleError<any>('site Config', []))
    )
  }
  getSiteFieldEditConfiguration(siteCode:string, type:string, Code : string) : Observable<any>

  {

    return this._httpClient.post(this.apiURL+'SC/getSiteFieldEditConfig?strSiteCode='+ siteCode +'&Type='+type +'&Code='+ Code,JSON.stringify(''),httpOptions).pipe(

      tap( res=>this.log('inside sc services') ), catchError( this.handleError<any>('GetUserID', [])))

  }
  

  saveSiteConfig(req: SiteConfig): Observable<any> {
    return this._httpClient.post(this.apiURL + 'SC/CreateOrUpdateUser', JSON.stringify(req), httpOptions).pipe(
      tap(res => this.log('inside siteConfig services')), catchError(this.handleError<any>('GetUserID', [])))
  }

  DataSet(Req: requestDetail): Observable<any> {
    return this._httpClient.post(this.apiURL + 'SC/DataSet', JSON.stringify(Req), httpOptions).pipe(
      tap(res => this.log('inside SC services')), catchError(this.handleError<any>('GetUserID', [])))
  }

  saveSiteFieldConfig(req: siteFieldsConfig): Observable<any> {
    return this._httpClient.post(this.apiURL + 'SC/CreateOrUpdateSitefieldConfig', JSON.stringify(req), httpOptions).pipe(
      tap(res => this.log('inside siteConfig services')), catchError(this.handleError<any>('GetUserID', [])))
  }


  saveSiteFieldEditConfig(req: SiteFieldsEditConfig): Observable<any> {
    return this._httpClient.post(this.apiURL + 'SC/CreateOrUpdateSitefieldEditConfig', JSON.stringify(req), httpOptions).pipe(
      tap(res => this.log('inside siteConfig services')), catchError(this.handleError<any>('GetUserID', [])))
  }


  saveSiteApprovalConfig(req: SiteApprovalConfig): Observable<any> {
    return this._httpClient.post(this.apiURL + 'SC/CreateOrUpdateSiteApprovalConfig', JSON.stringify(req), httpOptions).pipe(
      tap(res => this.log('inside siteConfig services')), catchError(this.handleError<any>('GetUserID', [])))
  }
  private log(message: string) {
    this.messageService.push("a");
  }

  DataTable(Req: requestDetail): Observable<any> {
    return this._httpClient.post(this.apiURL + 'UC/DataTable', JSON.stringify(Req), httpOptions).pipe(
      tap(res => this.log('inside cc services')), catchError(this.handleError<any>('GetUserID', [])))
  }


  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {

      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead

      // TODO: better job of transforming error for user consumption
      console.log(`${operation} failed: ${error.message}`);

      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }

}
