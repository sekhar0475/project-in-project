import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { HttpClientModule,HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { analyzeAndValidateNgModules } from '@angular/compiler';
import { map, tap, catchError } from "rxjs/operators";
import { SharedState } from '../Model/Common/InterPage';
import { httpOptions , loginServiceURL } from './httpConstant';

// const httpOptions = {
//   headers: new HttpHeaders({
//     'Content-Type':  'application/json'
//   })
// };

@Injectable({
  providedIn: 'root'
})
export class DashboardService {
  shared : SharedState = new SharedState();
  messageService :string []=[];

 apiURL: string = loginServiceURL;
  constructor(private httpClient: HttpClient ) {
    this.shared = JSON.parse(atob(localStorage.getItem('shared')));
   }

  getRoleListData (sitecode:number, strUserCode:number ): Observable<any> {
    // console.log(product);
    return this.httpClient.post<any>(this.apiURL + 'getRoleListData?strSitecode='+sitecode+'&strUserCode='+strUserCode+'', JSON.stringify(''), httpOptions).pipe(
      tap(_ => this.log('inside tap')),
      catchError(this.handleError<any>('', []))
    );
  }

  getUserDetailsFromSite(siteCode : string): Observable<any>{
    console.log(this.apiURL + 'getUserDetailsFromSite?siteId='+siteCode+'&UserId='+this.shared.userDomainId+'&IPAddress='+this.shared.ipAddress+'&IsVendor='+this.shared.isVendor+'&LoginSite='+this.shared.siteUrl)
    return this.httpClient.post<any>(this.apiURL + 'getUserDetailsFromSite?siteId='+siteCode+'&UserId='+this.shared.userDomainId+'&IPAddress='+this.shared.ipAddress+'&IsVendor='+this.shared.isVendor+'&LoginSite='+this.shared.siteUrl, JSON.stringify(''), httpOptions).pipe(
      tap(_ => this.log('inside tap')),
      catchError(this.handleError<any>('', []))
    );
  }

  dashBoardPendingDetail (): Observable<any> {
    // console.log(product);
    return this.httpClient.post<any>(this.apiURL + 'DashBoardPendingDetail?strSiteCode='+this.shared.siteCode+'&strUserCode='+this.shared.userCode+'&rolecode='+this.shared.roleCode, JSON.stringify(''), httpOptions).pipe(
      tap(_ => this.log('inside tap')),
      catchError(this.handleError<any>('', []))
    );
  }

  getMenuListData (sitecode:number, userCode:number, roleCode:number ): Observable<any> {
    // console.log(product);
    return this.httpClient.post<any>(this.apiURL + 'getMenuListData?strSitecode='+sitecode+'&strUserCode='+userCode+'&roleCode='+roleCode+'', JSON.stringify(''), httpOptions).pipe(
      tap(_ => this.log('inside tap')),
      catchError(this.handleError<any>('', []))
    );
  }
  private log(message: string) {
    this.messageService.push("a");
  }

  private handleError<T> (operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {

      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead

      // TODO: better job of transforming error for user consumption
      console.log(`${operation} failed: ${error.message}`);

      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }

}
