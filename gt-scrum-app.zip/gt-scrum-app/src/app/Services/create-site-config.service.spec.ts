import { TestBed } from '@angular/core/testing';

import { CreateSiteConfigService } from './create-site-config.service';

describe('CreateSiteConfigService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CreateSiteConfigService = TestBed.get(CreateSiteConfigService);
    expect(service).toBeTruthy();
  });
});
