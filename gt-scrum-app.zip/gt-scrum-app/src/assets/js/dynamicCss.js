 $(document).ready(function() {alert('inside javascript');
  $(".css-red").click(function() {
        $(this).addClass('active').siblings().removeClass('active');
        $("#btheme").attr({href : "css/theme-red/master.css"});
      });
});