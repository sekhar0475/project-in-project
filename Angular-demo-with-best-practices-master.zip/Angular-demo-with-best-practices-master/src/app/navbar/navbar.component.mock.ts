import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-navbar',
  template: ''
})
// tslint:disable-next-line:component-class-suffix
export class NavbarComponentMock implements OnInit {
  constructor() {}

  public ngOnInit() {}
}
