import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footer',
  template: ''
})
// tslint:disable-next-line:component-class-suffix
export class FooterComponentMock implements OnInit {
  constructor() {}

  public ngOnInit() {}
}
