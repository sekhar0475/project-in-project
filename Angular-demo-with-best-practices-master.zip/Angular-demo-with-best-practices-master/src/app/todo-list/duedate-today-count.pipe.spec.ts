/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { DuedateTodayCountPipe } from './duedate-today-count.pipe';

describe('Pipe: DuedateTodayCounte', () => {
  it('create an instance', () => {
    let pipe = new DuedateTodayCountPipe();
    expect(pipe).toBeTruthy();
  });
});
